package park.jun.test;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import park.jun.test.email.MailService;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@Inject
    private MailService mailService;
 
    public void setMailService(MailService mailService) {
        this.mailService = mailService;
    }
    
    @RequestMapping(value = "test")
    public String test(){
    	return "test";
    }
 
    // ȸ������ �̸��� ����
    @RequestMapping(value = "sendMail", method = RequestMethod.POST)
    public String sendMailAuth(HttpSession session, @RequestParam String email) {
        int ran = new Random().nextInt(100000) + 10000; // 10000 ~ 99999
        String joinCode = String.valueOf(ran);
        session.setAttribute("joinCode", joinCode);
 
        String subject = "ȸ������ ���� �ڵ� �߱� �ȳ� �Դϴ�.";
        String joinText = "���� �ڵ�� " + joinCode + " �Դϴ�.";
        mailService.send(subject, joinText , "pjw941021@gmail.com", email);
        
        return "redirect:check";
    }
    
    @RequestMapping(value = "check", method = RequestMethod.GET)
    public String check(){
    	return "confirm";
    }
    //ȸ�� ���� �̸��� ���� Ȯ��
    
    @RequestMapping(value = "confirm", method = RequestMethod.POST)
    public void confirm(HttpSession session, @RequestParam String check){
    	String sessionCheck = (String) session.getAttribute("joinCode");
    	
    	int num1 = Integer.parseInt(sessionCheck);
    	int num2 = Integer.parseInt(check);
    	
    	boolean result;
    	if (num1 == num2){
    		result = true;
    	}else{
    		result = false;
    	}
    	
    	System.out.println(result);
    }
	
}
