package yjc.wdb.goculture.pesistence;

import java.util.List;

import yjc.wdb.goculture.bean.MemberVO;

public interface JoinDAO {
	public void insert(MemberVO member) throws Exception;
	public void update(MemberVO member) throws Exception;
	public void delete(String m_id) throws Exception;
	public List<MemberVO> select() throws Exception;
	public MemberVO read(String m_id) throws Exception;
}
