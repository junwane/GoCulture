package yjc.wdb.goculture;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import yjc.wdb.goculture.bean.MemberVO;
import yjc.wdb.goculture.service.JoinService;

@Controller
public class LoginController {
	
	@Inject
	private JoinService join;
	
	@RequestMapping(value="/join", method=RequestMethod.GET)
	public String joinGET() throws Exception{
		return "/Login/page_join";
	}
	
	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String joinPOST(MemberVO member) throws Exception{
		join.insert(member);
		
		return "redirect:success";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginGET() throws Exception{
		return "/Login/page_login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String loginPOST(MemberVO member, @RequestParam("m_id") String m_id, @RequestParam("m_pw") String m_pw, HttpSession session) throws Exception{
		System.out.println(m_id);
		System.out.println(m_pw);
		
		MemberVO m =  join.read(m_id);
	
		String mId = m.getM_id();
		String mPw = m.getM_pw();

		if(mId.equals(m_id) && mPw.equals(m_pw)) {

			session.setAttribute("m_id", m_id);
			return "redirect:test";
		} else {
			return "redirect:login";
		}
		
		
		
	}
	

	
	@RequestMapping(value="/findid", method=RequestMethod.GET)
	public String findidGET() throws Exception{
		return "/Login/page_findid";
	}
	
	@RequestMapping(value="/findpw", method=RequestMethod.GET)
	public String findpwGET() throws Exception{
		return "/Login/page_findpw";
	}
	
	
	
	
	
	
	
	
	@RequestMapping(value="/success", method=RequestMethod.GET)
	public void success() throws Exception{

	}
	
	@RequestMapping(value="/test", method=RequestMethod.GET)
	public void test() throws Exception{
		
	}
}
