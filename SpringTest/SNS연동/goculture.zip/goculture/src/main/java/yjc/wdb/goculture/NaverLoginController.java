package yjc.wdb.goculture;

import java.io.IOException;


import javax.servlet.http.HttpSession;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.github.scribejava.core.model.OAuth2AccessToken;

import yjc.wdb.goculture.sns.NaverLoginBO;

@Controller
public class NaverLoginController {
	
	/* NaverLoginBO */
	private NaverLoginBO naverLoginBO;

	/* NaverLoginBO */
	@Autowired
	private void setNaverLoginBO(NaverLoginBO naverLoginBO){
		this.naverLoginBO = naverLoginBO;
	}
	
    @RequestMapping("/auth/naver")
    public String login(HttpSession session) {
        /* �׾Ʒ� ���� URL�� �����ϱ� ���Ͽ� getAuthorizationUrl�� ȣ�� */
        String naverAuthUrl = naverLoginBO.getAuthorizationUrl(session);
        
        /* ������ ���� URL�� View�� ���� */
        return "redirect:"+ naverAuthUrl;
    }
    
	@RequestMapping("/auth/naver/callback")
	public String callback(@RequestParam String code, @RequestParam String state, HttpSession session) throws IOException, ParseException {
		OAuth2AccessToken oauthToken = naverLoginBO.getAccessToken(session, code, state);
		String apiResult = naverLoginBO.getUserProfile(oauthToken);
		
		
		System.out.println(apiResult);
		
		ObjectMapper mapper = new ObjectMapper();
		JsonFactory factory = mapper.getJsonFactory(); // since 2.1 use mapper.getFactory() instead
		JsonParser jp = factory.createJsonParser(apiResult);
		JsonNode actualObj = mapper.readTree(jp);

		String id = null;
		String email = null;
		
		JsonNode response = actualObj.path("response");
		if(response.isMissingNode()) {
			
		} else {
			id = response.path("enc_id").asText();
			email = response.path("email").asText();
			
			System.out.println(id);
			System.out.println(email);
		}
 
		
		
		return "redirect:success";
		

	}
	
	@RequestMapping(value = "auth/naver/success", method = RequestMethod.GET)
	public String success() throws Exception{
		return "success";
	}
}
