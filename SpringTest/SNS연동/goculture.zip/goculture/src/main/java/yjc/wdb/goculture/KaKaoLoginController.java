package yjc.wdb.goculture;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;

import yjc.wdb.goculture.sns.KaKaoLoginBO;

@Controller
public class KaKaoLoginController {
	@RequestMapping(value="/kakaologin", produces="application/json", method= {RequestMethod.GET, RequestMethod.POST})
	public String kakaoLogin(@RequestParam("code") String code, HttpServletRequest request, HttpServletResponse httpServlet) {
		System.out.println("code : " + code);

		JsonNode jsonToken = KaKaoLoginBO.getAccessToken(code);
		System.out.println("JSON ��ȯ : " + jsonToken.get("access_token"));
		
		
		
		//����� ���� ��û
        JsonNode userInfo = KaKaoLoginBO.getKakaoUserInfo(jsonToken.get("access_token"));
        
        // Get id
 		String id = userInfo.path("id").asText();
 		String kaccount_email = userInfo.path("kaccount_email").asText();
 		String nickname = null;
 		String thumbnailImage = null;
 		String profileImage = null;
 		String message = null;
     		
        // �������� ī�忡�� �������� Get properties
		JsonNode properties = userInfo.path("properties");
		if (properties.isMissingNode()) {
			// if "name" node is missing
		} else {
			nickname = properties.path("nickname").asText();
			thumbnailImage = properties.path("thumbnail_image").asText();
			profileImage = properties.path("profile_image").asText();

			System.out.println("kaccount_email : " + kaccount_email);
			System.out.println("nickname : " + nickname);
			System.out.println("thumbnailImage : " + thumbnailImage);
			System.out.println("profileImage : " + profileImage);
		}


		return "success";




		
	}
	
	
}
