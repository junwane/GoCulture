package go.culture.service;

import java.util.List;

import go.culture.domain.NoticeVO;

public interface NoticeService {
	public void regist(NoticeVO Notice)throws Exception;
	
	public NoticeVO read(Integer nb_no)throws Exception;
	
	public void modify(NoticeVO notice)throws Exception;
	
	public void delete(Integer nb_no)throws Exception;
	
	public List<NoticeVO> listAll() throws Exception;

}
