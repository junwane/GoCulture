package go.culture.dao;

import java.util.List;

import go.culture.domain.NoticeVO;

public interface NoticeDAO {

	public void create(NoticeVO vo)throws Exception;
	
	public NoticeVO read(Integer nb_no)throws Exception;
	
	public void update(NoticeVO vo)throws Exception;

	public void delete(Integer nb_no)throws Exception;

	public List<NoticeVO> listAll()throws Exception;

}
