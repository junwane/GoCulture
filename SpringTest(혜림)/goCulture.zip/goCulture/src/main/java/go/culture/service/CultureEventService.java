package go.culture.service;

import go.culture.domain.CultureEventVO;

public interface CultureEventService {

	public void register(CultureEventVO vo) throws Exception;
	
}
