package go.culture.yg;

import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import go.culture.domain.NoticeVO;
import go.culture.service.NoticeService;

@Controller
public class NoticeController {
   private static final Logger logger = LoggerFactory.getLogger(NoticeController.class);
   
   @Inject
   private NoticeService service;

   @RequestMapping(value="/mknoticeBoard",method = RequestMethod.GET)
   public void registerGet(NoticeVO notice, Model model) throws Exception{
      logger.info("register get........");
   }//����� �������� �̵��ϴ°� �������� ..
   
   @RequestMapping(value="/register",method = RequestMethod.POST)
   public String registerPOST(NoticeVO notice, Model model) throws Exception{
      logger.info("register postt........");
      logger.info(notice.toString());
      
      service.regist(notice);
      
      model.addAttribute("msg","success");
      //return "/notice/success";
      return "redirect:noticeBoard";
      
   }//��ü����Ʈâ���� �̵�

@RequestMapping(value="/noticeBoard",method=RequestMethod.GET)
public void listAll(Model model)throws Exception{
   logger.info("show all list..........");
   List<NoticeVO> list = service.listAll();
	model.addAttribute("list", list);
}

@RequestMapping(value="/noticeBoardInner",method =RequestMethod.GET)
public void read(@RequestParam("nb_no") int nb_no, Model model)throws Exception{
	NoticeVO notice = service.read(nb_no);
	model.addAttribute("notice", notice);
}
@RequestMapping(value="/remove", method=RequestMethod.POST)
public String remove(@RequestParam("nb_no")int nb_no,
      RedirectAttributes rttr)throws Exception{
   service.delete(nb_no);
   rttr.addFlashAttribute("msg","SUCCESS");
   return "redirect:noticeBoard";
}
@RequestMapping(value ="/modify",method =RequestMethod.GET)
   public void modifyGET(int nb_no,Model model)throws Exception{
   model.addAttribute(service.read(nb_no));
   
}
@RequestMapping(value="/modify",method = RequestMethod.POST)
   public String modifyPOST(NoticeVO notice, RedirectAttributes rttr) throws Exception{
   logger.info("mod post........");
   service.modify(notice);
   rttr.addFlashAttribute("msg","SUCCESS");
   return "redirect:noticeBoard";
}

}