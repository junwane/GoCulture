function showme(v, id){
	if(v=="show"){
		document.getElementById(id).style.display="none";
		document.getElementById(v).id = "none";
	}else if(v=="none"){
		document.getElementById(id).style.display="block";
		document.getElementById(v).id = "show";
	}
}
function showmeQ(v, id){
	if(v=="showQ"){
		document.getElementById(id).style.display="none";
		document.getElementById(v).id = "noneQ";
	}else if(v=="noneQ"){
		document.getElementById(id).style.display="block";
		document.getElementById(v).id = "showQ";
	}
}

var map

map = new Tmap.Map({
	div : 'map_div',
	width : '100%',
	height : '400px',
	transitionEffect : "resize",
	animation : true
});
map.setCenter(new Tmap.LonLat(14315520.90430, 4283115.74626), 11);
// map.addControl(new Tmap.Control.KeyboardDefaults());
map.addControl(new Tmap.Control.MousePosition());
// searchRoute();