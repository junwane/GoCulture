package go.culture.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.TicketingDAO;
import go.culture.domain.TicketingVO;

@Service
public class TicketingServiceImpl implements TicketingService{
	
	@Inject
	private TicketingDAO dao;

	@Override
	public TicketingVO read(Integer cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.read(cul_no);
	}

}
