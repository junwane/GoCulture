package go.culture.domain;

public class TicketingVO {

	
	private Integer cul_no;
	private String cul_title;
	private Integer cul_price;
	
	
	public Integer getCul_no() {
		return cul_no;
	}
	public void setCul_no(Integer cul_no) {
		this.cul_no = cul_no;
	}
	public String getCul_title() {
		return cul_title;
	}
	public void setCul_title(String cul_title) {
		this.cul_title = cul_title;
	}
	public Integer getCul_price() {
		return cul_price;
	}
	public void setCul_price(Integer cul_price) {
		this.cul_price = cul_price;
	}
	
}
