package go.culture.yg;
import javax.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import go.culture.service.TicketingService;



@Controller
@RequestMapping("/yg/*")

public class TicketingController {
	private static final Logger logger=LoggerFactory.getLogger(TicketingController.class);
	
	@Inject
	private TicketingService service;
	
	
	@RequestMapping(value="/memTicketing", method = RequestMethod.GET)
	public void read(@RequestParam("cul_no") int cul_no,Model model)
	throws Exception{
		
		cul_no = 1;
		
		model.addAttribute(service.read(cul_no));
		
		System.out.println(cul_no);
	}

}
