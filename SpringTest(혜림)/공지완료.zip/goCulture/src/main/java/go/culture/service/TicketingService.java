package go.culture.service;

import go.culture.domain.TicketingVO;

public interface TicketingService {

	public TicketingVO read(Integer cul_no)throws Exception;
	
}
