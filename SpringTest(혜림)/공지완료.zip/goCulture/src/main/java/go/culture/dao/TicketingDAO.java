package go.culture.dao;

import go.culture.domain.TicketingVO;

public interface TicketingDAO {

	public TicketingVO read(Integer cul_no)throws Exception;
	
}
