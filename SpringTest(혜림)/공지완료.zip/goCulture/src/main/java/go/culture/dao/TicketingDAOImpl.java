package go.culture.dao;

import go.culture.domain.TicketingVO;


import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public class TicketingDAOImpl implements TicketingDAO{
	
	@Inject
	private SqlSession session;

	private static String NAMESPACE = "go.culture.mapper.TicketingMapper";
	
	
	@Override
	public TicketingVO read(Integer cul_no) throws Exception {
		
		
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+".read",cul_no);
	}
	
	

}
