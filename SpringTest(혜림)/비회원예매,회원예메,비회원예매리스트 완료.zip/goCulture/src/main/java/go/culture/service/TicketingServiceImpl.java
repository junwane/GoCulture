package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.TicketingDAO;
import go.culture.domain.TicketingVO;

@Service
public class TicketingServiceImpl implements TicketingService{
	
	@Inject
	private TicketingDAO dao;

	@Override
	public TicketingVO read(Integer cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.read(cul_no);
	}

	@Override
	public void regist(TicketingVO ticketing) throws Exception {
		
		dao.create(ticketing);
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<TicketingVO> listAll() throws Exception {
		// TODO Auto-generated method stub
		return dao.listAll();
	}



}
