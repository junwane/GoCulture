package go.culture.dao;


import go.culture.domain.TicketingVO;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

@Repository
public  class TicketingDAOImpl implements TicketingDAO{
	
	@Inject
	private SqlSession session;

	private static String NAMESPACE = "go.culture.mapper.TicketingMapper";
	
	
	@Override
	public TicketingVO read(Integer cul_no) throws Exception {
		
		
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+".read", cul_no);
	}


	

	@Override
	public void create(TicketingVO ticketing) throws Exception {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+".create",ticketing);
	}




	@Override
	public List<TicketingVO> listAll() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+".listAll");
	}


	
	
	

}
