package go.culture.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.NonTicketingVO;

@Repository
public class NonTicketingDAOImpl implements NonTicketingDAO {
	
	@Inject
	private SqlSession session;
	
	private static String namespace = "go.culture.mapper.NonTicketingMapper";

	@Override
	public void create1(NonTicketingVO nonticketing) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".create1",nonticketing);
	}

	@Override
	public NonTicketingVO read1(Integer cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".read",cul_no);
	}

	@Override
	public List<NonTicketingVO> listAll(String nm_name, int nm_residentNum) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> non = new HashMap<String, Object>();
		non.put("nm_name", nm_name);
		non.put("nm_residentNum", nm_residentNum);       
		return session.selectList(namespace+".listAll", non);
	}

	@Override
	public void noncreate(NonTicketingVO non) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".noncreate",non);
		
	}
	

}
