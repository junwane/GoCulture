package go.culture.domain;

import java.sql.Date;

public class TicketingVO {

	
	private Integer cul_no;//����ȣ
	private String cul_title;//�������
	private Integer cul_price;//��� ����
	private int t_quantity;//�ż�
	private int t_totalPrice;//�Ѱ���
	private Integer nm_no;//��ȸ����ȣ 
	private int m_no;//ȸ����ȣ
	private Date t_date;
	public Date getT_date() {
		return t_date;
	}
	public void setT_date(Date t_date) {
		this.t_date = t_date;
	}
	public Date getT_register() {
		return t_register;
	}
	public void setT_register(Date t_register) {
		this.t_register = t_register;
	}
	private Date t_register;
	
	public Date getCul_startDate() {
		return cul_startDate;
	}
	public void setCul_startDate(Date cul_startDate) {
		this.cul_startDate = cul_startDate;
	}
	public Date getCul_endDate() {
		return cul_endDate;
	}
	public void setCul_endDate(Date cul_endDate) {
		this.cul_endDate = cul_endDate;
	}
	private Date		cul_startDate;		// ��� ������
	private Date		cul_endDate;		// ��� ������
	
	
	public int getT_quantity() {
		return t_quantity;
	}
	public void setT_quantity(int t_quantity) {
		this.t_quantity = t_quantity;
	}
	public int getT_totalPrice() {
		return t_totalPrice;
	}
	public void setT_totalPrice(int t_totalPrice) {
		this.t_totalPrice = t_totalPrice;
	}
	public Integer getNm_no() {
		return nm_no;
	}
	public void setNm_no(Integer nm_no) {
		this.nm_no = nm_no;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	
	
	public Integer getCul_no() {
		return cul_no;
	}
	public void setCul_no(Integer cul_no) {
		this.cul_no = cul_no;
	}
	public String getCul_title() {
		return cul_title;
	}
	public void setCul_title(String cul_title) {
		this.cul_title = cul_title;
	}
	public Integer getCul_price() {
		return cul_price;
	}
	public void setCul_price(Integer cul_price) {
		this.cul_price = cul_price;
	}
	
}
