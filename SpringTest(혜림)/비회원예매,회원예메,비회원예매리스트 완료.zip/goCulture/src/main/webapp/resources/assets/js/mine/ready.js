jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
});