/**
 * 
 */
function myFunction() {
    document.getElementById("demo").innerHTML = "<input></input><button>검색</button>";
    }