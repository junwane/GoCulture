package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import go.culture.dao.NonTicketingDAO;
import go.culture.domain.NonTicketingVO;

@Service
public class NonTicketingServiceImpl implements NonTicketingService{
	
	@Inject
	private NonTicketingDAO dao;

	@Transactional
	@Override
	public void create1(NonTicketingVO nonticketing) throws Exception {
		// TODO Auto-generated method stub
		
		dao.create1(nonticketing);
		dao.noncreate(nonticketing);
		
	}

	@Override
	public NonTicketingVO read1(Integer cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.read1(cul_no);
	}

	@Override
	public List<NonTicketingVO> listAll(String nm_name, int nm_residentNum) throws Exception {
		// TODO Auto-generated method stub
		return dao.listAll(nm_name, nm_residentNum);
	}

	@Override
	public void noncreate(NonTicketingVO nonticketing) throws Exception {
		// TODO Auto-generated method stub
		dao.noncreate(nonticketing);
		
	}

}
