package go.culture.yg;


import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import go.culture.domain.MemberVO;
import go.culture.service.JoinService;




@Controller
public class LoginController {
	
	
	@Inject
	private JoinService join;
	


	@RequestMapping(value="/singUp", method=RequestMethod.GET)
	public String joinGET() throws Exception{
		return "singUp";
	}
	
	@RequestMapping(value="/singUp", method=RequestMethod.POST)
	public String joinPOST(MemberVO member) throws Exception{
		join.insert(member);
		
		return "redirect:main";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginGET() throws Exception{
		return "login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String loginPOST(MemberVO member, @RequestParam("m_email") String m_email, @RequestParam("m_password") String m_password, HttpSession session) throws Exception{
		
		MemberVO m =  join.read(m_email);
	
		String mId = m.getM_email();
		String mPw = m.getM_password();

		if(mId.equals(m_email) && mPw.equals(m_password)) {

			session.setAttribute("m_email", m_email);
			return "redirect:main";
		} else {
			return "redirect:login";
		}
		
		
		
	}
}
