package go.culture.service;

import java.util.List;

import go.culture.domain.NonTicketingVO;
import go.culture.domain.TicketingVO;

public interface TicketingService {

	public TicketingVO read(Integer cul_no)throws Exception;
	
	public void regist(TicketingVO ticketing)throws Exception;

	public List<TicketingVO> listAll()throws Exception;

	



}
