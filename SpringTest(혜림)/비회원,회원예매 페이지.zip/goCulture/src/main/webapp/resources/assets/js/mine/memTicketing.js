var price1;
var price;

$(document).ready(function(){

	var formObj = $("form[action='#']");
	console.log(formObj);
	$("#myBtn").on("click", function(){
		formObj.attr("action", "/yg/success");
		formObj.attr("method", "POST");
		formObj.submit();
	
	
	});
	
});

function add(){
	price = $('.priceNum').val();
	price1 = $('.price1').val();
	
	var t_totalPrice = price * price1
	
	alert(t_totalPrice);
	
	var prices = $('.fullprice').length;
	
	if(prices > 0){
		$('.size').remove();
	}
	$('.fullprice').append("<div class='size'><h2>결제금액: " + t_totalPrice + "원</h2></div>"
			+ "<input name='t_totalPrice' value='" + t_totalPrice + "' style='display:none'/>"
			);
}