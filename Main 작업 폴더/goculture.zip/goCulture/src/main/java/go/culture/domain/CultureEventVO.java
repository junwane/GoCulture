package go.culture.domain;

import java.sql.Date;

public class CultureEventVO {
	private int			cul_no;				// ��ȭ��� ��ȣ
	private int			cate_no;			// ī�װ��� ��ȣ
	private int			m_no;				// ȸ�� ��ȣ
	private String		cul_mainImg;		// ��ǥ �̹���
	private String		cul_title;			// ��� ����
	private Date		cul_startDate;		// ��� ������
	private int			cul_viewingTime;	// ��� �ð�
	private int			cul_price;			// ��� ����
	private String		cul_content;		// ��� ����
	private int			cul_questionNum;	// ���ǹ�ȣ
	private String		cul_latitude;		// ����
	private String		cul_hardness;		// �浵
	private Date		cul_register;		// �����
	private String		cul_placeName;		// ��� ���
	private String		cul_WGSlat;			// wgsǥ�� ���浵 
	private String		cul_WGSlon;			// wgsǥ�� ���浵 
	
	public String getCul_WGSlat() {
		return cul_WGSlat;
	}
	public void setCul_WGSlat(String cul_WGSlat) {
		this.cul_WGSlat = cul_WGSlat;
	}
	public String getCul_WGSlon() {
		return cul_WGSlon;
	}
	public void setCul_WGSlon(String cul_WGSlon) {
		this.cul_WGSlon = cul_WGSlon;
	}
	public String getCul_placeName() {
		return cul_placeName;
	}
	public void setCul_placeName(String cul_placeName) {
		this.cul_placeName = cul_placeName;
	}
	public int getCul_no() {
		return cul_no;
	}
	public void setCul_no(int cul_no) {
		this.cul_no = cul_no;
	}
	public int getCate_no() {
		return cate_no;
	}
	public void setCate_no(int cate_no) {
		this.cate_no = cate_no;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getCul_mainImg() {
		return cul_mainImg;
	}
	public void setCul_mainImg(String cul_mainImg) {
		this.cul_mainImg = cul_mainImg;
	}
	public String getCul_title() {
		return cul_title;
	}
	public void setCul_title(String cul_title) {
		this.cul_title = cul_title;
	}
	public Date getCul_startDate() {
		return cul_startDate;
	}
	public void setCul_startDate(Date cul_startDate) {
		this.cul_startDate = cul_startDate;
	}
	public int getCul_viewingTime() {
		return cul_viewingTime;
	}
	public void setCul_viewingTime(int cul_viewingTime) {
		this.cul_viewingTime = cul_viewingTime;
	}
	public int getCul_price() {
		return cul_price;
	}
	public void setCul_price(int cul_price) {
		this.cul_price = cul_price;
	}
	public String getCul_content() {
		return cul_content;
	}
	public void setCul_content(String cul_content) {
		this.cul_content = cul_content;
	}
	public int getCul_questionNum() {
		return cul_questionNum;
	}
	public void setCul_questionNum(int cul_questionNum) {
		this.cul_questionNum = cul_questionNum;
	}
	public String getCul_latitude() {
		return cul_latitude;
	}
	public void setCul_latitude(String cul_latitude) {
		this.cul_latitude = cul_latitude;
	}
	public String getCul_hardness() {
		return cul_hardness;
	}
	public void setCul_hardness(String cul_hardness) {
		this.cul_hardness = cul_hardness;
	}
	public Date getCul_register() {
		return cul_register;
	}
	public void setCul_register(Date cul_register) {
		this.cul_register = cul_register;
	}
	
	public String toString(){
		return "cul_no : " +  cul_no
				+ " cate_no" + cate_no
				+ " m_no : " + m_no
				+ " cul_mainImg" + cul_mainImg
				+ " cul_title" + cul_title
				+ " cul_startDate" + cul_startDate
				+ " cul_viewingTime" + cul_viewingTime
				+ " cul_price" + cul_price
				+ " cul_content" + cul_content
				+ " cul_questionNum" + cul_questionNum
				+ " cul_latitude" + cul_latitude
				+ " cul_hardness" + cul_hardness
				+ " cul_register" + cul_register
				+ " cul_placeName" + cul_placeName
				+ " cul_WGSlat" + cul_WGSlat
				+ " cul_WGSlon" + cul_WGSlon;

	}
	
}
