package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.PointVO;

@Repository
public class PointDAOImpl implements PointDAO {

	@Inject
	private SqlSession session;
	private static final String namespace = "go.culture.mapper.pointMapper";

	@Override
	public List<PointVO> listAddPoint() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".addPoint");
	}
	@Override
	public List<PointVO> listUsePoint() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".usePoint");
	}
	@Override
	public void usePoint(PointVO vo) {
		// TODO Auto-generated method stub
		session.insert(namespace+".updatePoint",vo);
	}

}
