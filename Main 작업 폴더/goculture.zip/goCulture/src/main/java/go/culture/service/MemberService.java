package go.culture.service;

import java.util.List;

import go.culture.domain.MemberVO;

public interface MemberService {
	public void changePw(String pw);
	
	public List<MemberVO> listMyInfo() throws Exception;
	
	public String checkPw(String m_password);
	
	public void delete();
	
	public List<MemberVO> listEmail(String search) throws Exception;
}
