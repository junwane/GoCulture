package go.culture.service;

import java.util.List;

import go.culture.domain.MemberVO;



public interface JoinService {
	public void				insert(MemberVO member)		throws Exception;
	public void				update(MemberVO member)		throws Exception;
	public void				delete(String m_id)			throws Exception;
	public List<MemberVO>	select()					throws Exception;
	public MemberVO			read(String m_id)			throws Exception;
	public void 			recommender(int m_no)		throws Exception;
}
