package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.TicketingDAO;
import go.culture.domain.TicketingVO;

@Service
public class TicketingServiceImpl implements TicketingService {
	

	@Inject
	private TicketingDAO dao;

	@Override
	public void insert(TicketingVO vo) throws Exception {
		// TODO Auto-generated method stub
		dao.insert(vo);
	}

	@Override
	public void insertNon(TicketingVO vo) throws Exception {
		// TODO Auto-generated method stub
		dao.insertNon(vo);
	}

	@Override
	public void insertNonTicketing(TicketingVO vo) throws Exception {
		// TODO Auto-generated method stub
		dao.insertNonTicketing(vo);
	}

	@Override
	public int getnmNo(TicketingVO vo) throws Exception {
		// TODO Auto-generated method stub
		return dao.getnmNo(vo);
	}

	@Override
	public void interestEvent(int cul_no, int m_no) throws Exception {
		// TODO Auto-generated method stub
		dao.interestEvent(cul_no, m_no);
	}

	@Override
	public int gettNo(TicketingVO vo) throws Exception {
		// TODO Auto-generated method stub
		return dao.gettNo(vo);
	}

	@Override
	public List<TicketingVO> reservePeople(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.reservePeople(cul_no);
	}

	@Override
	public List<TicketingVO> searchT(int t_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.searchT(t_no);
	}

	@Override
	public List<TicketingVO> reservePeopleNon(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.reservePeopleNon(cul_no);
	}

}
