package go.culture.domain;

import java.util.Date;

public class PointVO {
	private int m_no;
	private String eh_name;
	private int p_point;
	private Date p_date;
	private String p_useHistory;
	private String p_division;
	private int po1;
	private String m_email;

	public int getPo1() {
		return po1;
	}

	public void setPo1(int po1) {
		this.po1 = po1;
	}

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public String getEh_name() {
		return eh_name;
	}

	public void setEh_name(String eh_name) {
		this.eh_name = eh_name;
	}

	public int getP_point() {
		return p_point;
	}

	public void setP_point(int p_point) {
		this.p_point = p_point;
	}

	public Date getP_date() {
		return p_date;
	}

	public void setP_date(Date p_date) {
		this.p_date = p_date;
	}

	public String getP_useHistory() {
		return p_useHistory;
	}

	public void setP_useHistory(String p_useHistory) {
		this.p_useHistory = p_useHistory;
	}

	public String getP_division() {
		return p_division;
	}

	public void setP_division(String p_division) {
		this.p_division = p_division;
	}

	public String getM_email() {
		return m_email;
	}

	public void setM_email(String m_email) {
		this.m_email = m_email;
	}
	
}
