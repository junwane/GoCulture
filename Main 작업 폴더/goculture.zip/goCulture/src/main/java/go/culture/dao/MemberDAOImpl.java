package go.culture.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {
	@Inject
	private SqlSession session;
	private static final String namespace = "go.culture.mapper.memberMapper";

	@Override
	public void changePw(String m_password,int m_no) {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("m_password", m_password);
		map.put("m_no", m_no);
		session.update(namespace+".changePw",map);
	}

	@Override
	public List<MemberVO> listMyInfo(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listMyInfo",m_no);
	}

	@Override
	public String checkPw(String m_password,int m_no) {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("m_password", m_password);
		map.put("m_no", m_no);
		return session.selectOne(namespace+".checkPw",map);
	}

	@Override
	public void delete(int m_no) {
		// TODO Auto-generated method stub
		session.delete(namespace+".deleteMember",m_no);
	}

	@Override
	public List<MemberVO> listEmail(String search) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listEmail",search);
	}

	@Override
	public String findId(String name, int residentNum) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("m_name", name);
		map.put("m_residentNum", residentNum);
		return session.selectOne(namespace+".findId",map);
	}

	@Override
	public int findPw(String name, int residentNum, String email) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("m_name", name);
		map.put("m_residentNum", residentNum);
		map.put("m_email",email);
		return session.selectOne(namespace+".findPw",map);
	}

}
