package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.MemberVO;

@Repository
public class MemberDAOImpl implements MemberDAO {
	@Inject
	private SqlSession session;
	private static final String namespace = "go.culture.mapper.memberMapper";

	@Override
	public void changePw(String pw) {
		// TODO Auto-generated method stub
		session.update(namespace+".changePw",pw);
	}

	@Override
	public List<MemberVO> listMyInfo() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listMyInfo");
	}

	@Override
	public String checkPw(String m_password) {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".checkPw",m_password);
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		session.delete(namespace+".deleteMember");
	}

	@Override
	public List<MemberVO> listEmail(String search) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listEmail",search);
	}

}
