package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.ListVO;

@Repository
public class ListDAOImpl implements ListDAO {
	@Inject
	private SqlSession session;
	private static final String namespace = "go.culture.mapper.listMapper";
	
	@Override
	public List<ListVO> listGone(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listGone", m_no);
	}

	@Override
	public List<ListVO> listReservation(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listReservation", m_no);
	}

	@Override
	public List<ListVO> listHeart(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listHeart", m_no);
	}

	@Override
	public List<ListVO> listReservationDate(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listReservationDate", m_no);
	}

	@Override
	public List<ListVO> listHeartDate(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listHeartDate", m_no);
	}

	@Override
	public List<ListVO> listGone1mon(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listGone1mon", m_no);
	}

	@Override
	public List<ListVO> listGone3mon(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listGone3mon", m_no);
	}

	@Override
	public List<ListVO> listGone6mon(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listGone6mon", m_no);
	}

}
