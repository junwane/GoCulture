package go.culture.service;

import java.util.List;

import javax.inject.Inject;
import org.springframework.stereotype.Service;

import go.culture.dao.JoinDAO;
import go.culture.domain.MemberVO;



@Service
public class JoinServiceImpl implements JoinService {

	@Inject
	private JoinDAO dao;
	
	@Override
	public void insert(MemberVO member) throws Exception {
		// TODO Auto-generated method stub
		dao.insert(member);
	}

	@Override
	public void update(MemberVO member) throws Exception {
		// TODO Auto-generated method stub
		dao.update(member);
	}

	@Override
	public void delete(String m_id) throws Exception {
		// TODO Auto-generated method stub
		dao.delete(m_id);
	}

	@Override
	public List<MemberVO> select() throws Exception {
		// TODO Auto-generated method stub
		return dao.select();
	}

	@Override
	public MemberVO read(String m_id) throws Exception {
		// TODO Auto-generated method stub
		return dao.read(m_id);
	}

	@Override
	public void recommender(int m_no) throws Exception {
		// TODO Auto-generated method stub
		dao.recommender(m_no);
	}
	
}
