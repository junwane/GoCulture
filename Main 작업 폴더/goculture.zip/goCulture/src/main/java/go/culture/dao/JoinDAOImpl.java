package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.MemberVO;



@Repository
public class JoinDAOImpl implements JoinDAO {

	@Inject
	private SqlSession sql;
	private static final String namespace = "go.culture.mapper.memberMapper";
	
	@Override
	public void insert(MemberVO member) throws Exception {
		// TODO Auto-generated method stub
		sql.insert(namespace+".insert", member);
	}

	@Override
	public void update(MemberVO member) throws Exception {
		// TODO Auto-generated method stub
		sql.update(namespace+".update", member);
	}

	@Override
	public void delete(String m_id) throws Exception {
		// TODO Auto-generated method stub
		sql.delete(namespace+".delete", m_id);
	}

	@Override
	public List<MemberVO> select() throws Exception {
		// TODO Auto-generated method stub
		return sql.selectList(namespace+".select");
	}

	@Override
	public MemberVO read(String m_id) throws Exception {
		// TODO Auto-generated method stub
		return sql.selectOne(namespace+".read", m_id);
	}

	@Override
	public void recommender(int m_no) throws Exception {
		// TODO Auto-generated method stub
		sql.insert(namespace+".recommender", m_no);
	}

}
