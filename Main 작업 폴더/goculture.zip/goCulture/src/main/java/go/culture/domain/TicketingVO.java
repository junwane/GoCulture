package go.culture.domain;

import java.util.Date;

public class TicketingVO {
	private int t_no;
	private int m_no;
	private int cul_no;
	private int nm_no;
	private int t_quantity;
	private int t_totalPrice;
	private Date t_register;
	private String m_email;
	private String nm_name;
	private int nm_residentNum;
	private int nm_phoneNum;
	private Date ie_register;
	
	public int getT_no() {
		return t_no;
	}
	public void setT_no(int t_no) {
		this.t_no = t_no;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public int getCul_no() {
		return cul_no;
	}
	public void setCul_no(int cul_no) {
		this.cul_no = cul_no;
	}
	public int getNm_no() {
		return nm_no;
	}
	public void setNm_no(int nm_no) {
		this.nm_no = nm_no;
	}
	public int getT_quantity() {
		return t_quantity;
	}
	public void setT_quantity(int t_quantity) {
		this.t_quantity = t_quantity;
	}
	public int getT_totalPrice() {
		return t_totalPrice;
	}
	public void setT_totalPrice(int t_totalPrice) {
		this.t_totalPrice = t_totalPrice;
	}
	public Date getT_register() {
		return t_register;
	}
	public void setT_register(Date t_register) {
		this.t_register = t_register;
	}
	public String getM_email() {
		return m_email;
	}
	public void setM_email(String m_email) {
		this.m_email = m_email;
	}
	public String getNm_name() {
		return nm_name;
	}
	public void setNm_name(String nm_name) {
		this.nm_name = nm_name;
	}
	public int getNm_residentNum() {
		return nm_residentNum;
	}
	public void setNm_residentNum(int nm_residentNum) {
		this.nm_residentNum = nm_residentNum;
	}
	public int getNm_phoneNum() {
		return nm_phoneNum;
	}
	public void setNm_phoneNum(int nm_phoneNum) {
		this.nm_phoneNum = nm_phoneNum;
	}
	public Date getIe_register() {
		return ie_register;
	}
	public void setIe_register(Date ie_register) {
		this.ie_register = ie_register;
	}
	
	
}
