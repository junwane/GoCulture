package go.culture.domain;

import java.sql.Date;

public class NoticeVO {

	private Integer nb_no; //�Խ��� ��ȣ
	private String  nb_content; //�Խ��� ����
	private String nb_title;//�Խ��� ����
	public String getNb_title() {
		return nb_title;
	}
	public void setNb_title(String nb_title) {
		this.nb_title = nb_title;
	}
	private Integer  m_no;//�۾��� ��ȣ
	private Date nb_date;//�۾��� 
	public Integer getNb_no() {
		return nb_no;
	}
	public void setNb_no(Integer nb_no) {
		this.nb_no = nb_no;
	}
	public String getNb_content() {
		return nb_content;
	}
	public void setNb_content(String nb_content) {
		this.nb_content = nb_content;
	}
	public Integer getM_no() {
		return m_no;
	}
	public void setM_no(Integer m_no) {
		this.m_no = m_no;
	}
	public Date getNb_date() {
		return nb_date;
	}
	public void setNb_date(Date nb_date) {
		this.nb_date = nb_date;
	}


}
