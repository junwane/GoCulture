package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.GiftCardDAO;
import go.culture.domain.GiftCardUseVO;
import go.culture.domain.GiftCardVO;

@Service
public class GiftServiceImpl implements GiftCardService {

	@Inject
	private GiftCardDAO dao;

	@Override
	public void sendGiftCard(GiftCardVO vo) {
		// TODO Auto-generated method stub
		dao.sendGiftCard(vo);
	}

	@Override
	public List<GiftCardVO> listSend() throws Exception {
		// TODO Auto-generated method stub
		return dao.listSend();
	}

	@Override
	public List<GiftCardVO> listGet(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listGet(m_no);
	}

	@Override
	public List<GiftCardUseVO> listUse() throws Exception {
		// TODO Auto-generated method stub
		return dao.listUse();
	}
	
	@Override
	public void useGiftCard(GiftCardVO vo) {
		// TODO Auto-generated method stub
		dao.useGiftCard(vo);
	}

	@Override
	public List<GiftCardVO> extraGCList(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.extraGCList(m_no);
	}

}
