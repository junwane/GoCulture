package go.culture.dao;

import java.util.List;

import go.culture.domain.Criteria;
import go.culture.domain.NoticeVO;

public interface NoticeDAO {

	public void create(NoticeVO vo) throws Exception;

	public NoticeVO read(Integer nb_no) throws Exception;

	public void update(NoticeVO notice) throws Exception;

	public void delete(Integer nb_no) throws Exception;

	public List<NoticeVO> listAll() throws Exception;

	public List<NoticeVO> noticeBoard(int page) throws Exception;

	public List<NoticeVO> listCriteria(Criteria cri) throws Exception;
	
	public int countPaging(Criteria cri)throws Exception;

}
