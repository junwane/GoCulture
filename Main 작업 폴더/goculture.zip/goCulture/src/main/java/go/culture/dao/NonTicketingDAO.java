package go.culture.dao;

import java.util.List;

import go.culture.domain.NonTicketingVO;

public interface NonTicketingDAO {
	
	public void create1(NonTicketingVO nonticketing)throws Exception;
	
	public void noncreate(NonTicketingVO nonticketing)throws Exception;

	public NonTicketingVO read1(Integer cul_no)throws Exception;

	public List<NonTicketingVO> listAll(String nm_name, int nm_residentNum) throws Exception;

}
