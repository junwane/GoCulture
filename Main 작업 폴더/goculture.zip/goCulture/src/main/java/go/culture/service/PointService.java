package go.culture.service;

import java.util.List;

import go.culture.domain.PointVO;

public interface PointService {
	public List<PointVO> listAddPoint() throws Exception;
	
	public List<PointVO> listUsePoint() throws Exception;
}
