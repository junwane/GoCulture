package go.culture.domain;

public class DetailedPosterVO {
	private int		cul_no;
	private String	dp_detailedImg;
	private int		dp_sequence;
	
	public int getCul_no() {
		return cul_no;
	}
	public void setCul_no(int cul_no) {
		this.cul_no = cul_no;
	}
	public String getDp_detailedImg() {
		return dp_detailedImg;
	}
	public void setDp_detailedImg(String dp_detailedImg) {
		this.dp_detailedImg = dp_detailedImg;
	}
	public int getDp_sequence() {
		return dp_sequence;
	}
	public void setDp_sequence(int dp_sequence) {
		this.dp_sequence = dp_sequence;
	}
	public String toString(){
		return "cul_no" + cul_no
				+ "dp_detailedImg" + dp_detailedImg
				+ "dp_sequence" + dp_sequence;
	}
}
