package go.culture.domain;

import java.util.Date;

public class ListVO {
	private int cul_no;
	private int cate_no;
	private int m_no;
	private String cul_mainimg;
	private String cul_title;
	private Date cul_startDate;
	private Date cul_endDate;
	private int cul_viewingTime;
	private int cul_price;
	private String cul_content;
	private String cul_discountInfo;
	private int cul_questionNum;
	private String cul_honePage;
	private String cul_latitude;
	private String cul_hardness;
	private String cul_placeName;
	private String cul_WGSlat;
	private String cul_WGSlon;
	private Date cul_register;
	private Date t_date;
	private Date t_register;
	
	public int getCul_no() {
		return cul_no;
	}
	public void setCul_no(int cul_no) {
		this.cul_no = cul_no;
	}
	public int getCate_no() {
		return cate_no;
	}
	public void setCate_no(int cate_no) {
		this.cate_no = cate_no;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getCul_mainimg() {
		return cul_mainimg;
	}
	public void setCul_mainimg(String cul_mainimg) {
		this.cul_mainimg = cul_mainimg;
	}
	public String getCul_title() {
		return cul_title;
	}
	public void setCul_title(String cul_title) {
		this.cul_title = cul_title;
	}
	public Date getCul_startDate() {
		return cul_startDate;
	}
	public void setCul_startDate(Date cul_startDate) {
		this.cul_startDate = cul_startDate;
	}
	public Date getCul_endDate() {
		return cul_endDate;
	}
	public void setCul_endDate(Date cul_endDate) {
		this.cul_endDate = cul_endDate;
	}
	public int getCul_viewingTime() {
		return cul_viewingTime;
	}
	public void setCul_viewingTime(int cul_viewingTime) {
		this.cul_viewingTime = cul_viewingTime;
	}
	public int getCul_price() {
		return cul_price;
	}
	public void setCul_price(int cul_price) {
		this.cul_price = cul_price;
	}
	public String getCul_content() {
		return cul_content;
	}
	public void setCul_content(String cul_content) {
		this.cul_content = cul_content;
	}
	public String getCul_discountInfo() {
		return cul_discountInfo;
	}
	public void setCul_discountInfo(String cul_discountInfo) {
		this.cul_discountInfo = cul_discountInfo;
	}
	public int getCul_questionNum() {
		return cul_questionNum;
	}
	public void setCul_questionNum(int cul_questionNum) {
		this.cul_questionNum = cul_questionNum;
	}
	public String getCul_honePage() {
		return cul_honePage;
	}
	public void setCul_honePage(String cul_honePage) {
		this.cul_honePage = cul_honePage;
	}
	public String getCul_latitude() {
		return cul_latitude;
	}
	public void setCul_latitude(String cul_latitude) {
		this.cul_latitude = cul_latitude;
	}
	public String getCul_hardness() {
		return cul_hardness;
	}
	public void setCul_hardness(String cul_hardness) {
		this.cul_hardness = cul_hardness;
	}
	public String getCul_placeName() {
		return cul_placeName;
	}
	public void setCul_placeName(String cul_placeName) {
		this.cul_placeName = cul_placeName;
	}
	public String getCul_WGSlat() {
		return cul_WGSlat;
	}
	public void setCul_WGSlat(String cul_WGSlat) {
		this.cul_WGSlat = cul_WGSlat;
	}
	public String getCul_WGSlon() {
		return cul_WGSlon;
	}
	public void setCul_WGSlon(String cul_WGSlon) {
		this.cul_WGSlon = cul_WGSlon;
	}
	public Date getCul_register() {
		return cul_register;
	}
	public void setCul_register(Date cul_register) {
		this.cul_register = cul_register;
	}
	public Date gett_date() {
		return t_date;
	}
	public void sett_date(Date t_date) {
		this.t_date = t_date;
	}
	public Date gett_register() {
		return t_register;
	}
	public void sett_register(Date t_register) {
		this.t_register = t_register;
	}
	
		
}
