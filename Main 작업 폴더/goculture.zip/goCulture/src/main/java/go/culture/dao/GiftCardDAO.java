package go.culture.dao;

import java.util.List;

import go.culture.domain.GiftCardUseVO;
import go.culture.domain.GiftCardVO;

public interface GiftCardDAO {
	public void sendGiftCard(GiftCardVO vo);
	
	public List<GiftCardVO> listSend() throws Exception;
	
	public List<GiftCardVO> listGet() throws Exception;
	
	public List<GiftCardUseVO> listUse() throws Exception;
	
}
