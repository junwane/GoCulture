package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.MemberDAO;
import go.culture.domain.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO dao;
	
	@Override
	public void changePw(String pw,int m_no) {
		// TODO Auto-generated method stub
		dao.changePw(pw,m_no);
	}

	@Override
	public List<MemberVO> listMyInfo(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listMyInfo(m_no);
	}

	@Override
	public String checkPw(String m_password,int m_no) {
		// TODO Auto-generated method stub
		return dao.checkPw(m_password,m_no);
	}

	@Override
	public void delete(int m_no) {
		// TODO Auto-generated method stub
		dao.delete(m_no);
	}

	@Override
	public List<MemberVO> listEmail(String search) throws Exception {
		// TODO Auto-generated method stub
		return dao.listEmail(search);
	}

	@Override
	public String findId(String name, int residentNum) throws Exception {
		// TODO Auto-generated method stub
		return dao.findId(name, residentNum);
	}

	@Override
	public int findPw(String name, int residentNum,String email) throws Exception {
		// TODO Auto-generated method stub
		return dao.findPw(name, residentNum,email);
	}

}
