package go.culture.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.TicketingVO;

@Repository
public class TicketingDAOImpl implements TicketingDAO {
	
	@Inject
	private SqlSession sql;
	private static final String namespace = "go.culture.mapper.ticketingMapper";

	@Override
	public void insert(TicketingVO vo) throws Exception {
		// TODO Auto-generated method stub
		sql.insert(namespace+".insertmemTicketing", vo);
	}

}
