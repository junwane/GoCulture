package go.culture.domain;

import java.util.Date;

public class GiftCardUseVO {
	private int gc_no;
	private Date gcu_date;
	private String gcu_content;
	private int gcu_point;
	private int gc_point;
	private int n1;
	private String gc_title;

	public String getGc_title() {
		return gc_title;
	}

	public void setGc_title(String gc_title) {
		this.gc_title = gc_title;
	}

	public int getN1() {
		return n1;
	}

	public void setN1(int n1) {
		this.n1 = n1;
	}

	public int getGc_point() {
		return gc_point;
	}

	public void setGc_point(int gc_point) {
		this.gc_point = gc_point;
	}

	public int getGc_no() {
		return gc_no;
	}

	public void setGc_no(int gc_no) {
		this.gc_no = gc_no;
	}

	public Date getGcu_date() {
		return gcu_date;
	}

	public void setGcu_date(Date gcu_date) {
		this.gcu_date = gcu_date;
	}

	public String getGcu_content() {
		return gcu_content;
	}

	public void setGcu_content(String gcu_content) {
		this.gcu_content = gcu_content;
	}

	public int getGcu_point() {
		return gcu_point;
	}

	public void setGcu_point(int gcu_point) {
		this.gcu_point = gcu_point;
	}

}
