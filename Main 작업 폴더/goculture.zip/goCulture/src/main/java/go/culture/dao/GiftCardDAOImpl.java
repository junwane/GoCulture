package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.GiftCardUseVO;
import go.culture.domain.GiftCardVO;

@Repository
public class GiftCardDAOImpl implements GiftCardDAO {

	@Inject
	private SqlSession session;
	private static final String namespace = "go.culture.mapper.giftCardMapper";

	@Override
	public void sendGiftCard(GiftCardVO vo) {
		// TODO Auto-generated method stub
		session.insert(namespace + ".insertCard", vo);
	}

	@Override
	public List<GiftCardVO> listSend(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace + ".listSend",m_no);
	}

	@Override
	public List<GiftCardVO> listGet(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace + ".listGet", m_no);
	}

	@Override
	public List<GiftCardUseVO> listUse(int m_no) {
		// TODO Auto-generated method stub
		return session.selectList(namespace + ".listUse",m_no);
	}

	@Override
	public void useGiftCard(GiftCardVO vo) {
		// TODO Auto-generated method stub
		session.insert(namespace+".useGiftCard", vo);
	}

	@Override
	public List<GiftCardVO> extraGCList(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".extraGCList", m_no);
	}

}
