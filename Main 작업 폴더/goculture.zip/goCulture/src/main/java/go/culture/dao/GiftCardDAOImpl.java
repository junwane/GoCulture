package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.GiftCardUseVO;
import go.culture.domain.GiftCardVO;

@Repository
public class GiftCardDAOImpl implements GiftCardDAO {

	@Inject
	private SqlSession session;
	private static final String namespace = "go.culture.mapper.giftCardMapper";

	@Override
	public void sendGiftCard(GiftCardVO vo) {
		// TODO Auto-generated method stub
		session.insert(namespace + ".insertCard", vo);
	}

	@Override
	public List<GiftCardVO> listSend() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace + ".listSend");
	}

	@Override
	public List<GiftCardVO> listGet() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace + ".listGet");
	}

	@Override
	public List<GiftCardUseVO> listUse() {
		// TODO Auto-generated method stub
		return session.selectList(namespace + ".listUse");
	}

}
