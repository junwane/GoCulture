package go.culture.service;

import java.util.List;

import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;
import go.culture.domain.ReviewQuestionVO;

public interface CultureEventService {
		
	public void						register(CultureEventVO vo) 											throws Exception;
	
	public void						detailedPoster(DetailedPosterVO vo)										throws Exception;
	
	public CultureEventVO			culNo()																	throws Exception;
	
	public CultureEventVO 			read(int cul_no)														throws Exception;
	
	public List<DetailedPosterVO> 	dpRead(int cul_no)														throws Exception;
	
	public List<CultureEventVO>		cateInner(int cate_no, int filter, double latitude, double hardness)	throws Exception;

	public List<CultureEventVO> listSearch(String search);
	
	public void						rqRegister(ReviewQuestionVO vo)											throws Exception;
	
	public List<ReviewQuestionVO>	rqRead(int cul_no)														throws Exception;
	
}
