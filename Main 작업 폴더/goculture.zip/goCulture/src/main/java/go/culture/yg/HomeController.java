package go.culture.yg;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.StringTokenizer;

import javax.annotation.Resource;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import go.culture.domain.Criteria;
import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;
import go.culture.domain.GiftCardUseVO;
import go.culture.domain.GiftCardVO;
import go.culture.domain.ListVO;
import go.culture.domain.MemberVO;
import go.culture.domain.NoticeVO;
import go.culture.domain.PageMaker;
import go.culture.domain.PointVO;
import go.culture.domain.ReviewQuestionVO;
import go.culture.domain.TicketingVO;
import go.culture.email.MailService;
import go.culture.service.CultureEventService;
import go.culture.service.GiftCardService;
import go.culture.service.ListService;
import go.culture.service.MemberService;
import go.culture.service.NoticeService;
import go.culture.service.PointService;
import go.culture.service.TicketingService;
import go.culture.utils.MediaUtils;
import go.culture.utils.UploadFileUtils;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Inject
	private CultureEventService ceService;
	
	@Inject
	private GiftCardService gcService;

	@Inject
	private PointService pService;
	
	@Inject
	private ListService liService;
	
	@Inject
	private MemberService mService;
	
	@Inject
	private TicketingService tService;
	
	@Inject
	private NoticeService nService;
	
	@Inject
    private MailService mailService;
	
	@Resource(name="juploadPath")
	private String uploadPath;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@ResponseBody
	   @RequestMapping("/displayFile") 
	   public ResponseEntity<byte[]> displayFile(String fileName) throws Exception {
	      // ������ ������ �ٿ�ε��ϱ� ���� ��Ʈ��
	      InputStream in = null; // java.io
	      ResponseEntity<byte[]> entity = null;
	      
	      System.out.println("Display FILE NAME : " + fileName);
	      
	      try {
	         // Ȯ���ڸ� �����Ͽ� formatName�� ����
	         String formatName = fileName.substring(fileName.lastIndexOf(".")+1);
	         
	         // ������ Ȯ���ڸ� MediaUtilsŬ��������  �̹������Ͽ��θ� �˻��ϰ� ���Ϲ޾� mType�� ����
	         MediaType mType = MediaUtils.getMediaType(formatName);
	         
	         // ��� ���� ��ü(�ܺο��� �����͸� �ְ����� ������ header�� body�� �����ؾ��ϱ� ������)
	         HttpHeaders headers = new HttpHeaders();
	         
	          // InputStream ����
	         in = new FileInputStream(uploadPath+fileName);
	         
	         if(mType != null) { // �̹��� �����϶� 
	            headers.setContentType(mType);
	         } else { // �̹��������� �ƴҶ�
	            fileName = fileName.substring(fileName.indexOf("_")+1);
	            
	            // �ٿ�ε�� ����Ʈ Ÿ������ application/octet-stream 
	            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	            
	            // ����Ʈ�迭�� ��Ʈ������ : 
	            // new String(fileName.getBytes("utf-8"),"iso-8859-1") * iso-8859-1 ���������, ū ����ǥ ���ο�  " \" ���� \" "
	                // ������ �ѱ� ���� ����
	            headers.add("Content-Disposition", "attachment; filename=\"" + 
	               new String(fileName.getBytes("UTF-8"), "ISO-8859-1")+"\""); 
	            //headers.add("Content-Disposition", "attachment; filename='"+fileName+"'");
	         }
	         
	         // ����Ʈ �迭, ���, HTTP �����ڵ� 
	         // ������Ͽ��� �����͸� �о�� IOUtils�� toByteArray()�޼ҵ� 
	         entity = new ResponseEntity<byte[]>(IOUtils.toByteArray(in), headers, HttpStatus.CREATED); 
	            
	      } catch(Exception e) {
	         e.printStackTrace();
	         
	         // HTTP���� �ڵ�()
	         entity = new ResponseEntity<byte[]>(HttpStatus.BAD_REQUEST);
	      } finally {
	         in.close();
	      }
	      return entity;
	   }
	   
	   
	
	@RequestMapping(value = "/headerAf")
	public String headerAf(){
		return "headerAf";
	}
	
	@RequestMapping(value = "/headerBe")
	public String headerBe(){
		return "headerBe";
	}
	
	@RequestMapping(value = "/notification")
	public String notification(){
		return "notification";
	}
	
	@ResponseBody
	@RequestMapping(value = "/Chcate", method = RequestMethod.GET)
	public HashMap<String, Object> Chcate(int cate_no, int filter, double latitude, double hardness)throws Exception{
		HashMap<String, Object> map = new HashMap<>();
		map.put("ceList", ceService.cateInner(cate_no, filter, latitude ,hardness));
		return map;
	}
	
	@RequestMapping(value = "/cateInner", method = RequestMethod.GET)
	public void cateInner(@RequestParam("cate_no") int cate_no, @RequestParam("filter") int filter, @RequestParam("latitude") double latitude, @RequestParam("hardness") double hardness, Model model)throws Exception{
		List<CultureEventVO> ceList = ceService.cateInner(cate_no,filter,latitude,hardness);
		model.addAttribute("ceList",ceList);
	}
	
	@RequestMapping(value = "/confirmPassword",method = RequestMethod.GET)
	public String confirmPasswordGET(String m_password){
		return "confirmPassword";
	}
	@RequestMapping(value = "/confirmPassword",method = RequestMethod.POST)
	public void confirmPasswordPOST(@RequestParam("m_password") String m_password,HttpServletResponse response, HttpSession session) throws Exception{
		String personJson;
		int m_no = (int)session.getAttribute("m_no");
	    String pw = mService.checkPw(m_password,m_no);
		if(pw!=null) {
			personJson="true";
		} else{
	        personJson = "null";
	    }
	    try {
	        response.getWriter().print(personJson);
	    } catch (IOException e) {
	        e.printStackTrace();
	    } 
	}
	
	@RequestMapping(value = "/eventDetail", method = RequestMethod.GET)
	public void eventDetail(@RequestParam("cul_no") int cul_no, Model model,GiftCardVO gcVO, HttpSession session)throws Exception{
		int m_no;
		if(session.getAttribute("m_no") != null){
			m_no =(int)session.getAttribute("m_no");
		}else{
			m_no = 0;
		}
		
		model.addAttribute("ceVO",ceService.read(cul_no));
		List<DetailedPosterVO> dpImg = ceService.dpRead(cul_no);
		model.addAttribute("dpImg",dpImg);
		List<ReviewQuestionVO> rqVO = ceService.rqRead(cul_no);
		model.addAttribute("rqVO", rqVO);

		String totalPoint = pService.totalPoint(m_no);
		model.addAttribute("totalPoint", totalPoint);
		
		List<GiftCardVO> extraGCList = gcService.extraGCList(m_no);
		model.addAttribute("extraGCList", extraGCList);
	}
	
	@ResponseBody
	@RequestMapping(value = "/rqRegister", method = RequestMethod.POST)
	public String rqRegister(ReviewQuestionVO rqVO)throws Exception{
		ceService.rqRegister(rqVO);
		
		return "success";
	}
	
	@RequestMapping(value = "/eventRegister", method = RequestMethod.GET)
	public String eventRegisterGET(){
		return "eventRegister";
	}
	
	@RequestMapping(value = "/eventRegister", method = RequestMethod.POST)
	public String eventRegisterPOST(CultureEventVO ceVO, DetailedPosterVO dpVO)throws Exception{
		String cul_mainImg = ceVO.getCul_mainImg().substring(3);
		
		ceVO.setCul_mainImg(cul_mainImg);
		
		ceService.register(ceVO);
		
		int cul_no = ceService.culNo().getCul_no();
		
		if(dpVO.getDp_detailedImg() != null){
			dpVO.setCul_no(cul_no);

			StringTokenizer dpImg = new StringTokenizer(dpVO.getDp_detailedImg(),",");
			
			for(int x = 1; dpImg.hasMoreTokens(); x++){
				String dp_dpImg = dpImg.nextToken().substring(3);
				
				dpVO.setDp_detailedImg(dp_dpImg);
				
				ceService.detailedPoster(dpVO);
			}
		}
		return "redirect:/eventDetail?cul_no="+cul_no;
	}
	
	@RequestMapping(value = "/cul_mainImg", method = RequestMethod.POST, produces="text/plain;charset=UTF-8")
	public ResponseEntity<String> cul_mainImg(MultipartFile file) throws Exception{
		return new ResponseEntity<String>(UploadFileUtils.uploadFile(uploadPath, file.getOriginalFilename(), file.getBytes()), HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/imgRemove", method = RequestMethod.POST)
	public ResponseEntity<String> imgRemove(String fileName) {

		logger.info("delete file : " + fileName);

		// ������ Ȯ���� ����
		String formatName = fileName.substring(fileName.lastIndexOf(".") + 1);

		// �̹��� ���� ���� �˻�
		MediaType mType = MediaUtils.getMediaType(formatName);

		// �̹����� ���(����� + �������� ����), �̹����� �ƴϸ� �������ϸ� ����
		// �̹��� �����̸�
		if (mType != null) {
			String che = "/" + fileName.substring(3);
			// ����� �̹��� ����

			new File(uploadPath + (che).replace('/', File.separatorChar)).delete();
		}
		// ���� ���� ����

		new File(uploadPath + fileName.replace('/', File.separatorChar)).delete();

		// �����Ϳ� http ���� �ڵ� ����
		return new ResponseEntity<String>("deleted", HttpStatus.OK);

	}
	
	@RequestMapping(value = "/findId", method = RequestMethod.GET)
	public String findId(){
		return "findId";
	}
	
	@RequestMapping(value = "/findId", method = RequestMethod.POST)
	public @ResponseBody String findIdPOST(String name, int residentNum) throws Exception {

			String email = mService.findId(name,residentNum);
		    return email;
	}
	
	@RequestMapping(value = "/findPw")
	public String findPw(){
		return "findPw";
	}
	
	@RequestMapping(value = "/giftCard", method = RequestMethod.GET)
	public void giftCard(Model model, HttpSession session) throws Exception {
		int m_no = (int) session.getAttribute("m_no");
		List<GiftCardVO> listSend = gcService.listSend(m_no);
		List<GiftCardVO> listGet = gcService.listGet(m_no);
		List<GiftCardUseVO> listUse = gcService.listUse(m_no);
		model.addAttribute("listSend", listSend);
		model.addAttribute("listGet", listGet);
		model.addAttribute("listUse", listUse);
		
	}
	
	@RequestMapping(value = "/myEventList")
	public void myEventList(Model model,HttpSession session) throws Exception {
		System.out.println(session.getAttribute("m_no"));
		int m_no = (int) session.getAttribute("m_no");
		List<ListVO> listHeart = liService.listHeart(m_no);
		List<ListVO> listHeartDate = liService.listHeartDate(m_no);
		List<ListVO> listReservation = liService.listReservation(m_no);
		List<ListVO> listReservationDate = liService.listReservationDate(m_no);
		List<ListVO> listGone = liService.listGone(m_no);
		List<ListVO> listGone1mon = liService.listGone1mon(m_no);
		List<ListVO> listGone3mon = liService.listGone3mon(m_no);
		List<ListVO> listGone6mon = liService.listGone6mon(m_no);
		
		model.addAttribute("listHeart",listHeart);
		model.addAttribute("listHeartDate",listHeartDate);
		model.addAttribute("listReservation",listReservation);
		model.addAttribute("listReservationDate",listReservationDate);
		model.addAttribute("listGone",listGone);
		model.addAttribute("listGone1mon",listGone1mon);
		model.addAttribute("listGone3mon",listGone3mon);
		model.addAttribute("listGone6mon",listGone6mon);
	}
	
	@RequestMapping(value = "/main")
	public String main(Model model) throws Exception{
		List<CultureEventVO> imminentEvent = ceService.imminentEvent();
		model.addAttribute("imminentEvent",imminentEvent);
		
		return "main";
	}
	
	@RequestMapping(value = "/memberInfo", method = RequestMethod.GET)
	public void memberInfoGET(Model model,HttpSession session) throws Exception {
		int m_no = (int)session.getAttribute("m_no");
		List<MemberVO> listMyInfo = mService.listMyInfo(m_no);
		
		model.addAttribute("listMyInfo",listMyInfo);
	}
	
	@RequestMapping(value = "/memberInfo", method = RequestMethod.POST)
	public void memberInfoPOST(String pw, HttpSession session) throws Exception {
		int m_no = (int)session.getAttribute("m_no");
		mService.changePw(pw,m_no);
	}
	
	@RequestMapping(value = "/deleteMember", method = RequestMethod.POST)
	public String deleteMember(HttpSession session) throws Exception {
		int m_no = (int)session.getAttribute("m_no");
		mService.delete(m_no);
		return "main";
	}
	
	
	@RequestMapping(value = "/giftCardSend", method = RequestMethod.GET)
	public void giftCardSend() throws Exception {
	}

	@RequestMapping(value = "/giftCardSend", method = RequestMethod.POST)
	public String giftCardSend(GiftCardVO vo) throws Exception {
		gcService.sendGiftCard(vo);
		return "redirect:giftCard";
	}
	
	//�������� ����Ʈ
	@RequestMapping(value = "/noticeBoard")
	public void noticeBoard(Criteria cri,Model model)throws Exception{
		model.addAttribute("list",nService.listCriteria(cri));
		PageMaker pageMaker = new PageMaker();
		pageMaker.setCri(cri);
		pageMaker.setTotalCount(nService.listCountCriteria(cri));

		model.addAttribute("pageMaker",pageMaker);
	}
	
	@RequestMapping(value="/noticeBoardInner",method = RequestMethod.GET)//���� �Ұ����� �������� ���� 
	public void read(@RequestParam("nb_no") int nb_no, @ModelAttribute("cri") Criteria cri, Model model)throws Exception{
		NoticeVO NoticeVO = nService.read(nb_no);
		model.addAttribute("NoticeVO",NoticeVO);
	}
	
	@RequestMapping(value = "/nonMemEventList", method= RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	public void nonMemEventList(Model model, TicketingVO vo) throws Exception{
		int nm_no = tService.getnmNo(vo);
		List<ListVO> listNon = liService.listNon(nm_no);
	      model.addAttribute("listNon", listNon);
	}
	
	@RequestMapping(value = "/nonMemEventListClick", method= RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	public String nonMemEventList(Model model, String nm_name, int t_no) throws Exception{
		List<ListVO> listNonClick = liService.listNonClick(nm_name, t_no);
	      model.addAttribute("listNon", listNonClick);
	      return "nonMemEventList";
	}
	
	@RequestMapping(value="/mknoticeBoard",method = RequestMethod.GET)//���� �۾��� �������� �̵�
	public void registerGet(NoticeVO notice, Model model) throws Exception{
	}
	
	//�������� �ۼ�
	@RequestMapping(value="/register",method = RequestMethod.POST)
	public String registerPOST(NoticeVO notice, Model model) throws Exception{
	   nService.regist(notice);
	   model.addAttribute("msg","success");
   	   return "redirect:noticeBoard";   
	}
	
	//�������� ����
	@RequestMapping(value="/remove", method=RequestMethod.POST)
	public String remove(@RequestParam("nb_no")int nb_no, RedirectAttributes rttr)throws Exception{
		nService.delete(nb_no);
		rttr.addFlashAttribute("msg","SUCCESS");
		return "redirect:noticeBoard";
	}
	//�������� ����
	@RequestMapping(value ="/noticeBoardModi",method =RequestMethod.GET)
	   public void modifyGET(int nb_no,Model model)throws Exception{
		NoticeVO NoticeVO = nService.read(nb_no);
		model.addAttribute("NoticeVO",NoticeVO);
	}
	
	//�������� ����
	@RequestMapping(value="/noticeBoardModi",method = RequestMethod.POST)
	   public String modifyPOST(NoticeVO notice, RedirectAttributes rttr) throws Exception{
	   nService.update(notice);
	   rttr.addFlashAttribute("msg","SUCCESS");
	   return "redirect:noticeBoard"; 
	}
	
	//�������� ���������̼�
	@RequestMapping(value="/listCri",method =RequestMethod.GET)
	public void listAll(Criteria cri,Model model)throws Exception{
		model.addAttribute("list",nService.listCriteria(cri));
	}	
	
	@RequestMapping(value = "/nonMemEventList", method= RequestMethod.GET, produces = "text/plain; charset=UTF-8")
	public void nonMemEventListGET(Model model, HttpSession session) throws Exception{
		int nm_no = (int)session.getAttribute("nm_no");
		List<ListVO> listNon = liService.listNon(nm_no);
	      model.addAttribute("listNon", listNon);
	}

	@RequestMapping(value = "/nonMemTicketing", method = RequestMethod.POST)
	public @ResponseBody String nonMemTicketingPOST(String email,TicketingVO vo, HttpSession session) throws Exception {
		tService.insertNon(vo);
		tService.insertNonTicketing(vo);
		int nm_no = tService.getnmNo(vo);
        session.setAttribute("nm_no", nm_no);
        logger.info(email);
        if(email!=null) {
        	String t_no = String.valueOf(tService.gettNo(vo));
	 
	        String subject = "Go!Culture ��ȸ�� ���Ź�ȣ ���� �����Դϴ�.";
	        String joinText = "�������� ���Ź�ȣ�� " + t_no + " �Դϴ�.<br>���Ź�ȣ�� ���ų��� Ȯ�� �ÿ� �̿�˴ϴ�.";
	        mailService.send(subject, joinText , "pjw941021@gmail.com", email);
	        return email;
        }
		return "success";
	}
	
	@RequestMapping(value = "/reservePeople", method = RequestMethod.POST)
	public @ResponseBody List<TicketingVO> reservePeople(int cul_no) throws Exception {
			//String personJson;
			
			List<TicketingVO> reservePeople = tService.reservePeople(cul_no);
		    return reservePeople;
	}
	
	@RequestMapping(value = "/reservePeopleNon", method = RequestMethod.POST)
	public @ResponseBody List<TicketingVO> reservePeopleNon(int cul_no) throws Exception {
			//String personJson;
			
			List<TicketingVO> reservePeopleNon = tService.reservePeopleNon(cul_no);
		    return reservePeopleNon;
	}
	
	@RequestMapping(value = "/searchT", method = RequestMethod.POST)
	public @ResponseBody List<TicketingVO> searchT(int t_no) throws Exception {
			//String personJson;
			
			List<TicketingVO> searchT = tService.searchT(t_no);
		    return searchT;
	}
	
	@RequestMapping(value = "/searchEmail", method = RequestMethod.POST)
	public @ResponseBody List<MemberVO> searchEmailPOST(String search) throws Exception {
			//String personJson;
			
			List<MemberVO> listEmail = mService.listEmail(search);
		    return listEmail;
	}
	@RequestMapping(value = "/searchEmail", method = RequestMethod.GET)
	public String searchEmailGET(Model model, String email) throws Exception {
		return "giftCardSend";
	}
	
	@RequestMapping(value = "/point", method = RequestMethod.GET)
	public void point(Model model, HttpSession session) throws Exception {
		int m_no = (int) session.getAttribute("m_no");
		List<PointVO> addPoint = pService.listAddPoint();
		List<PointVO> usePoint = pService.listUsePoint(m_no);
		model.addAttribute("addPoint", addPoint);
		model.addAttribute("usePoint", usePoint);
	}
	
//���ϱ�
	@RequestMapping(value = "/interestEvent", method = RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	public @ResponseBody String interestEvent(int cul_no,HttpSession session) throws Exception {
		int m_no = (int) session.getAttribute("m_no");
		tService.interestEvent(cul_no,m_no);
		return "success";
	}
	
	
	@RequestMapping(value = "/search", method = RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	public @ResponseBody HashMap<String, Object> searchPOST(String cul_title, int filter) throws Exception {
		HashMap<String, Object> map = new HashMap<>();
		map.put("ceList", ceService.listSearch(cul_title, filter));
		return map;
	}

	@RequestMapping(value = "/search", method = RequestMethod.GET, produces = "text/plain; charset=UTF-8")
	public String searchGET(Model model, String cul_title, int filter) throws Exception {
		List<CultureEventVO> listSearch = ceService.listSearch(cul_title,filter);
		model.addAttribute("listSearch",listSearch);
		if(listSearch.size()==0) {
			return "searchFail";
		}else {
			return "search";
		}
	}
	
	@RequestMapping(value="/memTicketing", method = RequestMethod.POST, produces = "text/plain; charset=UTF-8")
	public @ResponseBody String memTicketingPOST(TicketingVO vo,PointVO pvo, GiftCardVO gvo) throws Exception {
		
		if(pvo.getP_point() != 0){
			pService.usePoint(pvo);
		}
		if(gvo.getGcu_point() != 0){
			gcService.useGiftCard(gvo);
		}
		
		tService.insert(vo);
		
		return "success";
	}
	
	@RequestMapping(value = "/nonMemChk")
	public void nonMemChk() {
		
	}
	public void setMailService(MailService mailService) {
        this.mailService = mailService;
    }
	// �ӽ� ��й�ȣ ����
	@ResponseBody
    @RequestMapping(value = "/mailSendingPw", method = RequestMethod.POST)
    public String sendMailAuth(String email, String name, int residentNum) throws Exception {
		int m_no = mService.findPw(name, residentNum,email);
		
        int ran = new Random().nextInt(100000) + 10000; // 10000 ~ 99999
        String m_password = String.valueOf(ran);
 
        String subject = "Go!Culture �ӽ� ��й�ȣ �߼� �����Դϴ�.";
        String joinText = "�ӽ� ��й�ȣ�� " + m_password + " �Դϴ�.<br>�������� ȸ�� �������� ��й�ȣ�� �������ּ���.";
        mService.changePw(m_password,m_no);
        mailService.send(subject, joinText , "pjw941021@gmail.com", email);
 
        return m_password;
    }
		
}
