package go.culture.yg;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.StringTokenizer;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;
import go.culture.service.CultureEventService;
import go.culture.utils.MediaUtils;
import go.culture.utils.UploadFileUtils;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Inject
	private CultureEventService ceService;
	
	@Resource(name="juploadPath")
	private String uploadPath;
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@ResponseBody
	   @RequestMapping("/displayFile") 
	   public ResponseEntity<byte[]> displayFile(String fileName) throws Exception {
	      // ������ ������ �ٿ�ε��ϱ� ���� ��Ʈ��
	      InputStream in = null; // java.io
	      ResponseEntity<byte[]> entity = null;
	      
	      System.out.println("Display FILE NAME : " + fileName);
	      
	      try {
	         // Ȯ���ڸ� �����Ͽ� formatName�� ����
	         String formatName = fileName.substring(fileName.lastIndexOf(".")+1);
	         
	         // ������ Ȯ���ڸ� MediaUtilsŬ��������  �̹������Ͽ��θ� �˻��ϰ� ���Ϲ޾� mType�� ����
	         MediaType mType = MediaUtils.getMediaType(formatName);
	         
	         // ��� ���� ��ü(�ܺο��� �����͸� �ְ����� ������ header�� body�� �����ؾ��ϱ� ������)
	         HttpHeaders headers = new HttpHeaders();
	         
	          // InputStream ����
	         in = new FileInputStream(uploadPath+fileName);
	         
	         if(mType != null) { // �̹��� �����϶� 
	            headers.setContentType(mType);
	         } else { // �̹��������� �ƴҶ�
	            fileName = fileName.substring(fileName.indexOf("_")+1);
	            
	            // �ٿ�ε�� ����Ʈ Ÿ������ application/octet-stream 
	            headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
	            
	            // ����Ʈ�迭�� ��Ʈ������ : 
	            // new String(fileName.getBytes("utf-8"),"iso-8859-1") * iso-8859-1 ���������, ū ����ǥ ���ο�  " \" ���� \" "
	                // ������ �ѱ� ���� ����
	            headers.add("Content-Disposition", "attachment; filename=\"" + 
	               new String(fileName.getBytes("UTF-8"), "ISO-8859-1")+"\""); 
	            //headers.add("Content-Disposition", "attachment; filename='"+fileName+"'");
	         }
	         
	         // ����Ʈ �迭, ���, HTTP �����ڵ� 
	         // ������Ͽ��� �����͸� �о�� IOUtils�� toByteArray()�޼ҵ� 
	         entity = new ResponseEntity<byte[]>(IOUtils.toByteArray(in), headers, HttpStatus.CREATED); 
	            
	      } catch(Exception e) {
	         e.printStackTrace();
	         
	         // HTTP���� �ڵ�()
	         entity = new ResponseEntity<byte[]>(HttpStatus.BAD_REQUEST);
	      } finally {
	         in.close();
	      }
	      return entity;
	   }
	
	@RequestMapping(value = "/headerAf")
	public String headerAf(){
		return "headerAf";
	}
	
	@RequestMapping(value = "/headerBe")
	public String headerBe(){
		return "headerBe";
	}
	
	@RequestMapping(value = "/notification")
	public String notification(){
		return "notification";
	}
	
	@RequestMapping(value = "/cateInner", method = RequestMethod.GET)
	public void cateInner(@RequestParam("cate_no") int cate_no, Model model)throws Exception{
		List<CultureEventVO> ceList = ceService.cateInner(cate_no,1);
		model.addAttribute("ceList",ceList);
	}
	
	@RequestMapping(value = "/page_confirmpassword")
	public String page_confirmpassword(){
		return "page_confirmpassword";
	}
	
	@RequestMapping(value = "/eventDetail", method = RequestMethod.GET)
	public void eventDetail(@RequestParam("cul_no") int cul_no, Model model)throws Exception{
		model.addAttribute("ceVO",ceService.read(cul_no));
		List<DetailedPosterVO> dpImg = ceService.dpRead(cul_no);
		model.addAttribute("dpImg",dpImg);
	}
	
	@RequestMapping(value = "/eventRegister", method = RequestMethod.GET)
	public String eventRegisterGET(){
		return "eventRegister";
	}
	
	@RequestMapping(value = "/eventRegister", method = RequestMethod.POST)
	public String eventRegisterPOST(CultureEventVO ceVO, DetailedPosterVO dpVO)throws Exception{
		
		String cul_mainImg = ceVO.getCul_mainImg().substring(3);
		
		ceVO.setCul_mainImg(cul_mainImg);
		
		ceService.register(ceVO);
		
		int cul_no = ceService.culNo().getCul_no();
		
		if(dpVO.getDp_detailedImg() != null){
			dpVO.setCul_no(cul_no);

			StringTokenizer dpImg = new StringTokenizer(dpVO.getDp_detailedImg(),",");
			
			for(int x = 1; dpImg.hasMoreTokens(); x++){
				String dp_dpImg = dpImg.nextToken().substring(3);
				
				dpVO.setDp_detailedImg(dp_dpImg);
				
				ceService.detailedPoster(dpVO);
			}
		}
		
		return "redirect:/eventDetail?cul_no="+cul_no;
	}
	
	@RequestMapping(value = "/cul_mainImg", method = RequestMethod.POST, produces="text/plain;charset=UTF-8")
	public ResponseEntity<String> cul_mainImg(MultipartFile file) throws Exception{
		return new ResponseEntity<String>(UploadFileUtils.uploadFile(uploadPath, file.getOriginalFilename(), file.getBytes()), HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/imgRemove", method = RequestMethod.POST)
	public ResponseEntity<String> imgRemove(String fileName) {

		logger.info("delete file : " + fileName);

		// ������ Ȯ���� ����
		String formatName = fileName.substring(fileName.lastIndexOf(".") + 1);

		// �̹��� ���� ���� �˻�
		MediaType mType = MediaUtils.getMediaType(formatName);

		// �̹����� ���(����� + �������� ����), �̹����� �ƴϸ� �������ϸ� ����
		// �̹��� �����̸�
		if (mType != null) {
			String che = "/" + fileName.substring(3);
			// ����� �̹��� ����

			new File(uploadPath + (che).replace('/', File.separatorChar)).delete();
		}
		// ���� ���� ����

		new File(uploadPath + fileName.replace('/', File.separatorChar)).delete();

		// �����Ϳ� http ���� �ڵ� ����
		return new ResponseEntity<String>("deleted", HttpStatus.OK);

	}
	
	@RequestMapping(value = "/findId")
	public String findId(){
		return "findId";
	}
	
	@RequestMapping(value = "/findPw")
	public String findPw(){
		return "findPw";
	}
	
	@RequestMapping(value = "/giftCard")
	public String giftCard(){
		return "giftCard";
	}
	
	@RequestMapping(value = "/page_gone")
	public String page_gone(){
		return "page_gone";
	}
	
	@RequestMapping(value = "/page_heart")
	public String page_heart(){
		return "page_heart";
	}
	
	@RequestMapping(value = "/main")
	public String main(){
		return "main";
	}
	
	@RequestMapping(value = "/memberInfo")
	public String memberInfo(){
		return "memberInfo";
	}
	
	@RequestMapping(value = "/giftCardSend")
	public String giftCardSend(){
		return "giftCardSend";
	}
	
	@RequestMapping(value = "/noticeBoard")
	public String noticeBoard(){
		return "noticeBoard";
	}
	
	@RequestMapping(value = "/nonMemEventList")
	public String nonMemEventList(){
		return "nonMemEventList";
	}
	
	@RequestMapping(value = "/nonMemTicketing")
	public String nonMemTicketing(){
		return "nonMemTicketing";
	}
	
	@RequestMapping(value = "/point")
	public String point(){
		return "point";
	}
	
	@RequestMapping(value = "/page_reservation")
	public String page_reservation(){
		return "page_reservation";
	}
	
	@RequestMapping(value = "/search")
	public String search(){
		return "search";
	}
	
	@RequestMapping(value = "/memTicketing")
	public String memTicketing(){
		return "memTicketing";
	}
	
}
