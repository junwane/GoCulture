package go.culture.dao;

import java.util.List;

import go.culture.domain.PointVO;

public interface PointDAO {
	public List<PointVO> listAddPoint() throws Exception;
	
	public List<PointVO> listUsePoint() throws Exception;
	
	public void usePoint(PointVO vo);
}
