package go.culture.dao;

import java.util.List;

import go.culture.domain.PointVO;

public interface PointDAO {
	public List<PointVO> listAddPoint() throws Exception;
	
	public List<PointVO> listUsePoint(int m_no) throws Exception;
	
	public void usePoint(PointVO vo);
	
	public int totalPoint(int m_no)throws Exception;
}
