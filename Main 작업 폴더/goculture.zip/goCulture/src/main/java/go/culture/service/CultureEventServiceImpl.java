package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.CultureEventDAO;
import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;

@Service
public class CultureEventServiceImpl implements CultureEventService {

	@Inject
	private CultureEventDAO dao;
	
	@Override
	public void register(CultureEventVO vo) throws Exception {
		// TODO Auto-generated method stub
		dao.register(vo);
	}

	@Override
	public void detailedPoster(DetailedPosterVO vo) throws Exception {
		// TODO Auto-generated method stub
		dao.detailedPoster(vo);
	}

	@Override
	public CultureEventVO culNo() throws Exception {
		// TODO Auto-generated method stub
		return dao.culNo();
	}

	@Override
	public CultureEventVO read(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.read(cul_no);
	}

	@Override
	public List<DetailedPosterVO> dpRead(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.dpRead(cul_no);
	}

	@Override
	public List<CultureEventVO> cateInner(int cate_no, int filter, double latitude, double hardness) throws Exception {
		// TODO Auto-generated method stub
		return dao.cateInner(cate_no, filter, latitude, hardness);
	}

}
