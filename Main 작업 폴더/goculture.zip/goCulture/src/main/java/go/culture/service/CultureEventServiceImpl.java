package go.culture.service;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.CultureEventDAO;
import go.culture.domain.CultureEventVO;

@Service
public class CultureEventServiceImpl implements CultureEventService {

	@Inject
	private CultureEventDAO dao;
	
	@Override
	public void register(CultureEventVO vo) throws Exception {
		// TODO Auto-generated method stub
		dao.register(vo);
	}

}
