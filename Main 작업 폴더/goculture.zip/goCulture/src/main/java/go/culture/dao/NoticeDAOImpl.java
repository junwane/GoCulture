package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.Criteria;
import go.culture.domain.NoticeVO;

@Repository
public class NoticeDAOImpl implements NoticeDAO {

	@Inject
	private SqlSession session;

	private static String NAMESPACE = "go.culture.mapper.NoticeMapper";

	@Override
	public void create(NoticeVO vo) throws Exception {
		
		session.insert(NAMESPACE+".create",vo);
		// TODO Auto-generated method stub��
		
	}

	@Override
	public NoticeVO read(Integer nb_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+".read",nb_no);
		
	}

	@Override
	public void update(NoticeVO notice) throws Exception {
		// TODO Auto-generated method stub
		session.update(NAMESPACE+".update",notice);
	}

	@Override
	public void delete(Integer nb_no) throws Exception {
		// TODO Auto-generated method stub
		session.insert(NAMESPACE+".delete",nb_no);
		
	}

	@Override
	public List<NoticeVO> listAll() throws Exception {
		
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+".listAll");
	}

	public List<NoticeVO> noticeBoard(int page) throws Exception {
		// TODO Auto-generated method stub
		if(page<=0) {
			page =1;
		}
		page=(page-1)*10;
	
	return session.selectList(NAMESPACE+".noticeBoard",page);
	}

	@Override
	public List<NoticeVO> listCriteria(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(NAMESPACE+".listCriteria",cri);
	}

	@Override
	public int countPaging(Criteria cri) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(NAMESPACE+".countPaging",cri);
	}

	
	

}
