package go.culture.domain;

public class ReviewQuestionVO {
	private int		rq_no;
	private int		cul_no;
	private int		m_no;
	private String	rq_title;
	private String	rq_content;
	private String	rq_img;
	private String	rq_open;
	private String	rq_division;
	private String	rq_register;
	
	public int getRq_no() {
		return rq_no;
	}
	public void setRq_no(int rq_no) {
		this.rq_no = rq_no;
	}
	public int getCul_no() {
		return cul_no;
	}
	public void setCul_no(int cul_no) {
		this.cul_no = cul_no;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getRq_title() {
		return rq_title;
	}
	public void setRq_title(String rq_title) {
		this.rq_title = rq_title;
	}
	public String getRq_content() {
		return rq_content;
	}
	public void setRq_content(String rq_content) {
		this.rq_content = rq_content;
	}
	public String getRq_img() {
		return rq_img;
	}
	public void setRq_img(String rq_img) {
		this.rq_img = rq_img;
	}
	public String getRq_open() {
		return rq_open;
	}
	public void setRq_open(String rq_open) {
		this.rq_open = rq_open;
	}
	public String getRq_division() {
		return rq_division;
	}
	public void setRq_division(String rq_division) {
		this.rq_division = rq_division;
	}
	
	public String getRq_register() {
		return rq_register;
	}
	public void setRq_register(String rq_register) {
		this.rq_register = rq_register;
	}
	public String toString(){
		return 		"rq_no"			+ rq_no
				+	"cul_no"		+ cul_no
				+	"m_no"			+ m_no
				+	"rq_title"		+ rq_title
				+	"rq_content"	+ rq_content
				+	"rq_img"		+ rq_img
				+	"rq_open"		+ rq_open
				+	"rq_division"	+ rq_division
				+	"rq_register"	+ rq_register;
				
	}
}
