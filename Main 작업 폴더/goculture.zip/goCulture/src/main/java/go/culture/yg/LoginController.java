package go.culture.yg;


import java.util.Random;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import go.culture.domain.MemberVO;
import go.culture.email.MailService;
import go.culture.service.JoinService;




@Controller
public class LoginController {
	
	
	@Inject
	private JoinService join;
	
	@Inject
    private MailService mailService;
 
    public void setMailService(MailService mailService) {
        this.mailService = mailService;
    }

	@RequestMapping(value="/singUp", method=RequestMethod.GET)
	public String joinGET() throws Exception{
		return "singUp";
	}
	
    // ȸ������ �̸��� ����
	@ResponseBody
    @RequestMapping(value = "/mailSending", method = RequestMethod.POST)
    public String sendMailAuth(String email) {
        int ran = new Random().nextInt(100000) + 10000; // 10000 ~ 99999
        String joinCode = String.valueOf(ran);
 
        String subject = "ȸ������ ���� �ڵ� �߱� �ȳ� �Դϴ�.";
        String joinText = "���� �ڵ�� " + joinCode + " �Դϴ�.";
        mailService.send(subject, joinText , "pjw941021@gmail.com", email);
        
        return joinCode;
    }
	
	@RequestMapping(value="/singUp", method=RequestMethod.POST)
	public String joinPOST(MemberVO member) throws Exception{
		join.insert(member);
		
		return "redirect:main";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.GET)
	public String loginGET() throws Exception{
		return "login";
	}
	
	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String loginPOST(MemberVO member, @RequestParam("m_email") String m_email, @RequestParam("m_password") String m_password, HttpSession session) throws Exception{
		
		MemberVO m =  join.read(m_email);
	
		String mId = m.getM_email();
		String mPw = m.getM_password();

		if(mId.equals(m_email) && mPw.equals(m_password)) {

			session.setAttribute("m_no", m.getM_no());
			return "redirect:main";
		} else {
			return "redirect:login";
		}	
	}
}
