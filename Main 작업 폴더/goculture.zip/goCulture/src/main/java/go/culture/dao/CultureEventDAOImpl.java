package go.culture.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;
import go.culture.domain.ReviewQuestionVO;

@Repository
public class CultureEventDAOImpl implements CultureEventDAO {

	@Inject
	private SqlSession session;
	
	private static String namespace = "go.culture.mapper.cultureEventMapper";
	
	@Override
	public void register(CultureEventVO vo) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".register",vo);
	}

	@Override
	public void detailedPoster(DetailedPosterVO vo) throws Exception {
		// TODO Auto-generated method stub
		
		session.insert(namespace+".detailedPoster",vo);
	}

	@Override
	public CultureEventVO culNo() throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".culNo");
	}

	@Override
	public CultureEventVO read(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".read",cul_no);
	}

	@Override
	public List<DetailedPosterVO> dpRead(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".dpRead",cul_no);
	}

	@Override
	public List<CultureEventVO> cateInner(int cate_no, int filter, double latitude, double hardness) throws Exception {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("cate_no", cate_no);
		map.put("latitude", latitude);
		map.put("hardness", hardness);
		
		
		if(cate_no != 0){
			if(filter == 1){
				return session.selectList(namespace+".cateListf1",cate_no);
			}else if(filter == 2){
				return session.selectList(namespace+".cateListf2",map);
			}else{
				return session.selectList(namespace+".cateListf3",cate_no);
			}
		}else{
			if(filter == 1){
				return session.selectList(namespace+".cateListAllf1");
			}else if(filter ==2){
				return session.selectList(namespace+".cateListAllf2",map);
			}else{
				return session.selectList(namespace+".cateListAllf3");
			}
		}
	}

	@Override
	public List<CultureEventVO> listSearch(String cul_title) {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".listSearch",cul_title);
	}
	
	@Override
	public void rqRegister(ReviewQuestionVO vo) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".rqRegister",vo);
	}

	@Override
	public List<ReviewQuestionVO> rqRead(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".rqRead", cul_no);
	}

	@Override
	public String reservePeople(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".reservePeople", cul_no);
	}

	@Override
	public List<CultureEventVO> imminentEvent() throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".imminentEvent");
	}

}
