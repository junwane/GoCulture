package go.culture.dao;

import java.util.List;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;

@Repository
public class CultureEventDAOImpl implements CultureEventDAO {

	@Inject
	private SqlSession session;
	
	private static String namespace = "go.culture.mapper.cultureEventMapper";
	
	@Override
	public void register(CultureEventVO vo) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".register",vo);
	}

	@Override
	public void detailedPoster(DetailedPosterVO vo) throws Exception {
		// TODO Auto-generated method stub
		
		session.insert(namespace+".detailedPoster",vo);
	}

	@Override
	public CultureEventVO culNo() throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".culNo");
	}

	@Override
	public CultureEventVO read(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectOne(namespace+".read",cul_no);
	}

	@Override
	public List<DetailedPosterVO> dpRead(int cul_no) throws Exception {
		// TODO Auto-generated method stub
		return session.selectList(namespace+".dpRead",cul_no);
	}

	@Override
	public List<CultureEventVO> cateInner(int cate_no, int filter) throws Exception {
		// TODO Auto-generated method stub
		if(cate_no != 0){
			if(filter == 1){
				return session.selectList(namespace+".cateListf1",cate_no);
			}else if(filter == 2){
				return session.selectList(namespace+".cateListf2",cate_no);
			}else{
				return session.selectList(namespace+".cateListf3",cate_no);
			}
		}else{
			if(filter == 1){
				return session.selectList(namespace+".cateListAllf1");
			}else if(filter ==2){
				return session.selectList(namespace+".cateListAllf2");
			}else{
				return session.selectList(namespace+".cateListAllf3");
			}
		}
	}

}
