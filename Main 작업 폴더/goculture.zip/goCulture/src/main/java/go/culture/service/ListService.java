package go.culture.service;

import java.util.List;

import org.springframework.stereotype.Service;

import go.culture.domain.ListVO;

@Service
public interface ListService {
	public List<ListVO> listGone(int m_no) throws Exception;
	
	public List<ListVO> listGone1mon(int m_no) throws Exception;
	
	public List<ListVO> listGone3mon(int m_no) throws Exception;
	
	public List<ListVO> listGone6mon(int m_no) throws Exception;	

	public List<ListVO> listReservation(int m_no) throws Exception;
	
	public List<ListVO> listHeart(int m_no) throws Exception;
	
	public List<ListVO> listReservationDate(int m_no) throws Exception;
	
	public List<ListVO> listHeartDate(int m_no) throws Exception;
	
	public List<ListVO> listNon(int nm_no) throws Exception;
	
	public List<ListVO> listNonClick(String nm_name, int t_no) throws Exception;
	
}
