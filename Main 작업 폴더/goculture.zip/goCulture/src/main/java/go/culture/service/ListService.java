package go.culture.service;

import java.util.List;

import org.springframework.stereotype.Service;

import go.culture.domain.ListVO;

@Service
public interface ListService {
	public List<ListVO> listGone() throws Exception;
	
	public List<ListVO> listGone1mon() throws Exception;
	
	public List<ListVO> listGone3mon() throws Exception;
	
	public List<ListVO> listGone6mon() throws Exception;	

	public List<ListVO> listReservation() throws Exception;
	
	public List<ListVO> listHeart() throws Exception;
	
	public List<ListVO> listReservationDate() throws Exception;
	
	public List<ListVO> listHeartDate() throws Exception;
	
}
