package go.culture.dao;

import java.util.List;

import go.culture.domain.MemberVO;

public interface MemberDAO {
	public void changePw(String pw);
	
	public List<MemberVO> listMyInfo() throws Exception;
	
	public String checkPw(String m_password);
	
	public void delete();
	
	public List<MemberVO> listEmail(String search) throws Exception;
}
