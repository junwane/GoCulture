package go.culture.dao;

import java.util.List;

import go.culture.domain.MemberVO;

public interface MemberDAO {
	public void changePw(String m_password,int m_no);
	
	public List<MemberVO> listMyInfo(int m_no) throws Exception;
	
	public String checkPw(String m_password, int m_no);
		
	public void delete(int m_no);
	
	public List<MemberVO> listEmail(String search) throws Exception;
	
	public String findId(String name, int residentNum) throws Exception;
	
	public int findPw(String name, int residentNum, String email) throws Exception;
}
