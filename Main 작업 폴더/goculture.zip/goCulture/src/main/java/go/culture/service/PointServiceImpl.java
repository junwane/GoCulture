package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.PointDAO;
import go.culture.domain.PointVO;
@Service
public class PointServiceImpl implements PointService {

	@Inject
	private PointDAO dao;
	@Override
	public List<PointVO> listAddPoint() throws Exception {
		// TODO Auto-generated method stub
		return dao.listAddPoint();
	}

	@Override
	public List<PointVO> listUsePoint(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listUsePoint(m_no);
	}

	@Override
	public void usePoint(PointVO vo) {
		// TODO Auto-generated method stub
		dao.usePoint(vo);
	}

	@Override
	public int totalPoint(int m_no) throws Exception{
		// TODO Auto-generated method stub
		return  dao.totalPoint(m_no);
	}
}
