package go.culture.service;

import go.culture.domain.TicketingVO;

public interface TicketingService {
	public void insert(TicketingVO vo) throws Exception;
}
