package go.culture.service;

import go.culture.domain.TicketingVO;

public interface TicketingService {
	public void insert(TicketingVO vo) throws Exception;
	
	public void insertNon(TicketingVO vo)throws Exception;
	
	public void insertNonTicketing(TicketingVO vo)throws Exception;
	
	public int getnmNo(TicketingVO vo)throws Exception;
}
