package go.culture.dao;

import java.util.List;

import go.culture.domain.ListVO;

public interface ListDAO {
	public List<ListVO> listGone() throws Exception;
	
	public List<ListVO> listGone1mon() throws Exception;
	
	public List<ListVO> listGone3mon() throws Exception;
	
	public List<ListVO> listGone6mon() throws Exception;

	public List<ListVO> listReservation() throws Exception;
	
	public List<ListVO> listHeart() throws Exception;
	
	public List<ListVO> listReservationDate() throws Exception;
	
	public List<ListVO> listHeartDate() throws Exception;
}