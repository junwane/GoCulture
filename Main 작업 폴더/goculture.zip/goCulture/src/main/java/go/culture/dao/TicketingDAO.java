package go.culture.dao;

import java.util.List;

import go.culture.domain.TicketingVO;

public interface TicketingDAO {
	public void insert(TicketingVO vo) throws Exception;
	
	public void insertNon(TicketingVO vo)throws Exception;
	
	public void insertNonTicketing(TicketingVO vo)throws Exception;
	
	public int getnmNo(TicketingVO vo)throws Exception;
	
	public void interestEvent(int cul_no, int m_no) throws Exception;
	
	public int gettNo(TicketingVO vo) throws Exception;
	
	public List<TicketingVO> reservePeople(int cul_no) throws Exception;
	
	public List<TicketingVO> reservePeopleNon(int cul_no) throws Exception;
	
	public List<TicketingVO> searchT(int t_no) throws Exception;
}
