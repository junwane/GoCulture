package go.culture.dao;

import go.culture.domain.TicketingVO;

public interface TicketingDAO {
	public void insert(TicketingVO vo) throws Exception;
}
