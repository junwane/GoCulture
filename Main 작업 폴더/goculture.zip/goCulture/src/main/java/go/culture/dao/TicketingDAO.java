package go.culture.dao;

import java.util.List;

import go.culture.domain.TicketingVO;

public interface TicketingDAO {

	public TicketingVO read(Integer cul_no)throws Exception;
	
	public void create(TicketingVO ticketing)throws Exception;

	public List<TicketingVO> listAll()throws Exception;


	
 
}
