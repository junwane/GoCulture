package go.culture.dao;

import go.culture.domain.TicketingVO;

public interface TicketingDAO {
	public void insert(TicketingVO vo) throws Exception;
	
	public void insertNon(TicketingVO vo)throws Exception;
	
	public void insertNonTicketing(TicketingVO vo)throws Exception;
	
	public int getnmNo(TicketingVO vo)throws Exception;
	
	public void interestEvent(int cul_no, int m_no) throws Exception;
	
	public int gettNo(TicketingVO vo) throws Exception;
}
