package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.ListDAO;
import go.culture.domain.ListVO;
@Service
public class ListServiceImpl implements ListService {

	@Inject
	private ListDAO dao;
	
	@Override
	public List<ListVO> listGone() throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone();
	}

	@Override
	public List<ListVO> listReservation() throws Exception {
		// TODO Auto-generated method stub
		return dao.listReservation();
	}

	@Override
	public List<ListVO> listHeart() throws Exception {
		// TODO Auto-generated method stub
		return dao.listHeart();
	}

	@Override
	public List<ListVO> listReservationDate() throws Exception {
		// TODO Auto-generated method stub
		return dao.listReservationDate();
	}

	@Override
	public List<ListVO> listHeartDate() throws Exception {
		// TODO Auto-generated method stub
		return dao.listHeartDate();
	}

	@Override
	public List<ListVO> listGone1mon() throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone1mon();
	}

	@Override
	public List<ListVO> listGone3mon() throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone3mon();
	}

	@Override
	public List<ListVO> listGone6mon() throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone6mon();
	}

}
