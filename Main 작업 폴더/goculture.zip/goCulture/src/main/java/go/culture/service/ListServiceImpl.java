package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.ListDAO;
import go.culture.domain.ListVO;
@Service
public class ListServiceImpl implements ListService {

	@Inject
	private ListDAO dao;
	
	@Override
	public List<ListVO> listGone(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone(m_no);
	}

	@Override
	public List<ListVO> listReservation(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listReservation(m_no);
	}

	@Override
	public List<ListVO> listHeart(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listHeart(m_no);
	}

	@Override
	public List<ListVO> listReservationDate(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listReservationDate(m_no);
	}

	@Override
	public List<ListVO> listHeartDate(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listHeartDate(m_no);
	}

	@Override
	public List<ListVO> listGone1mon(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone1mon(m_no);
	}

	@Override
	public List<ListVO> listGone3mon(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone3mon(m_no);
	}

	@Override
	public List<ListVO> listGone6mon(int m_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listGone6mon(m_no);
	}

	@Override
	public List<ListVO> listNon(int nm_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listNon(nm_no);
	}

	@Override
	public List<ListVO> listNonClick(String nm_name, int t_no) throws Exception {
		// TODO Auto-generated method stub
		return dao.listNonClick(nm_name, t_no);
	}

}
