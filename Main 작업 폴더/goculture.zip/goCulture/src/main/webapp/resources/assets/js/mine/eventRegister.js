$(document).ready(function(){
	$(".imgs_wrap, .mainImg").on("click", ".imgRemove", function(){
		var that = $(this); // this는 클릭한 small태그
	    $.ajax({
	       url: "./imgRemove",
	       type: "POST",
	       data: {fileName:$(this).attr("data-src")},
	       dataType: "text",
	       success: function(result){
	          if(result == 'deleted') {
	             that.parent().remove();
	          }
	       }
	    });
	});
});

var sel_files = [];

//상세이미지 업로드(n장)
function handleImgsFilesSelect(e){
	var files = e.files;
	var length = e.files.length;
	var filesArr = Array.prototype.slice.call(files);
	
	filesArr.forEach(function(f,i){
		
		if(!checkImageType((e.files[i].name))){
	        alert("파일형식은 이미지 파일만 가능합니다.");
	        $("#cul_detailImg").val("");
	        return false;
	     }
		
		sel_files.push(f);
		var formData = new FormData();
    	formData.append("file", e.files[i]);
		
		$.ajax({
	        url: "./cul_mainImg",
	        data: formData,
	        dataType: "text",
	        processData: false,
	        contentType: false,
	        type: "POST",
	        success: function(data) {
	    		var reader = new FileReader();
	    		reader.onload = function(e){
	    			var img_html = "<span><img class='imgmulti' src='"+e.target.result+"'/> <i data-src="+data+" class='fa fa-close imgRemove'></i></span>";
	    			$(".imgs_wrap").append(img_html);
	    			var imgInfo = "<input type = 'hidden' name = 'dp_detailedImg' value ='"+data+"'/>";
	    			$(".imgs_wrap").append(imgInfo);
	    		}
	    		reader.readAsDataURL(f);
	        }
	     });
		
	});
	
}

// 대표이미지 업로드(1장)
function handleImgFileSelect(input) {
	console.log(input.files[0])
	if(!checkImageType((input.files[0].name))){
        alert("파일형식은 이미지 파일만 가능합니다.");
        $("#cul_mainImg").val("");
        return false;
     }
	
	var formData = new FormData();
	formData.append("file", input.files[0]);
	
	$.ajax({
        url: "./cul_mainImg",
        data: formData,
        dataType: "text",
        processData: false,
        contentType: false,
        type: "POST",
        success: function(data) {
        	if (input.files && input.files[0]) {
        		var reader = new FileReader();
        		reader.onload = function(e) {
        			$('#blah').attr('src', e.target.result);
        			var str = "<i data-src="+data+" class='fa fa-close imgRemove'></i>";
	    			$("#blah").parent().append(str);
	    			var imgInfo = "<input type = 'hidden' name = 'cul_mainImg' value ='"+data+"'/>";
	    			$("#blah").parent().append(imgInfo);
        		}
        		reader.readAsDataURL(input.files[0]);
        	}
        }
     });
}

// 이미지 파일 형식 체크 
function checkImageType(fileName) {
   // checkImageType 메소드의 정규표현식을 이용하여 
   // 파일확장자의 존재여부 파악 
   // i의 의미는 대,소문자의 구분이 없다. 
   var pattern = /jpg|gif|png|jpeg/i;
   return fileName.match(pattern);
}

var map

var X = '14315520.90430';
var Y = '4283115.74626';
var scope = '11';

init();

function init(){
	mainMap();
}

function mapSet(){
	map = new Tmap.Map({
		div : 'map_div',
		width : '100%',
		height : '400px',
		transitionEffect : "resize",
		animation : true
	});
}

function mainMap(){
	mapSet();
	map.setCenter(new Tmap.LonLat(X, Y), scope);
	// map.addControl(new Tmap.Control.KeyboardDefaults());
	map.addControl(new Tmap.Control.MousePosition());
	// searchRoute();
}

var markerLayer;
var tdata;
var name = '';
 
addMarkerLayer();

var clcl;   // 장소
 $("#placeSerch").on("click", function(){
    clcl = true;

    $("#ul").empty();   // 태그제거
    var placeName = $("#placeName").val();

    searchPOI(placeName);   // 검색
    
    markerLayer.clearMarkers();   // 마커 초기화
    
    getDataFromLonLat($("#placeName").lonlat);   // 주소

 });

 
 function addMarkerLayer(){
    markerLayer = new Tmap.Layer.Markers("marker");
    map.addLayer(markerLayer);
};

function addMarker(options){
    var size = new Tmap.Size(23,30);
    var offset = new Tmap.Pixel(-(size.w/2), -size.h);
    var icon = new Tmap.Icon("http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",size,offset);
    var marker = new Tmap.Markers(options.lonlat,icon,options.label);
    markerLayer.addMarker(marker);
    marker.events.register("mouseover", marker, onOverMouse);
    marker.events.register("mouseout", marker, onOutMouse);
    marker.events.register("click", marker, onClickMouse);
}
function onOverMouse(e){
    this.popup.show();
}
function onOutMouse(e){
    this.popup.hide();
}
function onClickMouse(e){
    console.log(this.lonlat);
    getDataFromLonLat(this.lonlat);
}
function searchPOI(placeName){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTData);
    var center = map.getCenter();
    tdata.getPOIDataFromSearch(encodeURIComponent(placeName), {centerLon:center.lon, centerLat:center.lat});
}
function onCompleteTData(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var id = jQuery(this).find("id").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
            var options = {
                label:new Tmap.Label(name),
                lonlat:new Tmap.LonLat(lon, lat)
            };
            addMarker(options);
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTData);
}
function getDataFromLonLat(lonlat){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTDataLonLat);
    tdata.getPOIDataFromLonLat(lonlat, encodeURIComponent("편의점"), {bizAppId:"701a4eaf1326", radius:1});
}
function onCompleteTDataLonLat(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
            var options = {
                label:new Tmap.Label(name),
                lonlat:new Tmap.LonLat(lon, lat)
            };
            console.log(name, lon, lat);
          
          if(clcl == true) {
               $("#ul").append("<li id = '"+name+"'>" + name + "</li>" 
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          } else if (clcl == false) {
             $("#ul1").append("<li>" + name + "</li>" 
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          }

            addMarker(options); // all 마커
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTDataLonLat);
}


$("#ul").on("click", "li", function() {
	mapSet();
	
	var placeName	= $(this).prop("id");
	var placeX		= $(this).next().val();
	var placeY		= $(this).next().next().val();
	
	var pr_3857 = new Tmap.Projection("EPSG:3857");
	var pr_4326 = new Tmap.Projection("EPSG:4326");
	var lonlat = new Tmap.LonLat(placeX, placeY).transform(pr_3857, pr_4326);

	
	var latitude = lonlat.lat;
	var hardness = lonlat.lon;
	
	X = placeX;
	Y = placeY;
	scope = '20';
	
	$("#map_div").empty();
	
	mainMap();
	addMarkerLayer();
	
   $("#placeX").val(placeX);
   $("#placeY").val(placeY);
   $("#placeName").val(placeName);
   
   $("#ul").empty();
   
   var options = {
           label:new Tmap.Label(placeName),
           lonlat:new Tmap.LonLat(placeX, placeY)
       };
   addMarker(options);
   
   $("#ul").append("<li>" + placeName + "</li>" 
           + "<input name = 'cul_latitude' type='hidden' value='" + placeX + "'>"
           + "<input name = 'cul_hardness' type='hidden' value='" + placeY + "'>"
           + "<input name = 'cul_WGSlat' type='hidden' value='" + latitude + "'>"
           + "<input name = 'cul_WGSlon' type='hidden' value='" + hardness + "'>");
});