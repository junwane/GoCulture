$(document).ready(function(){
	
	App.init();
	StyleSwitcher.initStyleSwitcher();
	OwlRecentWorks.initOwlRecentWorksV1();
	$('#mask').click(function() {
		$(this).hide();
		$('.window').hide();
	});
	$('.openMask').click(function(e) {
		e.preventDefault();
		var src = $(e).attr( 'src' );
		$('#windowimg').attr('src',src);
		wrapWindowByMask();
	});
});
function wrapWindowByMask() {
	//화면의 높이와 너비를 구한다.
	var maskHeight = $(document).height();
	var maskWidth = $(window).width();

	//마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다.
	$('#mask').css({
		'width' : maskWidth,
		'height' : maskHeight
	});
	//애니메이션 효과
	$('#mask').fadeIn(500);
	$('#mask').fadeTo("slow", 0.8);
	$('.window').show();
}
function clickimg(src,con) {
	$(".window").html("<img id='windowimg' alt=''>"+con);
	$('#windowimg').attr('src', src);
}
function openCity(cityName) {
    var i;
    var x = document.getElementsByClassName("city");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";
    }
    document.getElementById(cityName).style.display = "block";
 }
