$(document).ready(function() {
	$(".fa-search").on("click", function() {
		var search = $("#search").val();
		$.ajax({
			url : "./page_confirmpassword",
			type : "POST",
			data : {
				search : search
			},
			success : function(result) {
			},
			error : function() {
				alert('통신실패!!');
			}
		});
	});
});