$(document).ready(function() {
	$(".fa-search").on("click", function() {
		var search = $("#search").val();
		$.ajax({
			url : "./search",
			type : "POST",
			data : {
				search : search
			},
			success : function(result) {
			},
			error : function(
					request,
					status, error) {
				alert("code:"
						+ request.status
						+ "\n"
						+ "message:"
						+ request.responseText
						+ "\n"
						+ "error:"
						+ error);
			}
		});
	});
});