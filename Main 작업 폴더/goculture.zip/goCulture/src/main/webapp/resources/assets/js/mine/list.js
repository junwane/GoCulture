$(document).ready(function(){
   $("#listReservationDate").hide();
   $("#listHeartDate").hide();
   $("#goneList").hide();
   $("#heartList").hide();
   $("#all").hide();
   $("#3mon").hide();
   $("#6mon").hide();
   
   $('#gone').click(function(e) {
      $("#reservationList").hide();
      $("#heartList").hide();
      $("#goneList").show();
      $("#gone").attr("class","active");
      $("#reservation").attr("class","act");
      $("#heart").attr("class","act");
      $(".h1").text("다녀온 행사");

   });
   
   $('#heart').click(function(e) {
      $("#reservationList").hide();
      $("#goneList").hide();
      $("#heartList").show();
      $("#heart").attr("class","active");
      $("#reservation").attr("class","act");
      $("#gone").attr("class","act");
      $(".h1").html("찜 <i class='fa fa-gratipay' aria-hidden='true'></i>");
   });
   
   $('#reservation').click(function(e) {
      $("#goneList").hide();
      $("#heartList").hide();
      $("#reservationList").show();
      $("#reservation").attr("class","active");
      $("#gone").attr("class","act");
      $("#heart").attr("class","act");
      $(".h1").text("예매 내역");
   });
});

function reservationRegister(val){
   if(val==("예매날짜순")){
      $("#listReservation").show();
      $("#listReservationDate").hide();
   }else{
      $("#listReservation").hide();
      $("#listReservationDate").show();
   }
}

function listHeart(val){
   if(val==("예매날짜순")){
      $("#listHeart").show();
      $("#listHeartDate").hide();
   }else{
      $("#listHeart").hide();
      $("#listHeartDate").show();
   }
}

function goneRegister(val){
   if(val==("1개월")){
      $("#1mon").show();
      $("#all").hide();
      $("#3mon").hide();
      $("#6mon").hide();
   }else if(val==("3개월")){
      $("#all").hide();
      $("#3mon").show();
      $("#6mon").hide();
      $("#1mon").hide();
   }else if(val==("6개월")){
      $("#all").hide();
      $("#6mon").show();
      $("#3mon").hide();
      $("#1mon").hide();
   }else{
      $("#1mon").hide();
      $("#3mon").hide();
      $("#6mon").hide();
      $("#all").show();
   }
   
}