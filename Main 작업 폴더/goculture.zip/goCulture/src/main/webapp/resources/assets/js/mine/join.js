function emailChecked(){ //email 형식 체크

	this.boolean = true;
	var exptext = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
		if (exptext.test($("#emailVal").val())!=true){
			this.boolean = false;
		}
	return this.boolean;     // boolean 값을 반환 . 이메일 형식이 아니면 false
}

//회원가입 클릭 시 이메일 인증팝업 넘어감
$("#save").on("click", function(e){
	
	var email_bool = new emailChecked();
    if($("#emailVal").val() === ""){
      alert("이메일을 입력해주세요");
      $("#emailVal").focus();
      return false;
    }
    else if($("#pass").val() === ""){
     alert("패스워드를 입력하세요");
     $("#pass").focus();
     $("#pass").val("");
     return false;
   }
   else if($("#passConfirm").val() === ""){
    alert("패스워드를 입력하세요");
    $("#passConfirm").focus();
    $("#passConfirm").val("");
    return false;
  }
   else if($("#pass").val() !== $("#passConfirm").val()){
     alert("패스워드가 맞지 않습니다.");
     $("#pass").focus();
     $("#pass").val("");
     $("#passConfirm").val("");
     return false;
   }
    else if(!$("#pass").val().match(/\d+/g) || ! $("#pass").val().match(/[a-z]+/gi)){
     alert("패스워드는 반드시 영문과 숫자를 1개 이상 조합하여 사용하십시오.");
     return false;
   }
    else if(email_bool.boolean === false){
      alert("이메일 형식이 올바르지 않습니다.");
      $("#emailVal").focus();
      return false;
    }
    else{
      alert("회원가입을 완료하였습니다.");
    }
  });


/*$("#mailSend").on('click', function(){
	var email = $("#emailVal").val();
	
    $.ajax({
        url : "/goculture/mailSending",
        type : "post",
        dataType : "json",
        data : {email:email},
        success : function(result){
        	alert("이메일이 발송되었습니다.");
        },
        error : function(err){
        	alert("이메일 발송 실패");
        }
      });
});*/
