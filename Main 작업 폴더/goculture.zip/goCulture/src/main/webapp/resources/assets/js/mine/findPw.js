jQuery(document).ready(function() {
		$('#sendPw').click(function(e) {
			var chk = true;
			$("#searchUl").empty();
			$("#NoneSearch").empty();
			var num = $('#m_residentNum').val(); //주민번호
			var residentNum=$('#realresidentNum').val();
			var name = $('#m_name').val();
			var email = $('#m_email').val();
			var email_bool = new emailChecked();
			
			if(name == "") {
				$('.modal-header').hide();
				$("#NoSearch").html("<br/><h3 style='text-align:center;'>이름을 입력해주세오</h3><br/>");
				chk = false;
			}else if(num == ""||num.length!=9) {
				$('.modal-header').hide();
				$("#NoSearch").html("<br/><h3 style='text-align:center;'>주민등록번호 8자리를 입력해주세오</h3><br/>");
				chk = false;
			}else if(email == "") {
				$('.modal-header').hide();
				$("#NoSearch").html("<br/><h3 style='text-align:center;'>회원가입시 입력한 이메일을 입력해주세오</h3><br/>");
				chk = false;
			}else if(email_bool.boolean === false){
				$('.modal-header').hide();
				$("#NoSearch").html("<br/><h3 style='text-align:center;'>이메일 형식이 올바르지 않습니다.</h3><br/>");
			      $("#m_email").focus();
			      chk = false;
			    }
			if (chk) {
				$.ajax({
						url : "mailSendingPw",
						type : "POST",
						data : {
							name : name,
							residentNum : residentNum,
							email:email
						},
						success : function(result) {
							if(result==""){
								$('#NoSearch').hide();
								$("#NoneSearch").html("<br/><h3 style='text-align:center;'>검색 결과가 없습니다ㅠㅅㅠ</h3><br/>");
							}else{
								$('#NoSearch').hide();
								$('#NoneSearch').hide();
								$("#searchUl").append("<h4 style='text-align:center; data-dismiss='modal'>임시 비밀번호가 전송되었습니다!<br/>전송 받은 임시 비밀번호로 로그인해주세용</h4>");
								}
							},
							error : function(request,status, error) {
								$('.modal-header').hide();
								$("#NoSearch").html("<br/><h3 style='text-align:center;'>일치하는 회원 정보가 없습니다ㅠㅠ</h3><br/>");
							}

						});
					}
			});
});

function autoHypenPhone(str) {
	str = str.replace(/[^0-9]/g, '');
	var tmp = '';
	if (str.length < 7) {
		return str;
	} else {
		tmp += str.substr(0, 6);
		tmp += '-';
		tmp += str.substr(6);
		return tmp;
	}
	return str;
}

function emailChecked(){ //email 형식 체크

	this.boolean = true;
	var exptext = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
		if (exptext.test($("#m_email").val())!=true){
			this.boolean = false;
		}
	return this.boolean;     // boolean 값을 반환 . 이메일 형식이 아니면 false
}

var m_residentNum = document.getElementById('m_residentNum');
m_residentNum.onkeyup = function(event) {
	event = event || window.event;
	var _val = this.value.trim();
	var num1 = this.value.substr(0,6);
	var num2 = this.value.substr(7,9);
	document.getElementById('realresidentNum').value=num1+num2;
	this.value = autoHypenPhone(_val);
}

