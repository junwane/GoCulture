jQuery(document).ready(function() {
		$('#findId').click(function(e) {
			var chk = true;
			$("#searchUl").empty();
			$("#NoneSearch").empty();
			var num = $('#m_residentNum').val(); //주민번호
			var residentNum=$('#realresidentNum').val();
			var name = $('#m_name').val();
			if(name == "") {
				$('.modal-header').hide();
				$("#NoSearch").html("<br/><h3 style='text-align:center;'>이름을 입력해주세오</h3><br/>");
				chk = false;
			}else if(num == ""||num.length!=9) {
				$('.modal-header').hide();
				$("#NoSearch").html("<br/><h3 style='text-align:center;'>주민등록번호 8자리를 입력해주세오</h3><br/>");
				chk = false;
			}
			if (chk) {
				$.ajax({
						url : "./findId",
						type : "POST",
						data : {
							name : name,
							residentNum : residentNum
						},
						success : function(result) {
							if (result == "") {
								$("#NoneSearch").html("<br/><h3 style='text-align:center;'>검색 결과가 없습니다ㅠㅅㅠ</h3><br/>");
								$('#NoSearch').hide();
								$('.modal-header').hide();
								} else {
										$('#NoSearch').hide();
										$('.modal-header').show();
										$("#searchUl").append("<h4 data-dismiss='modal'> 회원님의 아이디는 <b>"+ result+ "</b>입니다.</h4>");
									e.preventDefault();
								}
							},
							error : function(request,status, error) {
								alert("code:"
										+ request.status
										+ "\n"
										+ "message:"
										+ request.responseText
										+ "\n"
										+ "error:"
										+ error);
							}

						});
					}
			});
});

function autoHypenPhone(str) {
	str = str.replace(/[^0-9]/g, '');
	var tmp = '';
	if (str.length < 7) {
		return str;
	} else {
		tmp += str.substr(0, 6);
		tmp += '-';
		tmp += str.substr(6);
		return tmp;
	}
	return str;
}

var m_residentNum = document.getElementById('m_residentNum');
m_residentNum.onkeyup = function(event) {
	event = event || window.event;
	var _val = this.value.trim();
	var num1 = this.value.substr(0,6);
	var num2 = this.value.substr(7,9);
	document.getElementById('realresidentNum').value=num1+num2;
	this.value = autoHypenPhone(_val);
}

