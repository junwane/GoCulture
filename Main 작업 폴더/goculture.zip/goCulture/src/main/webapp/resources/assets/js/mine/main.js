jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
});
$(document).ready(function() {
	$('.bxslider').bxSlider({
		auto : true,
		autoHover : true,
		captions : true
	});
})

$(".mainImg").on("click",function(){
	var imgId = $(this).attr('id');
	window.location.href="cateInner?cate_no="+imgId+"&filter=1&latitude=1&hardness=1";
});