jQuery(document).ready(function() {
			App.init();
			StyleSwitcher.initStyleSwitcher();
		});
		$(document).ready(function(){
			$('.bxslider').bxSlider({
				auto : true,
				autoHover : true,
				captions: true
			});
		})