		jQuery(document).ready(function() {
			App.init();
			StyleSwitcher.initStyleSwitcher();
		});
		function autoHypenPhone(str){
            str = str.replace(/[^0-9]/g, '');
            var tmp = '';
            if( str.length < 7){
                return str;
            }else if(str.length < 9){
                tmp += str.substr(0, 6);
                tmp += '-';
                tmp += str.substr(6);
                return tmp;
            }
            return str;
        }

var cellPhone = document.getElementById('num');
cellPhone.onkeyup = function(event){
        event = event || window.event;
        var _val = this.value.trim();
        this.value = autoHypenPhone(_val) ;
}