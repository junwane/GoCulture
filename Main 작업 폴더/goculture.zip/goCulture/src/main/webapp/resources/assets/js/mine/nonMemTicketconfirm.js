jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
});
function autoHypenPhone(str) {
	str = str.replace(/[^0-9]/g, '');
	return str;
}

var t_no = document.getElementById('t_no');
t_no.onkeyup = function(event) {
	event = event || window.event;
	var _val = this.value.trim();
	this.value = autoHypenPhone(_val);
}
