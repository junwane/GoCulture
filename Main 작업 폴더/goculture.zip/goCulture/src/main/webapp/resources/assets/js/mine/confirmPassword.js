$(document).ready(function() {
	$(".btn-u").on("click", function() {
		var pw = $("#pw").val();
		$.ajax({
			url : "./confirmPassword",
			type : "POST",
			data : {
				m_password : pw
			},
			success : function(responseData) {
				var data = JSON.parse(responseData);
				if (!data) {
					$(".con").html("비밀번호가 맞지 않습니다ㅠㅅㅠ");
					$("#pw").val("");
				} else {
					window.location="memberInfo";
				}
			},
			error : function() {
				alert('통신실패!!');
			}
		});
	});
});