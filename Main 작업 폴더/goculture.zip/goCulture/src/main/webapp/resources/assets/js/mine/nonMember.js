	var price1;
	var price;

	$(document).ready(function() {

		var formObj = $("form[action='#']");
		console.log(formObj);
		$("#nonMemEventList").on("click", function() {
			formObj.attr("action", "/yg/nonMemEventList");
			formObj.attr("method", "POST");
			formObj.submit();

		});

	});
