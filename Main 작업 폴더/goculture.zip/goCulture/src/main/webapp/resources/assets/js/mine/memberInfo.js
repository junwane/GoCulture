
jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
	$('#mask').click(function() {
		$(this).hide();
		$('.window').hide();
	});
	$('#cancle').click(function() {
		$('#mask').hide();
		$('.window2').hide();
	});
	$('#myBtn').click(function(e) {
		e.preventDefault();
		wrapWindowByMask();
	});	
	$('#bye').click(function(e) {
		e.preventDefault();
		wrapWindowByMask2();
	});
	$('#checkpw').click(function(e) {
		var pw1 = $("#pw1").val();
		var pw2 = $("#pw2").val();
		if(pw1!=pw2){
			$("#con").text("비밀번호가 일치하지 않습니다.");
		}else{
			$.ajax({
				url : "./memberInfo",
				type : "POST",
				data : {
					pw : pw1
				},
				success : function(result) {
					$("#con").text("변경되었습니다!");
				},
				error : function() {
					alert('통신실패!!');
				}
			});
		}
	});
	
	$('#delete').click(function(e) {
			$.ajax({
				url : "./deleteMember",
				type : "POST",
				data : {
					
				},
				success : function(result) {
					$('#mask').hide();
					$('.window2').hide();
					window.alert("탈퇴되었습니당");
					location.href="main";
				},
				error : function() {
					alert('통신실패!!');
				}
			});
	});
});


function wrapWindowByMask() {
	//화면의 높이와 너비를 구한다.
	var maskHeight = $(document).height();
	var maskWidth = $(window).width();

	//마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다.
	$('#mask').css({
		'width' : maskWidth,
		'height' : maskHeight
	});
	//애니메이션 효과
	$('#mask').fadeIn(500);
	$('#mask').fadeTo("slow", 0.8);
	$('.window').show();
}

function wrapWindowByMask2() {
	//화면의 높이와 너비를 구한다.
	var maskHeight = $(document).height();
	var maskWidth = $(window).width();

	//마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다.
	$('#mask').css({
		'width' : maskWidth,
		'height' : maskHeight
	});
	//애니메이션 효과
	$('#mask').fadeIn(500);
	$('#mask').fadeTo("slow", 0.8);
	$('.window2').show();
}
