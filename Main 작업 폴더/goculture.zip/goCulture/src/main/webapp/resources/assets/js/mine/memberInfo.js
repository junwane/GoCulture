jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
	$('#mask').click(function() {
		$(this).hide();
		$('.window').hide();
	});
	$('#cancle').click(function() {
		$('#mask').hide();
		$('.window2').hide();
	});
	$('#myBtn').click(function(e) {
		e.preventDefault();
		wrapWindowByMask();
	});
	$('#bye').click(function(e) {
		e.preventDefault();
		wrapWindowByMask2();
	});
	$('#checkpw').click(function(e) {
		var pw1 = $("#pw1").val();
		var pw2 = $("#pw2").val();
		if (pw1 != pw2) {
			$("#con").text("비밀번호가 일치하지 않습니다.");
		} else {
			$.ajax({
				url : "./memberInfo",
				type : "POST",
				data : {
					pw : pw1
				},
				success : function(result) {
					$("#con").text("변경되었습니다!");
				},
				error : function() {
					alert('통신실패!!');
				}
			});
		}
	});

	$('#delete').click(function(e) {
		$.ajax({
			url : "./deleteMember",
			type : "POST",
			data : {

			},
			success : function(result) {
				$('#mask').hide();
				$('.window2').hide();
				window.alert("탈퇴되었습니당");
				location.href = "main";
			},
			error : function() {
				alert('통신실패!!');
			}
		});
	});
});
