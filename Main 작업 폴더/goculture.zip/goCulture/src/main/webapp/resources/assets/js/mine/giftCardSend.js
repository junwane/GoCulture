jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
});
$('#searchbutton').click(function(e) {
	var chk = true;
	$("#searchUl").empty();
	$("#NoneSearch").empty();
	search = $("#searchEmail").val();
	if (search == "") {
		$('.modal-header').hide();
		$("#NoSearch").html("검색어를 입력해주세오");
		chk = false;
		}
	if (chk) {
		$.ajax({
			url : "./searchEmail",
			type : "POST",
			data : {
				search : search
					},
			success : function(result) {
				if (result == "") {
					$("#NoneSearch").html("검색 결과가 없습니다ㅠㅅㅠ");
					$('#NoSearch').hide();
					$('.modal-header').hide();
				} else {
					var resident, re1, re2, residentNum;
					for (var i = 0; i < result.length; i++) {
						$('#NoSearch').hide();
						$('.modal-header').show();
						resident = result[i].m_residentNum;
						re1 = new String(resident).substr(0,6);
						re2 = new String(resident).substr(8,2);
						residentNum = re1+"-"+ re2;
						$("#searchUl").append("<li id='"+ result[i].m_email+ "'data-dismiss='modal' onclick='liClick(this);'>"
														+ result[i].m_name
														+ "<br/>"
														+ residentNum
														+ "<br/><a>"
														+ result[i].m_email
														+ "</a></li><br/>")
					}
				e.preventDefault();
				}
			},
			error : function(request,status, error) {
				alert("code:"+ request.status
						 	 + "\n"
						 	 + "message:"
						 	 + request.responseText
						 	 + "\n"
						 	 + "error:"
						 	 + error);
			}
		});
	}
});

$('.bxslider').bxSlider({
maxSlides : 4,
minSlides : 3,
slideWidth : 170,
slideMargin : 10
});


function liClick(e) {
	var name = e.getAttribute('id');// 변수 name 에 클릭한 위치의 텍스트 저장
	$("#searchEmail").val(name);
}

function handleImgFileSelect(input) {
	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('.gift').attr('src', e.target.result);
			$('#gc_img').val(e.target.result);
		}
	reader.readAsDataURL(input.files[0]);
	}
}

function clickimg(src) {
	$('.gift').attr('src', src);
	$('#gc_img').val(src);
}