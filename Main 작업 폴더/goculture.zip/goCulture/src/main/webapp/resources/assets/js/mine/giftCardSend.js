jQuery(document).ready(
		function() {
			App.init();
			StyleSwitcher.initStyleSwitcher();
			$('#mask').click(function() {
				$(this).hide();
				$('.window').hide();
			});

			// $('li').click(function(){
			// var name=$(this).text(); //변수 name 에 클릭한 위치의 텍스트 저장
			// $("#search").val(name);
			// $('#mask').hide();
			// $('.window').hide();
			// });

			$('#searchbutton').click(
					function(e) {
						var chk=true;
						$("#searchUl").empty();
						$("#con").empty();
						search = $("#search").val();
						if(search==""){
							alert('검색어를 입력해주세요!');
							chk=false;
						}
						if(chk){
						$.ajax({
							url : "./searchEmail",
							type : "POST",
							data : {
								search : search
							},
							success : function(result) {
								if (result=="") {
									$("#con").html("검색 결과가 없습니다ㅠㅅㅠ");
								} 
								else {
									for(var i =0; i<result.length; i++){
										$("#searchUl").append("<li>"+result[i].m_email+"</li>")
									}
									e.preventDefault();
									wrapWindowByMask();
								}
							},
							error : function(request, status, error) {
								alert("code:" + request.status + "\n"
										+ "message:" + request.responseText
										+ "\n" + "error:" + error);
							}

						});
					}
					});

			$('.bxslider').bxSlider({
				maxSlides : 4,
				minSlides : 3,
				slideWidth : 170,
				slideMargin : 10
			});
		});

function handleImgFileSelect(input) {

	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('.gift').attr('src', e.target.result);
			$('#gc_img').val(e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	}
}
function wrapWindowByMask() {
	// 화면의 높이와 너비를 구한다.
	var maskHeight = $(document).height();
	var maskWidth = $(window).width();

	// 마스크의 높이와 너비를 화면 것으로 만들어 전체 화면을 채운다.
	$('#mask').css({
		'width' : maskWidth,
		'height' : maskHeight
	});
	//애니메이션 효과
	$('#mask').fadeIn(500);
	$('#mask').fadeTo("slow", 0.8);
	$('.window').show();
}
function clickimg(src) {

	$('.gift').attr('src', src);
	$('#gc_img').val(src);
}
