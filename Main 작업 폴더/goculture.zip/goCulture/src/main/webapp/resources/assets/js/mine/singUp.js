function emailChecked(){ //email 형식 체크

	this.boolean = true;
	var exptext = /^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/;
		if (exptext.test($("#emailVal").val())!=true){
			this.boolean = false;
		}
	return this.boolean;     // boolean 값을 반환 . 이메일 형식이 아니면 false
}

//회원가입 클릭 시 이메일 인증팝업 넘어감
$("#save").on("click", function(e){
	
	var email_bool = new emailChecked();
    if($("#emailVal").val() === ""){
      alert("이메일을 입력해주세요");
      $("#emailVal").focus();
      return false;
    }
    else if($("#pass").val() === ""){
     alert("패스워드를 입력하세요");
     $("#pass").focus();
     $("#pass").val("");
     return false;
   }
   else if($("#passConfirm").val() === ""){
    alert("패스워드를 입력하세요");
    $("#passConfirm").focus();
    $("#passConfirm").val("");
    return false;
  }
   else if($("#pass").val() !== $("#passConfirm").val()){
     alert("패스워드가 맞지 않습니다.");
     $("#pass").focus();
     $("#pass").val("");
     $("#passConfirm").val("");
     return false;
   }
    else if(!$("#pass").val().match(/\d+/g) || ! $("#pass").val().match(/[a-z]+/gi)){
     alert("패스워드는 반드시 영문과 숫자를 1개 이상 조합하여 사용하십시오.");
     return false;
   }
    else if(email_bool.boolean === false){
      alert("이메일 형식이 올바르지 않습니다.");
      $("#emailVal").focus();
      return false;
    }
    else{
      alert("회원가입을 완료하였습니다.");
    }
  });

// 이메일 인증
$(".mailSend").on('click', function(event){
	event.preventDefault();//submit ㅂㅇㅂㅇ
	if($("#emailVal").val() === ""){
	      alert("이메일을 입력해주세요");
	      $("#emailVal").focus();
	      return false;
	}
	var email = $("#emailVal").val();
	
    $.ajax({
        url : "mailSending",
        data : {email:email},
        type : "post",
        success : function(result){
        	$("#emailCode").val(result);
        },
        error : function(err){
        	console.log(err);
        	alert("이메일 발송 실패");
        }
      });
});

$(".emailCodeCheck").on("click",function(event){
	event.preventDefault();
	var emailCheck = $("#emailCode").val();
	var emailCode = $("#joinCode").val();
	
	if(emailCheck != emailCode){
		alert("인증코드가 틀립니다.")
	}else{
		alert("인증 성공")
		$(".emailCodeCheck").attr("data-dismiss","modal")
	}
});

$(".emailSerch").on("click", function(event){
	event.preventDefault();
});

var m_residentNum = document.getElementById('m_residentNum');
m_residentNum.onkeyup = function(event) {
	event = event || window.event;
	var _val = this.value.trim();
	var num1 = this.value.substr(0,6);
	var num2 = this.value.substr(7,9);
	document.getElementById('realresidentNum').value=num1+num2;
	this.value = autoHypenPhone(_val);
}

jQuery(document).ready(function() {
	$('#searchbutton').click(function(e) {
		var chk = true;
		$("#searchUl").empty();
		$("#NoneSearch").empty();
		search = $("#searchEmail").val();
		if (search == "") {
			$('.modal-header').hide();
			$("#NoSearch").html("<br/><h3 style='text-align:center;'>검색어를 입력해주세오</h3><br/>");
			chk = false;
		}
		if (chk) {
			$.ajax({
				url : "./searchEmail",
				type : "POST",
				data : {
					search : search
				},
				success : function(result) {
					if (result == "") {
						$("#NoneSearch").html("<br/><h3 style='text-align:center;'>검색 결과가 없습니다ㅠㅅㅠ</h3><br/>");
						$('#NoSearch').hide();
						$('.modal-header').hide();
					} else {
						for (var i = 0; i < result.length; i++) {
							$('#NoSearch').hide();
							$('.modal-header').show();
							$("#searchUl").append("<li data-dismiss='modal' onclick='liClick(this);'>"+ result[i].m_email+ "</li>")
						}
						e.preventDefault();
					}
				},
				error : function(request,status, error) {
					alert("code:"+ request.status
							+ "\n"
							+ "message:"
							+ request.responseText
							+ "\n"
							+ "error:"
								+ error);
					}

				});
			}
		});
});
function liClick(e) {
var name = $(e).text(); // 변수 name 에 클릭한 위치의 텍스트 저장
$("#searchEmail").val(name);

$('.window').hide();
}