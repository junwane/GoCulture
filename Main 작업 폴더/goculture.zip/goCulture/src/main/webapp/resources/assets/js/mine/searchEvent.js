$(document).ready(function() {
	$("#searchEventBtn").on("click", function(e) {
		var searchEvent = $("#searchEvent").val();
		$.ajax({
			url : "search",
			type : "post",
			data : {},
			success : function(result) {
				if(result!=null){
				location.href="search?cul_title="+searchEvent;
				}
			},
			error : function(request,status, error) {
				alert("code:"
						+ request.status
						+ "\n"
						+ "message:"
						+ request.responseText
						+ "\n"
						+ "error:"
						+ error);
			}
		});
	});
});
//문화행사 클릭 시 해당 문화행사 상세 페이지로 이동
$(document).on("click", ".ceInner", function() {
	var cul_no = $(this).attr("id");
	location.href = "eventDetail?cul_no=" + cul_no;
});