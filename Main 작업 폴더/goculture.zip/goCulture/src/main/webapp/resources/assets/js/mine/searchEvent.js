$(document).ready(function() {
	$("#searchEventBtn").on("click", function(e) {
		var searchEvent = $("#searchEvent").val();
		$.ajax({
			url : "",
			type : "post",
			data : {},
			success : function(result) {
				if(result!=null){
				location.href="search?cul_title="+searchEvent+"&filter=1";
				}
			},
			error : function(request,status, error) {
				alert("code:"
						+ request.status
						+ "\n"
						+ "message:"
						+ request.responseTexot
						+ "\n"
						+ "error:"
						+ error);
			}
		});
	});
});
//문화행사 클릭 시 해당 문화행사 상세 페이지로 이동
$(document).on("click", ".ceInner", function() {
	var filter = $(this).val();
	var searchEvent = $("#searchEvent").val();
	location.href = "eventDetail?cul_no=" + cul_no;
});
$(".select").on("change", function() {
	var filter = $(this).val();
	var searchEvent = $("#searchEvent").val();
	cateList(filter, searchEvent);
});
function cateList(filter, searchEvent){
	$
			.ajax({
				url : "search",
				data : {
					filter : filter,
					cul_title : searchEvent
				},
				type : "post",
				success : function(data) {
					$(".culWrap").empty();
					var str = "";
					for ( var i in data.ceList) {
						str += '<li class="col-sm-3 col-xs-6 md-margin-bottom-30">'
							+ '<div class="team-img" id="'
							+ data.ceList[i].cul_no
							+ '">'
							+ '<img class="img-responsive ceInner" style="height: 170px;" src="displayFile?fileName=/s_'
							+ data.ceList[i].cul_mainImg
							+ '" id="'+data.ceList[i].cul_no+'"/>'
							+ '</div><br/>'
							+ '<a class="h3 ceInner" id= "'
							+ data.ceList[i].cul_no
							+ '"><b>'
							+ data.ceList[i].cul_title
							+ '</b></a>'
							+ '<h3>'
							+ data.ceList[i].cul_startDate
							+ '</h3><p> <span class="chat-message-item" class="font17">'
							+ '잔여 예매 수 : '
							+ data.ceList[i].ticketNum
							+ '</span><br> <span class="chat-message-item" class="font17">'
							+ data.ceList[i].cul_placeNum
							+ '</span><br> <span class="chat-message-item" class="font17">'
							+ '￦ '
							+ data.ceList[i].cul_price
							+ '</span></p>'
							+ '</li>'
							+ '<input type = "hidden" class = "cul_latitude" name = "cul_latitude" value = "'
							+ data.ceList[i].cul_latitude
							+ '" />'
							+ '<input type = "hidden" class = "cul_hardness" name = "cul_hardness" value = "'
							+ data.ceList[i].cul_hardness
							+ '" />'
							+ '<input type = "hidden" class = "cul_placeName" name = "cul_placeName" value = "'
							+ data.ceList[i].cul_placeName
							+ '" />'
							+ '<input type = "hidden" class="cate_no" value = "'
							+ data.ceList[i].cate_no + '" />'
					}
					$(".culWrap").append(str);
				}
			});
}