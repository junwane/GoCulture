	$("document").ready(function() {
		var formObj = $("form[role='form']");

		$(".btn-warning").on("click", function() {

			formObj.attr("action", "noticeBoardModi");
			formObj.attr("method", "get");
			formObj.submit();
		});

		$("#remove").on("click", function() {
			formObj.attr("action", "remove");
			formObj.submit();
		});

		$("#listAll").on("click", function() {
			//self.location = "noticeBoard?page=${criteria.page}&recordsPerPage=${criteria.recordsPerPage}";

			formObj.attr("action", "/yg/noticeBoard");
			formObj.attr("method", "get");
			formObj.submit();
		});
		
		$("#frn").on("click",function(){
			formObj.submit();//수정버튼
		});
	});
	
	$(function(){
	    //전역변수
	    var obj = [];              
	    //스마트에디터 프레임생성
	    nhn.husky.EZCreator.createInIFrame({
	        oAppRef: obj,
	        elPlaceHolder: "nb_content",
	        sSkinURI: "./resources/smarteditor2-master/dist/SmartEditor2Skin.html",
	        htParams : {
	            // 툴바 사용 여부 (true:사용/ false:사용하지 않음)
	            bUseToolbar : true,            
	            // 입력창 크기 조절바 사용 여부 (true:사용/ false:사용하지 않음)
	            bUseVerticalResizer : true,    
	            // 모드 탭(Editor | HTML | TEXT) 사용 여부 (true:사용/ false:사용하지 않음)
	            bUseModeChanger : true,
	        }
	    });
	    //전송버튼
	    $("#frn").click(function(){
	        //id가 smarteditor인 textarea에 에디터에서 대입
	        obj.getById["nb_content"].exec("UPDATE_CONTENTS_FIELD", []);
	        //폼 submit
	        submit();
	    })
	    $("#save").click(function(){
	        //id가 smarteditor인 textarea에 에디터에서 대입
	        obj.getById["nb_content"].exec("UPDATE_CONTENTS_FIELD", []);
	        //폼 submit
	        submit();
	    })
	})   