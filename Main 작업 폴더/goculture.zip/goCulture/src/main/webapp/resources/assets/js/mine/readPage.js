	$("document").ready(function() {
		var formObj = $("form[role='form']");

		$("#modify").on("click", function() {
			formObj.attr("action", "modify");
			formObj.append($("#writer"));
			formObj.append($("#content"));
			formObj.append($("#title"));
			formObj.submit();
		});

		$("#remove").on("click", function() {
			formObj.attr("action", "remove");
			formObj.submit();
		});

		$("#listAll").on("click", function() {
			//self.location = "listPage?page=${criteria.page}&recordsPerPage=${criteria.recordsPerPage}";

			formObj.attr("action", "listPage");
			formObj.attr("method", "get");
			formObj.submit();

		});
	});