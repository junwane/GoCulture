//관람 후기
function showme(v, id){
	if(v=="show"){
		document.getElementById(id).style.display="none";
		document.getElementById(v).id = "none";
	}else if(v=="none"){
		document.getElementById(id).style.display="block";
		document.getElementById(v).id = "show";
	}
}
//관람 문의
function showmeQ(v, id){
	if(v=="showQ"){
		document.getElementById(id).style.display="none";
		document.getElementById(v).id = "noneQ";
	}else if(v=="noneQ"){
		document.getElementById(id).style.display="block";
		document.getElementById(v).id = "showQ";
	}
}

//목록
$(".list").on("click", function(){
	var cate_no = $("#cate_no").val();
	location.href="cateInner?cate_no="+cate_no;
});

//위치 표시
var map
var markerLayer;
var tdata;
var name = '';

map = new Tmap.Map({
	div : 'map_div',
	width : '100%',
	height : '400px',
	transitionEffect : "resize",
	animation : true
});
map.setCenter(new Tmap.LonLat($("#latitude").val(), $("#hardness").val()), 20);
// map.addControl(new Tmap.Control.KeyboardDefaults());
map.addControl(new Tmap.Control.MousePosition());
// searchRoute();

addMarkerLayer();

var options = {
        label:new Tmap.Label($("#placeName").val()),
        lonlat:new Tmap.LonLat($("#latitude").val(), $("#hardness").val())
    };
addMarker(options);

function addMarkerLayer(){
    markerLayer = new Tmap.Layer.Markers("marker");
    map.addLayer(markerLayer);
};

function addMarker(options){
    var size = new Tmap.Size(23,30);
    var offset = new Tmap.Pixel(-(size.w/2), -size.h);
    var icon = new Tmap.Icon("http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",size,offset);
    var marker = new Tmap.Markers(options.lonlat,icon,options.label);
    markerLayer.addMarker(marker);
    marker.events.register("mouseover", marker, onOverMouse);
    marker.events.register("mouseout", marker, onOutMouse);
}
function onOverMouse(e){
    this.popup.show();
}
function onOutMouse(e){
    this.popup.hide();
}