$(document).ready(function(){
	$(".transitCon").hide();
	$(".naviCon").hide();
	$(".reviewList > .reviewContent").css("display",'none');
});
//관람 후기
function showme(v, id) {
	var check = v.substring(0,4);
	if (check == "show") {
		document.getElementById(id).style.display = "none";
		document.getElementById(v).id = "none"+id;
	} else if (check == "none") {
		document.getElementById(id).style.display = "block";
		document.getElementById(v).id = "show"+id;
	}
}
//관람 문의
function showmeQ(v, id) {
	if (v == "showQ") {
		document.getElementById(id).style.display = "none";
		document.getElementById(v).id = "noneQ";
	} else if (v == "noneQ") {
		document.getElementById(id).style.display = "block";
		document.getElementById(v).id = "showQ";
	}
}
//길찾기 출발지 show/hide
$(".transit").on("click", function(){
	var check = $(".transitCon").attr('id');
	
	if(check == 'hide'){
		$(".transitCon").show();
		$(".transitCon").attr('id','show');
	}else{
		$(".transitCon").hide();
		$(".transitCon").attr('id','hide');
	}
});
//네비 출발지 show/hide
$(".navi").on("click", function(){
	var check = $(".naviCon").attr('id');
	
	if(check == 'hide'){
		$(".naviCon").show();
		$(".naviCon").attr('id','show');
	}else{
		$(".naviCon").hide();
		$(".naviCon").attr('id','hide');
	}
});

//길찾기 gogo
$(".transitResult").on("click", function(){
	$("#map_div").removeClass();
	$("#map_div").empty();
	gMap();
});

//네비 gogo
$(".naviResult").on("click",function(){
	var startX	= $("#naviStartLat").val();
	var startY	= $("#naviStartLon").val();
	var endX	= $("#latitude").val();
	var endY	= $("#hardness").val();
	
    var urlnavi="https://apis.skplanetx.com/tmap/routes?version=1";

   urlnavi += "&startX="+startX;
   urlnavi += "&startY="+startY;
   
   urlnavi += "&endX="+endX;
   urlnavi += "&endY="+endY;
   urlnavi += "&appKey=da7b6bd4-2dc6-3dfb-aa2e-bbd59150b051";
   $.ajax({

       url:urlnavi,
       type:"POST",
       success:function(data){
           console.log(data);
           
           naviArray=data.features;

       }
   });
});


//목록
$(".list").on("click", function() {
	var cate_no = $("#cate_no").val();
	location.href = "cateInner?cate_no=" + cate_no + "&filter=1&latitude=0&hardness=0";
});

//위치 표시
var map
var markerLayer;
var tdata;
var name = '';

map = new Tmap.Map({
	div : 'map_div',
	width : '100%',
	height : '400px',
	transitionEffect : "resize",
	animation : true
});
map.setCenter(new Tmap.LonLat($("#latitude").val(), $("#hardness").val()), 20);
// map.addControl(new Tmap.Control.KeyboardDefaults());
map.addControl(new Tmap.Control.MousePosition());
// searchRoute();

addMarkerLayer();

var options = {
	label : new Tmap.Label($("#placeName").val()),
	lonlat : new Tmap.LonLat($("#latitude").val(), $("#hardness").val())
};
addMarker(options);

function addMarkerLayer() {
	markerLayer = new Tmap.Layer.Markers("marker");
	map.addLayer(markerLayer);
};

function addMarker(options) {
	var size = new Tmap.Size(23, 30);
	var offset = new Tmap.Pixel(-(size.w / 2), -size.h);
	var icon = new Tmap.Icon(
			"http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",
			size, offset);
	var marker = new Tmap.Markers(options.lonlat, icon, options.label);
	markerLayer.addMarker(marker);
	marker.events.register("mouseover", marker, onOverMouse);
	marker.events.register("mouseout", marker, onOutMouse);
}
function onOverMouse(e) {
	this.popup.show();
}
function onOutMouse(e) {
	this.popup.hide();
}

function gMapSet(map){
	directionsDisplay = new google.maps.DirectionsRenderer({
		suppressMarkers : true
	});
	var chicago = new google.maps.LatLng(35.871344882897404, 128.60067330523393);
	var mapOptions = {
		zoom : 11,
		mapTypeId : google.maps.MapTypeId.ROADMAP,
		center : chicago
	}
	map = new google.maps.Map(document.getElementById('map_div'),
			mapOptions);
	directionsDisplay.setMap(map);
}

function calcRoute(map,directionsService) {
	gMapSet(map);
	var start = $("#startName").val();
	var end = $("#placeName").val();
	var mode = 'TRANSIT';

	var icons = {
		start : new google.maps.MarkerImage(
		// URL
		'http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico',
		// (width,height)
		new google.maps.Size(80, 80),
		// The origin point (x,y)
		new google.maps.Point(0, 0),
		// The anchor point (x,y)
		new google.maps.Point(40, 80)),
		end : new google.maps.MarkerImage(
		// URL
		'http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico',
		// (width,height)
		new google.maps.Size(80, 80),
		// The origin point (x,y)
		new google.maps.Point(0, 0),
		// The anchor point (x,y)
		new google.maps.Point(40, 80))
	};

	var request = {
		origin : start,
		destination : end,
		travelMode : eval("google.maps.DirectionsTravelMode." + mode)
	};
	directionsService.route(request, function(response, status) {
		if (status == google.maps.DirectionsStatus.OK) {
			directionsDisplay.setDirections(response);
			var leg = response.routes[0].legs[0];
			makeMarker(leg.start_location, icons.start, "현위치 : "
					+ leg.start_address);
			makeMarker(leg.end_location, icons.end, "목적지 : "
					+ leg.end_address);
		}
	});

	function makeMarker(position, icon, title) {
		var markers = new google.maps.Marker({
			position : position,
			map : map,
			icon : icon,
			title : title
		});

		var data = title;
		var infowindow = new google.maps.InfoWindow({
			content : data
		});

		google.maps.event.addListener(markers, 'click', function() {
			infowindow.open(map, markers);
		});

	}

}

function gMap() {
	var directionsDisplay;
	var directionsService = new google.maps.DirectionsService();
	var map;

	gMapSet(map);
	calcRoute(map,directionsService);

	google.maps.event.addDomListener(window, 'load', gMapSet());
}

var clcl;   // 장소
$(".placeSerch").on("click", function(){
   clcl = true;

   $("#ul").empty();   // 태그제거
   var placeName = $("#startName").val();

   searchPOI(placeName);   // 검색
   
   getDataFromLonLat($("#startName").lonlat);   // 주소

});
$(".naviPlaceSerch").on("click", function(){
	   clcl = false;

	   $("#ul1").empty();   // 태그제거
	   var placeName = $("#naviStartName").val();

	   searchPOI(placeName);   // 검색
	   
	   getDataFromLonLat($("#naviStartName").lonlat);   // 주소

	});

function searchPOI(placeName){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTData);
    var center = map.getCenter();
    tdata.getPOIDataFromSearch(encodeURIComponent(placeName), {centerLon:center.lon, centerLat:center.lat});
}
function onCompleteTData(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var id = jQuery(this).find("id").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTData);
}
function getDataFromLonLat(lonlat){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTDataLonLat);
    tdata.getPOIDataFromLonLat(lonlat, encodeURIComponent("편의점"), {bizAppId:"701a4eaf1326", radius:1});
}
function onCompleteTDataLonLat(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
          if(clcl == true) {
               $("#ul").append("<li id = '"+name+"'>" + name + "</li>" 
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          } else if (clcl == false) {
             $("#ul1").append("<li id = '"+name+"'>" + name + "</li>"
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          }
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    
   // map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTDataLonLat);
}

$("#ul").on("click", "li", function() {
	var placeName	= $(this).prop("id");
	var placeX		= $(this).next().val();
	var placeY		= $(this).next().next().val();
	
	$("#startName").val(placeName);
	$("#startLat").val(placeX);
	$("#startLon").val(placeY);
	
	$("#ul").empty();
});
$("#ul1").on("click", "li", function() {
	var placeName	= $(this).prop("id");
	var placeX		= $(this).next().val();
	var placeY		= $(this).next().next().val();
	
	$("#naviStartName").val(placeName);
	$("#naviStartLat").val(placeX);
	$("#naviStartLon").val(placeY);
	
	$("#ul1").empty();
});

$(".reply").on("click", function(event){
	event.preventDefault();
	var rq_division = $(this).attr("id");
	var cul_no		= $("#cul_no"+rq_division).val();
	var m_no		= $("#m_no"+rq_division).val();
	var rq_title	= $("#rq_title"+rq_division).val();
	var rq_content	= $("#rq_content"+rq_division).val();
	var rq_open		= $("#rq_open"+rq_division).is(":checked");
	
	$("#rq_title"+rq_division).val("");
	$("#rq_content"+rq_division).val("");
	rq_division		= $("#rq_division"+rq_division).val();
	
	var date = new Date();
	var year	= date.getFullYear();
	var month	= date.getMonth()+1;
	var day		= date.getDate()
	
	$.ajax({
		url : "rqRegister",
		data :{
			cul_no		: cul_no,
			m_no		: m_no,
			rq_title	: rq_title,
			rq_content	: rq_content,
			rq_division	: rq_division,
			rq_open		: rq_open
		},
		type : "post",
		success:function(data){
			var str = '<div class="margin-bottom-20">'
					+'</div>'
					+'<a id="none'+date+'" onclick="showme(this.id,'+date.getTime()+');"><b class="size">'+rq_title+'</b></a>&nbsp;&nbsp;&nbsp;'+m_no+'&nbsp;&nbsp;'+year+'.'+month+'.'+day
					+'<div class="margin-bottom-5">'
					+'</div>'
					+'<div id="'+date.getTime()+'">'
						+'<p class="comm">'
							+rq_content
						+'</p>'
					+'</div>'
					+'<div class="margin-bottom-40">'
					+'</div>'
					+'<hr class="hr"/>'
			$("#review").append(str);
			document.getElementById(date.getTime()).style.display = "none";
		}
	});
});

$("#memTicketing").on("click", function(event) {

	event.preventDefault();
	var reservation = confirm("예매하시겠습니까?");
	if (reservation) {
		var cul_no = getQuerystring('cul_no');
		var m_email = $("#m_email").val();	
		var t_quantity =$("#t_quantity").val();
		var t_totalPrice =$("#t_totalPrice").val();

		$.ajax({
			url : "memTicketing",
			type : "post",
			data : { 
				m_email : m_email,
				cul_no: cul_no,
				t_quantity:t_quantity,
				t_totalPrice:t_totalPrice
			},
			success : function(data) {
				window.alert("예매되었습니다!");
			},error : function(data) {
				alert(data+"데이터다아아아아ㅏ아아아아ㅏㄱ");
			}
		});
	}
});


$(":input").bind('keyup mouseup',function() {
					price = $('.priceNum').val(); // 가격
					price1 = $('.price1').val(); // 매수

					var t_totalPrice = price * price1

					var prices = $('.fullprice').length;

					if (prices > 0) {
						$('.size').remove();
					}
					$('.fullprice').append("<div class='size'><h2>결제금액: "
											+ t_totalPrice
											+ "원</h2></div>"
											+ "<input type='hidden' id = 't_totalPrice' value='"
											+ t_totalPrice + "' />");
				});



function getQuerystring(paramName) {
	var _tempUrl = window.location.search.substring(1);
	var _tempArray = _tempUrl.split('&'); // '&'을 기준으로 분리하기
	for (var i = 0; _tempArray.length; i++) {
		var _keyValuePair = _tempArray[i].split('=');
		if(_keyValuePair[0] == paramName){
			return _keyValuePair[1];
		}
	}

}