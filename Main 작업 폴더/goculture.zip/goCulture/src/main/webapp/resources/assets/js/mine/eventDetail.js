$(document).ready(function(){
	$(".transitCon").hide();
	$(".naviCon").hide();
	$(".reviewList > .reviewContent").css("display",'none');
});
//관람 후기
function showme(v, id) {
	var check = v.substring(0,4);
	if (check == "show") {
		document.getElementById(id).style.display = "none";
		document.getElementById(v).id = "none"+id;
	} else if (check == "none") {
		document.getElementById(id).style.display = "block";
		document.getElementById(v).id = "show"+id;
	}
}
//관람 문의
function showmeQ(v, id) {
	if (v == "showQ") {
		document.getElementById(id).style.display = "none";
		document.getElementById(v).id = "noneQ";
	} else if (v == "noneQ") {
		document.getElementById(id).style.display = "block";
		document.getElementById(v).id = "showQ";
	}
}
//길찾기 출발지 show/hide
$(".transit").on("click", function(){
	var check = $(".transitCon").attr('id');
	
	if(check == 'hide'){
		$(".transitCon").show();
		$(".transitCon").attr('id','show');
	}else{
		$(".transitCon").hide();
		$(".transitCon").attr('id','hide');
	}
});
//네비 출발지 show/hide
$(".navi").on("click", function(){
	var check = $(".naviCon").attr('id');
	
	if(check == 'hide'){
		$(".naviCon").show();
		$(".naviCon").attr('id','show');
	}else{
		$(".naviCon").hide();
		$(".naviCon").attr('id','hide');
	}
});

//길찾기 gogo
$(".transitResult").on("click", function(){
	$("#map_div").removeClass();
	$("#map_div").empty();
	gMap();
});

//네비 gogo
$(".naviResult").on("click",function(){
	var startX	= $("#naviStartLat").val();
	var startY	= $("#naviStartLon").val();
	var endX	= $("#latitude").val();
	var endY	= $("#hardness").val();
	
    var urlnavi="https://apis.skplanetx.com/tmap/routes?version=1";

   urlnavi += "&startX="+startX;
   urlnavi += "&startY="+startY;
   
   urlnavi += "&endX="+endX;
   urlnavi += "&endY="+endY;
   urlnavi += "&appKey=da7b6bd4-2dc6-3dfb-aa2e-bbd59150b051";
   $.ajax({

       url:urlnavi,
       type:"POST",
       success:function(data){
           console.log(data);
           
           naviArray=data.features;

       }
   });
});


//목록
$(".list").on("click", function() {
	var cate_no = $("#cate_no").val();
	location.href = "cateInner?cate_no=" + cate_no + "&filter=1&latitude=0&hardness=0";
});

//위치 표시
var map
var markerLayer;
var tdata;
var name = '';

map = new Tmap.Map({
	div : 'map_div',
	width : '100%',
	height : '400px',
	transitionEffect : "resize",
	animation : true
});
map.setCenter(new Tmap.LonLat($("#latitude").val(), $("#hardness").val()), 20);
// map.addControl(new Tmap.Control.KeyboardDefaults());
map.addControl(new Tmap.Control.MousePosition());
// searchRoute();

addMarkerLayer();

var options = {
	label : new Tmap.Label($("#placeName").val()),
	lonlat : new Tmap.LonLat($("#latitude").val(), $("#hardness").val())
};
addMarker(options);

function addMarkerLayer() {
	markerLayer = new Tmap.Layer.Markers("marker");
	map.addLayer(markerLayer);
};

function addMarker(options) {
	var size = new Tmap.Size(23, 30);
	var offset = new Tmap.Pixel(-(size.w / 2), -size.h);
	var icon = new Tmap.Icon(
			"http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",
			size, offset);
	var marker = new Tmap.Markers(options.lonlat, icon, options.label);
	markerLayer.addMarker(marker);
	marker.events.register("mouseover", marker, onOverMouse);
	marker.events.register("mouseout", marker, onOutMouse);
}
function onOverMouse(e) {
	this.popup.show();
}
function onOutMouse(e) {
	this.popup.hide();
}

function gMapSet(map){
	directionsDisplay = new google.maps.DirectionsRenderer({
		suppressMarkers : true
	});
	var chicago = new google.maps.LatLng(35.871344882897404, 128.60067330523393);
	var mapOptions = {
		zoom : 11,
		mapTypeId : google.maps.MapTypeId.ROADMAP,
		center : chicago
	}
	map = new google.maps.Map(document.getElementById('map_div'),
			mapOptions);
	directionsDisplay.setMap(map);
}

function calcRoute(map,directionsService) {
	gMapSet(map);
	var start = $("#startName").val();
	var end = $("#placeName").val();
	var mode = 'TRANSIT';

	var icons = {
		start : new google.maps.MarkerImage(
		// URL
		'http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico',
		// (width,height)
		new google.maps.Size(80, 80),
		// The origin point (x,y)
		new google.maps.Point(0, 0),
		// The anchor point (x,y)
		new google.maps.Point(40, 80)),
		end : new google.maps.MarkerImage(
		// URL
		'http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico',
		// (width,height)
		new google.maps.Size(80, 80),
		// The origin point (x,y)
		new google.maps.Point(0, 0),
		// The anchor point (x,y)
		new google.maps.Point(40, 80))
	};

	var request = {
		origin : start,
		destination : end,
		travelMode : eval("google.maps.DirectionsTravelMode." + mode)
	};
	directionsService.route(request, function(response, status) {
		if (status == google.maps.DirectionsStatus.OK) {
			directionsDisplay.setDirections(response);
			var leg = response.routes[0].legs[0];
			makeMarker(leg.start_location, icons.start, "현위치 : "
					+ leg.start_address);
			makeMarker(leg.end_location, icons.end, "목적지 : "
					+ leg.end_address);
		}
	});

	function makeMarker(position, icon, title) {
		var markers = new google.maps.Marker({
			position : position,
			map : map,
			icon : icon,
			title : title
		});

		var data = title;
		var infowindow = new google.maps.InfoWindow({
			content : data
		});

		google.maps.event.addListener(markers, 'click', function() {
			infowindow.open(map, markers);
		});

	}

}

function gMap() {
	var directionsDisplay;
	var directionsService = new google.maps.DirectionsService();
	var map;

	gMapSet(map);
	calcRoute(map,directionsService);

	google.maps.event.addDomListener(window, 'load', gMapSet());
}

var clcl;   // 장소
$(".placeSerch").on("click", function(){
   clcl = true;

   $("#ul").empty();   // 태그제거
   var placeName = $("#startName").val();

   searchPOI(placeName);   // 검색
   
   getDataFromLonLat($("#startName").lonlat);   // 주소

});
$(".naviPlaceSerch").on("click", function(){
	   clcl = false;

	   $("#ul1").empty();   // 태그제거
	   var placeName = $("#naviStartName").val();

	   searchPOI(placeName);   // 검색
	   
	   getDataFromLonLat($("#naviStartName").lonlat);   // 주소

	});

function searchPOI(placeName){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTData);
    var center = map.getCenter();
    tdata.getPOIDataFromSearch(encodeURIComponent(placeName), {centerLon:center.lon, centerLat:center.lat});
}
function onCompleteTData(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var id = jQuery(this).find("id").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTData);
}
function getDataFromLonLat(lonlat){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTDataLonLat);
    tdata.getPOIDataFromLonLat(lonlat, encodeURIComponent("편의점"), {bizAppId:"701a4eaf1326", radius:1});
}
function onCompleteTDataLonLat(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
          if(clcl == true) {
               $("#ul").append("<li id = '"+name+"'>" + name + "</li>" 
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          } else if (clcl == false) {
             $("#ul1").append("<li id = '"+name+"'>" + name + "</li>"
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          }
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    
   // map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTDataLonLat);
}

$("#ul").on("click", "li", function() {
	var placeName	= $(this).prop("id");
	var placeX		= $(this).next().val();
	var placeY		= $(this).next().next().val();
	
	$("#startName").val(placeName);
	$("#startLat").val(placeX);
	$("#startLon").val(placeY);
	
	$("#ul").empty();
});
$("#ul1").on("click", "li", function() {
	var placeName	= $(this).prop("id");
	var placeX		= $(this).next().val();
	var placeY		= $(this).next().next().val();
	
	$("#naviStartName").val(placeName);
	$("#naviStartLat").val(placeX);
	$("#naviStartLon").val(placeY);
	
	$("#ul1").empty();
});

$(".reply").on("click", function(event){
	event.preventDefault();
	var rq_division = $(this).attr("id");
	var cul_no		= $("#cul_no"+rq_division).val();
	var m_no		= $("#m_no"+rq_division).val();
	var rq_title	= $("#rq_title"+rq_division).val();
	var rq_content	= $("#rq_content"+rq_division).val();
	var rq_open		= $("#rq_open"+rq_division).is(":checked");
	
	$("#rq_title"+rq_division).val("");
	$("#rq_content"+rq_division).val("");
	rq_division		= $("#rq_division"+rq_division).val();
	
	var date = new Date();
	var year	= date.getFullYear();
	var month	= date.getMonth()+1;
	var day		= date.getDate()
	
	$.ajax({
		url : "rqRegister",
		data :{
			cul_no		: cul_no,
			m_no		: m_no,
			rq_title	: rq_title,
			rq_content	: rq_content,
			rq_division	: rq_division,
			rq_open		: rq_open
		},
		type : "post",
		success:function(data){
			var str = '<div class="margin-bottom-20">'
					+'</div>'
					+'<a id="none'+date+'" onclick="showme(this.id,'+date.getTime()+');"><b class="size">'+rq_title+'</b></a>&nbsp;&nbsp;&nbsp;'+m_no+'&nbsp;&nbsp;'+year+'.'+month+'.'+day
					+'<div class="margin-bottom-5">'
					+'</div>'
					+'<div id="'+date.getTime()+'">'
						+'<p class="comm">'
							+rq_content
						+'</p>'
					+'</div>'
					+'<div class="margin-bottom-40">'
					+'</div>'
					+'<hr class="hr"/>'
			$("#review").append(str);
			document.getElementById(date.getTime()).style.display = "none";
		}
	});
});

$("#extraGCList").on("change",function(){
	var point = $("#extraGCList option:selected").val();
	$("#extraGCPoint").html("사용 가능 포인트 : "+point+"P");
});

$("#t_quantity").on("change",function(){
	var quantity	= $("#t_quantity").val()*1;
	var mPoint		= $("#mPoint").val()*1;
	var gcPoint		= $("#gcPoint").val()*1;
	var price		= $("#cul_price").html()*1;
	
	var totalPrice	= (quantity*price)-mPoint-gcPoint;
	
	if(totalPrice < 0){
		alert("0원 이하로는 사용할 수 없습니다.");
		$("#t_quantity").val(1);
		$("#mPoint").val(0);
		$("#gcPoint").val(0);
		$("#htotalPrice").val(price);
		$("#totalPrice").html("결제금액: "+price+"원");
	}else{
		$("#htotalPrice").val(totalPrice);
		$("#totalPrice").html("결제금액: "+totalPrice+"원");	
	}
});

$("#mPointBtn, #gcPointBtn").on("click",function(){
	if($(this).attr('id') == 'gcPointBtn'){
		var extraPoint = $("#extraGCList option:selected").val()*1;
		var inputPoint = $("#gcPoint").val()*1;
		if(extraPoint < inputPoint){
			alert("해당 카드의 잔여 포인트 보다 많은 금액을 입력하셨습니다.");
			 $("#gcPoint").val(0);
			 return false;
		}
	}else{
		var mtotalPoint = $("#mtotalPoint").val();
		var mPoint		= $("#mPoint").val()*1;
		if(mtotalPoint < mPoint){
			alert("회원님의 포인트 보다 많은 포인트를 입력하셨습니다.");
			 $("#mPoint").val(0);
			 return false;
		}
	}
	
	var quantity	= $("#t_quantity").val()*1;
	var mPoint		= $("#mPoint").val()*1;
	var gcPoint		= $("#gcPoint").val()*1;
	var price		= $("#cul_price").html()*1;
	
	var totalPrice	= (quantity*price)-mPoint-gcPoint;
	
	if(totalPrice < 0){
		alert("0원 이하로는 사용할 수 없습니다.");
		$("#t_quantity").val(1);
		$("#mPoint").val(0);
		$("#gcPoint").val(0);
		$("#totalPrice").html("결제금액: "+price+"원");
		$("#htotalPrice").val(price);
	}else{
		$("#htotalPrice").val(totalPrice);
		$("#totalPrice").html("결제금액: "+totalPrice+"원");	
	}
});

$("#memTicketing").on("click",function(){
	var t_totalPrice	= $("#htotalPrice").val()*1;						// 총 가격
	var t_quantity		= $("#t_quantity").val()*1;							// 예매 수량
	var p_point			= $("#mPoint").val()*1;								// 포인트 사용
	var gcu_point		= $("#gcPoint").val()*1;							// 기프트 카드 사용
	var m_no 			= $("#m_no").val();									// 회원 번호
	var cul_no			= $("#cul_no").val();								// 모임 번호
	var gcu_content	 	= $(".cul_title").html();							// 모임 제목
	var p_useHistory	= $(".cul_title").html();							// 모임 제목
	var gc_no			= $("#extraGCList option:selected").attr('id');		// 기프트 카드 번호
	
	$.ajax({
		url : "memTicketing",
		data :{
			t_totalPrice	: t_totalPrice,
			t_quantity		: t_quantity,
			p_point			: p_point,
			gcu_point		: gcu_point,
			m_no 			: m_no,
			cul_no			: cul_no,
			gcu_content	 	: gcu_content,
			p_useHistory	: p_useHistory,
			gc_no			: gc_no
		},
		type : "post",
		success:function(data){
			$("#t_quantity").val(1);
			$("#mPoint").val(0);
			$("#gcPoint").val(0);
			$("#totalPrice").html("결제금액: "+t_totalPrice/t_quantity+"원");
			$("#htotalPrice").val(t_totalPrice/t_quantity);
			$("#extraGCList").val("0").prop("selected", true);
			$("#extraGCPoint").html("사용 가능 포인트 : 0P");
			var check = confirm("예매가 완료 되었습니다. 예매 목록창으로 이동하시겠습니까?");
			alert(check);
		},error:function(err){
			alert(err);
		}
	});	
});

$("#nonMemTicketing").on("click",function(){
	var t_totalPrice	= $("#htotalPrice").val()*1;									// 총 가격
	var t_quantity		= $("#t_quantity").val()*1;										// 예매 수량
	var cul_no			= $("#cul_no").val();											// 모임 번호
	var nm_name			= $("#nm_name").val();											// 비회원 이름
	var nm_phone		 	= $("#nm_pn1").val()+$("#nm_pn2").val()+$("#nm_pn3").val();	
	var nm_phoneNum     = parseInt(nm_phone);											
	var nm_residentNum	= $("#nm_residentNum1").val()+$("#nm_residentNum2").val();		// 비회원 번호
	$.ajax({
		url : "nonMemTicketing",
		data :{
			t_totalPrice	: t_totalPrice,
			t_quantity		: t_quantity,
			cul_no			: cul_no,
			nm_name			: nm_name,
			nm_phoneNum		: nm_phoneNum,
			nm_residentNum  : nm_residentNum
		},
		type : "post",
		success:function(data){
			$("#t_quantity").val(1);
			$("#totalPrice").html("결제금액: "+t_totalPrice/t_quantity+"원");
			$("#htotalPrice").val(t_totalPrice/t_quantity);
			var check = confirm("예매가 완료 되었습니다. 예매 목록창으로 이동하시겠습니까?");
			alert(nm_phoneNum +"and"+ nm_residentNum);
		},error:function(err){
			alert(err);
		}
	});	
});

$(".close").on("click", function(){
	var t_totalPrice	= $("#htotalPrice").val()*1;	
	var t_quantity		= $("#t_quantity").val()*1;	
	
	$("#t_quantity").val(1);
	$("#mPoint").val(0);
	$("#gcPoint").val(0);
	$("#totalPrice").html("결제금액: "+t_totalPrice/t_quantity+"원");
	$("#htotalPrice").val(t_totalPrice/t_quantity);
	$("#extraGCList").val("0").prop("selected", true);
});


