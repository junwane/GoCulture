//페이지 로드되자마자 지도 그리고 위치랑 지도 hide
$(document).ready(function(){
	mapSet();
	cateMap();
	$("#place").hide();
	$("#map_div").hide();
});

//지도 show/hide
$(document).on("click", "#showMap", function(){
	if($("#showMap").html()=="showMap"){
		$("#showMap").html("hideMap");
		$("#map_div").show();
	}else{
		$("#showMap").html("showMap");
		$("#map_div").hide();
	}
});

//문화행사 클릭 시 해당 문화행사 상세 페이지로 이동
$(document).on("click",".ceInner",function(){
	var cul_no = $(this).attr("id");
	location.href="eventDetail?cul_no="+cul_no;
});

//검색 후 리스트 클릭
$("#ul").on("click", "li", function() {
	mapSet();
	
	var filter		= 2;
	var placeName	= $(this).prop("id");
	var latitude	= $(this).next().val();
	var hardness	= $(this).next().next().val();   
	var cate_no		= $(".cate_no").val();
	
	var pr_3857 = new Tmap.Projection("EPSG:3857");
	var pr_4326 = new Tmap.Projection("EPSG:4326");
	var lonlat = new Tmap.LonLat(latitude, hardness).transform(pr_3857, pr_4326);

	
	latitude = lonlat.lat;
	hardness = lonlat.lon;
	
   $("#ul").empty();
   $("#placeName").val("");
   $("#cul_latitude").val(latitude);
   $("#cul_hardness").val(hardness);
   $("#myPlace").html(placeName);
   
   $.ajax({
		url : "Chcate",
		data :{
			filter		: filter,
			cate_no		: cate_no,
			latitude	: latitude,
			hardness	: hardness
		},
		type : "get",
		success:function(data){
			console.log(data);
			$(".culWrap").empty();
			var str = '<div id="map_div"></div>'
			for(var i in data.ceList){
				str += '<div class="col-xl-3 culList">'
				 	+'<div class="ui-block video-item border">'
						+'<div class="video-player ceInner" id = "'+data.ceList[i].cul_no+'">'
							+'<img src="displayFile?fileName=/s_'+data.ceList[i].cul_mainImg+'" />'
						+'</div>'
						+'<div class="ui-block-content video-content">'
								+'<a class="h4 ceInner" id = "'+data.ceList[i].cul_no+'">'+data.ceList[i].cul_title+'</a>'
							+'<ul>'
								+'<li class="inline-items center">'
									+'<div class="notification-event">'
										+'<br> <div class="h5 notification-friend">'+data.ceList[i].cul_startDate
											+'~ '+data.ceList[i].cul_endDate+'</div><br> <span class="chat-message-item">'+'가격'
											+data.ceList[i].cul_price+'</span><br> <span class="chat-message-item">'+data.ceList[i].cul_placeName+'</span>'
									+'</div>'
								+'</li>'
							+'</ul>'
						+'</div>'
						+'<input type = "hidden" class = "cul_latitude" name = "cul_latitude" value = "'+data.ceList[i].cul_latitude+'" />'
						+'<input type = "hidden" class = "cul_hardness" name = "cul_hardness" value = "'+data.ceList[i].cul_hardness+'" />'
						+'<input type = "hidden" class = "cul_placeName" name = "cul_placeName" value = "'+data.ceList[i].cul_placeName+'" />'
					+'</div>'
				+'</div>'
			}
			str += '<input type = "hidden" id="cate_no" value = "'+data.ceList[0].cate_no+'" />'
			$(".culWrap").append(str);
			cateMap();
			$("#map_div").hide();
		}
	});
   
});

var clcl; //장소
//위치 검색
$(document).on("click","#placeSearch", function(){
	clcl = true;

    $("#ul").empty();   // 태그제거
    var placeName = $("#placeName").val();

    searchPOI(placeName);   // 검색
    
    getDataFromLonLat($("#placeName").lonlat);   // 주소
	
	$("#myPlace").html(placeName);
	
});

function search_lo(v, id) {
	if (v == "show") {
		document.getElementById(id).style.display = "none";
		document.getElementById(v).id = "none";
	} else if (v == "none") {
		document.getElementById(id).style.display = "block";
		document.getElementById(v).id = "show";
	}
}

//목록의 위도 경도  표시
var latitude = $(".cul_latitude");
var hardness = $(".cul_hardness");
var placeName = $(".cul_placeName");

//위치 표시
var map
var markerLayer;
var tdata;
var name = '';
function mapSet(){
	map = new Tmap.Map({
		div : 'map_div',
		width : '100%',
		height : '400px',
		transitionEffect : "resize",
		animation : true
	});
}
//지도
function cateMap(){
	map.setCenter(new Tmap.LonLat($(".cul_latitude").val(), $(".cul_hardness").val()), 11);
	// map.addControl(new Tmap.Control.KeyboardDefaults());
	map.addControl(new Tmap.Control.MousePosition());
	// searchRoute();

	addMarkerLayer();

	for(var i = 0 ; i < latitude.length ; i++){
		var options = {
		        label:new Tmap.Label(placeName[i].value),
		        lonlat:new Tmap.LonLat(latitude[i].value, hardness[i].value)
		    };
		addMarker(options);
	}
}

function addMarkerLayer(){
    markerLayer = new Tmap.Layer.Markers("marker");
    map.addLayer(markerLayer);
};

function addMarker(options){
    var size = new Tmap.Size(23,30);
    var offset = new Tmap.Pixel(-(size.w/2), -size.h);
    var icon = new Tmap.Icon("http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",size,offset);
    var marker = new Tmap.Markers(options.lonlat,icon,options.label);
    markerLayer.addMarker(marker);
    marker.events.register("mouseover", marker, onOverMouse);
    marker.events.register("mouseout", marker, onOutMouse);
}
function onOverMouse(e){
    this.popup.show();
}
function onOutMouse(e){
    this.popup.hide();
}
function searchPOI(placeName){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTData);
    var center = map.getCenter();
    tdata.getPOIDataFromSearch(encodeURIComponent(placeName), {centerLon:center.lon, centerLat:center.lat});
}
function onCompleteTData(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var id = jQuery(this).find("id").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
            var options = {
                label:new Tmap.Label(name),
                lonlat:new Tmap.LonLat(lon, lat)
            };
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTData);
}
function getDataFromLonLat(lonlat){
    tdata = new Tmap.TData();
    tdata.events.register("onComplete", tdata, onCompleteTDataLonLat);
    tdata.getPOIDataFromLonLat(lonlat, encodeURIComponent("편의점"), {bizAppId:"701a4eaf1326", radius:1});
}
function onCompleteTDataLonLat(e){
    if(jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != ''){
        jQuery(this.responseXML).find("searchPoiInfo pois poi").each(function(){
            var name = jQuery(this).find("name").text();
            var lon = jQuery(this).find("frontLon").text();
            var lat = jQuery(this).find("frontLat").text();
            var options = {
                label:new Tmap.Label(name),
                lonlat:new Tmap.LonLat(lon, lat)
            };
            console.log(name, lon, lat);
          
          if(clcl == true) {
               $("#ul").append("<li id = '"+name+"'>" + name + "</li>" 
                           + "<input type='hidden' value='" + lon + "'>"
                           + "<input type='hidden' value='" + lat + "'>");
          }
        });
    }else {
        alert('검색결과가 없습니다.');
    }
    map.zoomToExtent(markerLayer.getDataExtent());
    tdata.events.unregister("onComplete", tdata, onCompleteTDataLonLat);
}


$(".select").on("change",function(){
	mapSet();
	var filter		= $(this).val();
	var cate_no		= $(".cate_no").val();
	var latitude	= $("#cul_latitude").val();
	var hardness	= $("#cul_hardness").val();
	
	if(filter == 2){
		$("#place").show();
	}else{
		$("#place").hide();
	}
	
	cateList(filter, cate_no, latitude, hardness);
});

$(".category").on("click",function(){
	mapSet();
	var filter		= 1;
	var cate_no		= $(this).attr("id");
	var latitude	= 0;
	var hardness	= 0;
	
	cateList(filter, cate_no, latitude, hardness);
});

function cateList(filter, cate_no, latitude, hardness){
	$.ajax({
		url : "Chcate",
		data :{
			filter		: filter,
			cate_no		: cate_no,
			latitude	: latitude,
			hardness	: hardness
		},
		type : "get",
		success:function(data){
			$(".culWrap").empty();
			console.log(data);
			var str = '<div id="map_div"></div>'
			for(var i in data.ceList){
				str += '<div class="col-xl-3 culList">'
				 	+'<div class="ui-block video-item border">'
						+'<div class="video-player ceInner" id = "'+data.ceList[i].cul_no+'">'
							+'<img src="displayFile?fileName=/s_'+data.ceList[i].cul_mainImg+'" />'
						+'</div>'
						+'<div class="ui-block-content video-content">'
								+'<a class="h4 ceInner" id = "'+data.ceList[i].cul_no+'">'+data.ceList[i].cul_title+'</a>'
							+'<ul>'
								+'<li class="inline-items center">'
									+'<div class="notification-event">'
										+'<br> <div class="h5 notification-friend">'+data.ceList[i].cul_startDate
											+'~ '+data.ceList[i].cul_endDate+'</div><br> <span class="chat-message-item">'+'가격'
											+data.ceList[i].cul_price+'</span><br> <span class="chat-message-item">'+data.ceList[i].cul_placeName+'</span>'
									+'</div>'
								+'</li>'
							+'</ul>'
						+'</div>'
						+'<input type = "hidden" class = "cul_latitude" name = "cul_latitude" value = "'+data.ceList[i].cul_latitude+'" />'
						+'<input type = "hidden" class = "cul_hardness" name = "cul_hardness" value = "'+data.ceList[i].cul_hardness+'" />'
						+'<input type = "hidden" class = "cul_placeName" name = "cul_placeName" value = "'+data.ceList[i].cul_placeName+'" />'
					+'</div>'
				+'</div>'
				+ '<input type = "hidden" class="cate_no" value = "'+data.ceList[i].cate_no+'" />'
			}
			$(".culWrap").append(str);
			cateMap();
			$("#map_div").hide();
		}
	});
}
