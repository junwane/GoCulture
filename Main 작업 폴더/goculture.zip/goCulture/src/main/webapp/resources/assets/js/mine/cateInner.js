//페이지 로드되자마자 지도 그리고 위치랑 지도 hide
$(document).ready(function() {
	mapSet();
	cateMap();
	$("#place").hide();
	$("#map_div").hide();

});

// 지도 show/hide
$(document).on("click", "#showMap", function() {
	if ($("#showMap").html() == "showMap") {
		$("#showMap").html("hideMap");
		$("#map_div").show();
	} else {
		$("#showMap").html("showMap");
		$("#map_div").hide();
	}
});

// 문화행사 클릭 시 해당 문화행사 상세 페이지로 이동
$(document).on("click", ".ceInner", function() {
	var cul_no = $(this).attr("id");
	location.href = "eventDetail?cul_no=" + cul_no;
});

// 검색 후 리스트 클릭
$("#ul").on("click","li",function() {
					var filter = 2;
					var placeName = $(this).prop("id");
					var latitude = $(this).next().val();
					var hardness = $(this).next().next().val();
					var cate_no = $(".cate_no").val();

					var pr_3857 = new Tmap.Projection("EPSG:3857");
					var pr_4326 = new Tmap.Projection("EPSG:4326");
					var lonlat = new Tmap.LonLat(latitude, hardness).transform(
							pr_3857, pr_4326);

					latitude = lonlat.lat;
					hardness = lonlat.lon;

					$("#placeName").val("");
					$("#cul_latitude").val(latitude);
					$("#cul_hardness").val(hardness);
					$("#myPlace").html(placeName);

					$
							.ajax({
								url : "Chcate",
								data : {
									filter : filter,
									cate_no : cate_no,
									latitude : latitude,
									hardness : hardness
								},
								type : "get",
								success : function(data) {
									$(".culWrap").empty();
									var str = "";
									for ( var i in data.ceList) {
										str += '<li class="col-sm-3 col-xs-6 md-margin-bottom-30">'
											+ '<div class="team-img" id="'
											+ data.ceList[i].cul_no
											+ '">'
											+ '<img class="img-responsive ceInner" style="height: 170px;" src="displayFile?fileName=/s_'
											+ data.ceList[i].cul_mainImg
											+ '" id="'+data.ceList[i].cul_no+'"/>'
											+ '</div><br/>'
											+ '<a class="h3 ceInner" id= "'
											+ data.ceList[i].cul_no
											+ '"><b>'
											+ data.ceList[i].cul_title
											+ '</b></a>'
											+ '<h3>'
											+ data.ceList[i].cul_startDate
											+ '</h3><p> <span class="chat-message-item" class="font17">'
											+ '잔여 예매 수 : '
											+ data.ceList[i].ticketNum
											+ '</span><br> <span class="chat-message-item" class="font17">'
											+ data.ceList[i].cul_placeNum
											+ '</span><br> <span class="chat-message-item" class="font17">'
											+ '￦ '
											+ data.ceList[i].cul_price
											+ '</span></p>'
											+ '</li>'
											+ '<input type = "hidden" class = "cul_latitude" name = "cul_latitude" value = "'
											+ data.ceList[i].cul_latitude
											+ '" />'
											+ '<input type = "hidden" class = "cul_hardness" name = "cul_hardness" value = "'
											+ data.ceList[i].cul_hardness
											+ '" />'
											+ '<input type = "hidden" class = "cul_placeName" name = "cul_placeName" value = "'
											+ data.ceList[i].cul_placeName
											+ '" />'
											+ '<input type = "hidden" class="cate_no" value = "'
											+ data.ceList[i].cate_no + '" />'
									}
									cateMap();
									$(".culWrap").append(str);
									$("#map_div").hide();
								}
							});

				});

$(".select").on("change", function() {
	$("#map_div").empty();
	mapSet();
	var filter = $(this).val();
	var cate_no = $(".cate_no").val();
	var latitude = $("#cul_latitude").val();
	var hardness = $("#cul_hardness").val();

	if (filter == 2) {
		$("#place").show();
	} else {
		$("#place").hide();
	}
	cateList(filter, cate_no, latitude, hardness);
});

$(".category").on("click", function() {
	$("#map_div").empty();
	mapSet();
	var filter = $(".select").val();
	var cate_no = $(this).attr("id");
	var latitude = 0;
	var hardness = 0;

	if (filter == 2) {
		$("#place").show();
	} else {
		$("#place").hide();
	}
	cateList(filter, cate_no, latitude, hardness);
});

var clcl; // 장소
// 위치 검색
$(document).on("click", "#placeSearch", function() {
	clcl = true;

	$("#ul").empty(); // 태그제거
	var placeName = $("#placeName").val();

	searchPOI(placeName); // 검색

	getDataFromLonLat($("#placeName").lonlat); // 주소

	$("#myPlace").html(placeName);

});

function search_lo(v, id) {
	if (v == "show") {
		document.getElementById(id).style.display = "none";
		document.getElementById(v).id = "none";
	} else if (v == "none") {
		document.getElementById(id).style.display = "block";
		document.getElementById(v).id = "show";
	}
}

var latitude = '';
var hardness = '';
var placeName = '';

function placeLatLon() {
	// 목록의 위도 경도 표시
	latitude = $(".cul_latitude");
	hardness = $(".cul_hardness");
	placeName = $(".cul_placeName");
}

// 위치 표시
var map
var markerLayer;
var tdata;
var name = '';
function mapSet() {
	map = new Tmap.Map({
		div : 'map_div',
		width : '100%',
		height : '400px',
		transitionEffect : "resize",
		animation : true
	});
}
// 지도
function cateMap() {
	placeLatLon();
	console.log(latitude);
	map.setCenter(new Tmap.LonLat($(".cul_latitude").val(), $(".cul_hardness")
			.val()), 11);
	// map.addControl(new Tmap.Control.KeyboardDefaults());
	map.addControl(new Tmap.Control.MousePosition());
	// searchRoute();
	markerLayer = ''; // 마커 초기화
	addMarkerLayer();

	for (var i = 0; i < latitude.length; i++) {
		var options = {
			label : new Tmap.Label(placeName[i].value),
			lonlat : new Tmap.LonLat(latitude[i].value, hardness[i].value)
		};
		addMarker(options);
	}
}

function addMarkerLayer() {
	markerLayer = new Tmap.Layer.Markers("marker");
	map.addLayer(markerLayer);
};

function addMarker(options) {
	var size = new Tmap.Size(23, 30);
	var offset = new Tmap.Pixel(-(size.w / 2), -size.h);
	var icon = new Tmap.Icon(
			"http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",
			size, offset);
	var marker = new Tmap.Markers(options.lonlat, icon, options.label);
	markerLayer.addMarker(marker);
	marker.events.register("mouseover", marker, onOverMouse);
	marker.events.register("mouseout", marker, onOutMouse);
}
function onOverMouse(e) {
	this.popup.show();
}
function onOutMouse(e) {
	this.popup.hide();
}
function searchPOI(placeName) {
	tdata = new Tmap.TData();
	tdata.events.register("onComplete", tdata, onCompleteTData);
	var center = map.getCenter();
	tdata.getPOIDataFromSearch(encodeURIComponent(placeName), {
		centerLon : center.lon,
		centerLat : center.lat
	});
}
function onCompleteTData(e) {
	if (jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != '') {
		jQuery(this.responseXML).find("searchPoiInfo pois poi").each(
				function() {
					var name = jQuery(this).find("name").text();
					var id = jQuery(this).find("id").text();
					var lon = jQuery(this).find("frontLon").text();
					var lat = jQuery(this).find("frontLat").text();
					var options = {
						label : new Tmap.Label(name),
						lonlat : new Tmap.LonLat(lon, lat)
					};
				});
	} else {
		$('.modal-header').hide();
		$("#NoSearch").html("<br/><h3 style='text-align:center;'>검색 결과가 없습니다ㅠㅠ</h3><br/>");
	}
	map.zoomToExtent(markerLayer.getDataExtent());
	tdata.events.unregister("onComplete", tdata, onCompleteTData);
}
function getDataFromLonLat(lonlat) {
	tdata = new Tmap.TData();
	tdata.events.register("onComplete", tdata, onCompleteTDataLonLat);
	tdata.getPOIDataFromLonLat(lonlat, encodeURIComponent("편의점"), {
		bizAppId : "701a4eaf1326",
		radius : 1
	});
}
function onCompleteTDataLonLat(e) {
	if (jQuery(this.responseXML).find("searchPoiInfo pois poi").text() != '') {
		jQuery(this.responseXML).find("searchPoiInfo pois poi").each(
				function() {
					var name = jQuery(this).find("name").text();
					var lon = jQuery(this).find("frontLon").text();
					var lat = jQuery(this).find("frontLat").text();
					var options = {
						label : new Tmap.Label(name),
						lonlat : new Tmap.LonLat(lon, lat)
					};
					console.log(name, lon, lat);

					if (clcl == true) {
						$('#NoSearch').hide();
						$("#ul").append(
								"<li  style='font-size:18px;' data-dismiss='modal' id = '" + name + "'>" + name + "</li>"
										+ "<input type='hidden' value='" + lon
										+ "'>" + "<input type='hidden' value='"
										+ lat + "'>");
					}
				});
	} else {
		$('.modal-header').hide();
		$("#NoSearch").html("<br/><h3 style='text-align:center;'>검색 결과가 없습니다ㅠㅠ</h3><br/>");
	}
	map.zoomToExtent(markerLayer.getDataExtent());
	tdata.events.unregister("onComplete", tdata, onCompleteTDataLonLat);
}

function cateList(filter, cate_no, latitude, hardness) {
	$
			.ajax({
				url : "Chcate",
				data : {
					filter : filter,
					cate_no : cate_no,
					latitude : latitude,
					hardness : hardness
				},
				type : "get",
				success : function(data) {
					$(".culWrap").empty();
					var str = "";
					for ( var i in data.ceList) {
						str += '<li class="col-sm-3 col-xs-6 md-margin-bottom-30">'
							+ '<div class="team-img" id="'
							+ data.ceList[i].cul_no
							+ '">'
							+ '<img class="img-responsive ceInner" style="height: 170px;" src="displayFile?fileName=/s_'
							+ data.ceList[i].cul_mainImg
							+ '" id="'+data.ceList[i].cul_no+'"/>'
							+ '</div><br/>'
							+ '<a class="h3 ceInner" id= "'
							+ data.ceList[i].cul_no
							+ '"><b>'
							+ data.ceList[i].cul_title
							+ '</b></a>'
							+ '<h3>'
							+ data.ceList[i].cul_startDate
							+ '</h3><p> <span class="chat-message-item" class="font17">'
							+ '잔여 예매 수 : '
							+ data.ceList[i].ticketNum
							+ '</span><br> <span class="chat-message-item" class="font17">'
							+ data.ceList[i].cul_placeNum
							+ '</span><br> <span class="chat-message-item" class="font17">'
							+ '￦ '
							+ data.ceList[i].cul_price
							+ '</span></p>'
							+ '</li>'
							+ '<input type = "hidden" class = "cul_latitude" name = "cul_latitude" value = "'
							+ data.ceList[i].cul_latitude
							+ '" />'
							+ '<input type = "hidden" class = "cul_hardness" name = "cul_hardness" value = "'
							+ data.ceList[i].cul_hardness
							+ '" />'
							+ '<input type = "hidden" class = "cul_placeName" name = "cul_placeName" value = "'
							+ data.ceList[i].cul_placeName
							+ '" />'
							+ '<input type = "hidden" class="cate_no" value = "'
							+ data.ceList[i].cate_no + '" />'
					}
					cateMap();
					$(".culWrap").append(str);
					$("#showMap").html("showMap");
					$("#map_div").hide();
				}
			});
}
