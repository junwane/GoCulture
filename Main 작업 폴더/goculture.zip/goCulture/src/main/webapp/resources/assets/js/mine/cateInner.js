$(document).ready(function(){
	cateMap();
	$("#place").hide();
	$("#map_div").hide();
});
	function search_lo(v, id) {
		if (v == "show") {
			document.getElementById(id).style.display = "none";
			document.getElementById(v).id = "none";
		} else if (v == "none") {
			document.getElementById(id).style.display = "block";
			document.getElementById(v).id = "show";
		}
	}

	$(document).on("click",".ceInner",function(){
		var cul_no = $(this).attr("id");
		location.href="eventDetail?cul_no="+cul_no;
	});
	
	$("#showMap").on("click",function(){
		if($("#showMap").html()=="showMap"){
			$("#showMap").html("hideMap");
			$("#map_div").show();
		}else{
			$("#showMap").html("showMap");
			$("#map_div").hide();
		}
	});
	
	//지도
	function cateMap(){
		//목록의 위도 경도  표시
		var latitude = $(".cul_latitude");
		var hardness = $(".cul_hardness");
		var placeName = $(".cul_placeName");
		
		//위치 표시
		var map
		var markerLayer;
		var tdata;
		var name = '';
	
		map = new Tmap.Map({
			div : 'map_div',
			width : '100%',
			height : '400px',
			transitionEffect : "resize",
			animation : true
		});
		map.setCenter(new Tmap.LonLat($(".cul_latitude").val(), $(".cul_hardness").val()), 11);
		// map.addControl(new Tmap.Control.KeyboardDefaults());
		map.addControl(new Tmap.Control.MousePosition());
		// searchRoute();
	
		addMarkerLayer();
	
		for(var i = 0 ; i < latitude.length ; i++){
			var options = {
			        label:new Tmap.Label(placeName[i].value),
			        lonlat:new Tmap.LonLat(latitude[i].value, hardness[i].value)
			    };
			addMarker(options);
		}
	
		function addMarkerLayer(){
		    markerLayer = new Tmap.Layer.Markers("marker");
		    map.addLayer(markerLayer);
		};
	
		function addMarker(options){
		    var size = new Tmap.Size(23,30);
		    var offset = new Tmap.Pixel(-(size.w/2), -size.h);
		    var icon = new Tmap.Icon("http://download.seaicons.com/download/i103443/paomedia/small-n-flat/paomedia-small-n-flat-map-marker.ico",size,offset);
		    var marker = new Tmap.Markers(options.lonlat,icon,options.label);
		    markerLayer.addMarker(marker);
		    marker.events.register("mouseover", marker, onOverMouse);
		    marker.events.register("mouseout", marker, onOutMouse);
		}
		function onOverMouse(e){
		    this.popup.show();
		}
		function onOutMouse(e){
		    this.popup.hide();
		}
	}
	
	$(".select").on("change",function(){
		var filter = $(this).val();
		var cate_no = $("#cate_no").val();
		
	});
