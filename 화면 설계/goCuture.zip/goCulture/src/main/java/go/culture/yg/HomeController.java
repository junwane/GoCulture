package go.culture.yg;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}
	
	@RequestMapping(value = "/headerAf")
	public String headerAf(){
		return "headerAf";
	}
	
	@RequestMapping(value = "/headerBe")
	public String headerBe(){
		return "headerBe";
	}
	
	@RequestMapping(value = "/notification")
	public String notification(){
		return "notification";
	}
	
	@RequestMapping(value = "/cateInner")
	public String cateInner(){
		return "cateInner";
	}
	
	@RequestMapping(value = "/page_confirmpassword")
	public String page_confirmpassword(){
		return "page_confirmpassword";
	}
	
	@RequestMapping(value = "/eventDetail")
	public String eventDetail(){
		return "eventDetail";
	}
	
	@RequestMapping(value = "/findId")
	public String findId(){
		return "findId";
	}
	
	@RequestMapping(value = "/findPw")
	public String findPw(){
		return "findPw";
	}
	
	@RequestMapping(value = "/giftCard")
	public String giftCard(){
		return "giftCard";
	}
	
	@RequestMapping(value = "/page_gone")
	public String page_gone(){
		return "page_gone";
	}
	
	@RequestMapping(value = "/page_heart")
	public String page_heart(){
		return "page_heart";
	}
	
	@RequestMapping(value = "/singUp")
	public String singUp(){
		return "singUp";
	}
	
	@RequestMapping(value = "/login")
	public String login(){
		return "login";
	}
	
	@RequestMapping(value = "/main")
	public String main(){
		return "main";
	}
	
	@RequestMapping(value = "/memberInfo")
	public String memberInfo(){
		return "memberInfo";
	}
	
	@RequestMapping(value = "/giftCardSend")
	public String giftCardSend(){
		return "giftCardSend";
	}
	
	@RequestMapping(value = "/noticeBoard")
	public String noticeBoard(){
		return "noticeBoard";
	}
	
	@RequestMapping(value = "/nonMemEventList")
	public String nonMemEventList(){
		return "nonMemEventList";
	}
	
	@RequestMapping(value = "/nonMemTicketing")
	public String nonMemTicketing(){
		return "nonMemTicketing";
	}
	
	@RequestMapping(value = "/point")
	public String point(){
		return "point";
	}
	
	@RequestMapping(value = "/page_reservation")
	public String page_reservation(){
		return "page_reservation";
	}
	
	@RequestMapping(value = "/search")
	public String search(){
		return "search";
	}
	
	@RequestMapping(value = "/memTicketing")
	public String memTicketing(){
		return "memTicketing";
	}
	
}
