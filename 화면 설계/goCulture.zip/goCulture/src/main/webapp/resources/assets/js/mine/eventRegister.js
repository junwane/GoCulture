var sel_files = [];

function handleImgsFilesSelect(e){
	var files = e.files;
	var length = e.files.length;
	var filesArr = Array.prototype.slice.call(files);
	filesArr.forEach(function(f){
		
		sel_files.push(f);
		
		var reader = new FileReader();
		reader.onload = function(e){
			var img_html = "<img class='imgmulti' name='"+e.target.result+"' src='"+e.target.result+"'/>";
			$(".imgs_wrap").append(img_html);
			var loadimg = $("[name='"+e.target.result+"']");
			var index = $("img").index(loadimg);
			$("img:eq("+index+")").attr('id', index);
		}
		reader.readAsDataURL(f);
		
	});
}


function handleImgFileSelect(input) {

	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('#blah').attr('src', e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	}
}

