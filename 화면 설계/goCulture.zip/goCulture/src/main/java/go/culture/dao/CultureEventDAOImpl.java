package go.culture.dao;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import go.culture.domain.CultureEventVO;

@Repository
public class CultureEventDAOImpl implements CultureEventDAO {

	@Inject
	private SqlSession session;
	
	private static String namespace = "go.culture.mapper.cultureEventMapper";
	
	@Override
	public void register(CultureEventVO vo) throws Exception {
		// TODO Auto-generated method stub
		session.insert(namespace+".register",vo);
	}

}
