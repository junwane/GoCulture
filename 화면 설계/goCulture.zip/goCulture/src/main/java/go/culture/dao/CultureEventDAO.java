package go.culture.dao;

import go.culture.domain.CultureEventVO;

public interface CultureEventDAO {
	
	public void register(CultureEventVO vo) throws Exception;
	
}
