jQuery(document).ready(function() {
	App.init();
	StyleSwitcher.initStyleSwitcher();
});
$(document).ready(function() {
	$('.bxslider').bxSlider({
		maxSlides : 4,
		minSlides : 3,
		slideWidth : 170,
		slideMargin : 10
	});

})
function handleImgFileSelect(input) {

	if (input.files && input.files[0]) {
		var reader = new FileReader();
		reader.onload = function(e) {
			$('.gift').attr('src', e.target.result);
			$('#gc_img').val(e.target.result);
		}
		reader.readAsDataURL(input.files[0]);
	}
}

function clickimg(src) {

	$('.gift').attr('src', src);
	$('#gc_img').val(src);
}
