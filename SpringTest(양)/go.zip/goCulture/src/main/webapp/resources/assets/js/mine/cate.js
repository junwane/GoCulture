function search_lo(v, id){
				if(v=="show"){
					document.getElementById(id).style.display="none";
					document.getElementById(v).id = "none";
				}else if(v=="none"){
					document.getElementById(id).style.display="block";
					document.getElementById(v).id = "show";
				}
			}