package go.culture.yg;

import java.io.File;
import java.text.DateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.annotation.Resource;
import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import go.culture.domain.CultureEventVO;
import go.culture.domain.DetailedPosterVO;
import go.culture.domain.GiftCardUseVO;
import go.culture.domain.GiftCardVO;
import go.culture.domain.ListVO;
import go.culture.domain.PointVO;
import go.culture.service.CultureEventService;
import go.culture.service.GiftCardService;
import go.culture.service.ListService;
import go.culture.service.PointService;
import go.culture.utils.MediaUtils;
import go.culture.utils.UploadFileUtils;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	@Inject
	private CultureEventService ceService;

	@Inject
	private GiftCardService gcService;

	@Inject
	private PointService pService;
	
	@Inject
	private ListService liService;
	
	@Resource(name = "juploadPath")
	private String uploadPath;

	/**
	 * Simply selects the home view to render by returning its name.
	 */
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);

		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);

		String formattedDate = dateFormat.format(date);

		model.addAttribute("serverTime", formattedDate);

		return "home";
	}

	@RequestMapping(value = "/headerAf")
	public String headerAf() {
		return "headerAf";
	}

	@RequestMapping(value = "/headerBe")
	public String headerBe() {
		return "headerBe";
	}

	@RequestMapping(value = "/notification")
	public String notification() {
		return "notification";
	}

	@RequestMapping(value = "/cateInner")
	public String cateInner() {
		return "cateInner";
	}

	@RequestMapping(value = "/page_confirmpassword")
	public String page_confirmpassword() {
		return "page_confirmpassword";
	}

	@RequestMapping(value = "/eventDetail")
	public String eventDetail() {
		return "eventDetail";
	}

	@RequestMapping(value = "/eventRegister", method = RequestMethod.GET)
	public String eventRegisterGET() {
		return "eventRegister";
	}

	@RequestMapping(value = "/eventRegister", method = RequestMethod.POST)
	public String eventRegisterPOST(CultureEventVO ceVO, DetailedPosterVO dpVO) throws Exception {
		System.out.println(ceVO);
		System.out.println(dpVO);

		ceService.register(ceVO);

		return "redirect:/";
	}

	@RequestMapping(value = "/cul_mainImg", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	public ResponseEntity<String> cul_mainImg(MultipartFile file) throws Exception {
		return new ResponseEntity<String>(
				UploadFileUtils.uploadFile(uploadPath, file.getOriginalFilename(), file.getBytes()),
				HttpStatus.CREATED);
	}

	@ResponseBody
	@RequestMapping(value = "/imgRemove", method = RequestMethod.POST)
	public ResponseEntity<String> imgRemove(String fileName) {

		logger.info("delete file : " + fileName);

		// ������ Ȯ���� ����
		String formatName = fileName.substring(fileName.lastIndexOf(".") + 1);

		// �̹��� ���� ���� �˻�
		MediaType mType = MediaUtils.getMediaType(formatName);

		// �̹����� ���(����� + �������� ����), �̹����� �ƴϸ� �������ϸ� ����
		// �̹��� �����̸�
		if (mType != null) {
			String che = "/" + fileName.substring(3);
			// ����� �̹��� ����

			new File(uploadPath + (che).replace('/', File.separatorChar)).delete();
		}
		// ���� ���� ����

		new File(uploadPath + fileName.replace('/', File.separatorChar)).delete();

		// �����Ϳ� http ���� �ڵ� ����
		return new ResponseEntity<String>("deleted", HttpStatus.OK);

	}

	@RequestMapping(value = "/findId")
	public String findId() {
		return "findId";
	}

	@RequestMapping(value = "/findPw")
	public String findPw() {
		return "findPw";
	}

	@RequestMapping(value = "/giftCard", method = RequestMethod.GET)
	public void giftCard(Model model) throws Exception {
		List<GiftCardVO> listSend = gcService.listSend();
		List<GiftCardVO> listGet = gcService.listGet();
		List<GiftCardUseVO> listUse = gcService.listUse();
		model.addAttribute("listSend", listSend);
		model.addAttribute("listGet", listGet);
		model.addAttribute("listUse", listUse);
		
	}

	@RequestMapping(value = "/myEventList")
	public void myEventList(Model model) throws Exception {
		List<ListVO> listHeart = liService.listHeart();
		List<ListVO> listHeartDate = liService.listHeartDate();
		List<ListVO> listReservation = liService.listReservation();
		List<ListVO> listReservationDate = liService.listReservationDate();
		List<ListVO> listGone = liService.listGone();
		List<ListVO> listGone1mon = liService.listGone1mon();
		List<ListVO> listGone3mon = liService.listGone3mon();
		List<ListVO> listGone6mon = liService.listGone6mon();
		
		model.addAttribute("listHeart",listHeart);
		model.addAttribute("listHeartDate",listHeartDate);
		model.addAttribute("listReservation",listReservation);
		model.addAttribute("listReservationDate",listReservationDate);
		model.addAttribute("listGone",listGone);
		model.addAttribute("listGone1mon",listGone1mon);
		model.addAttribute("listGone3mon",listGone3mon);
		model.addAttribute("listGone6mon",listGone6mon);
	}
	
	@RequestMapping(value = "/singUp")
	public String singUp() {
		return "singUp";
	}

	@RequestMapping(value = "/login")
	public String login() {
		return "login";
	}

	@RequestMapping(value = "/main")
	public String main() {
		return "main";
	}

	@RequestMapping(value = "/memberInfo")
	public String memberInfo() {
		return "memberInfo";
	}

	@RequestMapping(value = "/noticeBoard")
	public String noticeBoard() {
		return "noticeBoard";
	}

	@RequestMapping(value = "/nonMemEventList")
	public String nonMemEventList() {
		return "nonMemEventList";
	}

	@RequestMapping(value = "/nonMemTicketing")
	public String nonMemTicketing() {
		return "nonMemTicketing";
	}

	@RequestMapping(value = "/point", method = RequestMethod.GET)
	public void point(Model model) throws Exception {
		List<PointVO> addPoint = pService.listAddPoint();
		List<PointVO> usePoint = pService.listUsePoint();
		model.addAttribute("addPoint", addPoint);
		model.addAttribute("usePoint", usePoint);
	}

	@RequestMapping(value = "/giftCardSend", method = RequestMethod.GET)
	public void giftCardSend() {
	}

	@RequestMapping(value = "/giftCardSend", method = RequestMethod.POST)
	public String giftCardSend(GiftCardVO vo) throws Exception {
		gcService.sendGiftCard(vo);
		return "redirect:giftCard";
	}
	
	@RequestMapping(value = "/search")
	public String search() {
		return "search";
	}

	@RequestMapping(value = "/memTicketing")
	public String memTicketing() {
		return "memTicketing";
	}

}
