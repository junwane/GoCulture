package go.culture.domain;

public class GiftCardVO {
	private int gc_no;
	private int send_no;
	private int accept_no;
	private String gc_img;
	private String gc_title;
	private String gc_content;
	private int gc_point;
	private String gc_date;

	/**
	 * @return the gc_no
	 */
	public int getGc_no() {
		return gc_no;
	}

	/**
	 * @param gc_no
	 *            the gc_no to set
	 */
	public void setGc_no(int gc_no) {
		this.gc_no = gc_no;
	}

	/**
	 * @return the send_no
	 */
	public int getSend_no() {
		return send_no;
	}

	/**
	 * @param send_no
	 *            the send_no to set
	 */
	public void setSend_no(int send_no) {
		this.send_no = send_no;
	}

	/**
	 * @return the accept_no
	 */
	public int getAccept_no() {
		return accept_no;
	}

	/**
	 * @param accept_no
	 *            the accept_no to set
	 */
	public void setAccept_no(int accept_no) {
		this.accept_no = accept_no;
	}

	/**
	 * @return the gc_img
	 */
	public String getGc_img() {
		return gc_img;
	}

	/**
	 * @param gc_img
	 *            the gc_img to set
	 */
	public void setGc_img(String gc_img) {
		this.gc_img = gc_img;
	}

	/**
	 * @return the gc_title
	 */
	public String getGc_title() {
		return gc_title;
	}

	/**
	 * @param gc_title
	 *            the gc_title to set
	 */
	public void setGc_title(String gc_title) {
		this.gc_title = gc_title;
	}

	/**
	 * @return the gc_content
	 */
	public String getGc_content() {
		return gc_content;
	}

	/**
	 * @param gc_content
	 *            the gc_content to set
	 */
	public void setGc_content(String gc_content) {
		this.gc_content = gc_content;
	}

	/**
	 * @return the gc_point
	 */
	public int getGc_point() {
		return gc_point;
	}

	/**
	 * @param gc_point
	 *            the gc_point to set
	 */
	public void setGc_point(int gc_point) {
		this.gc_point = gc_point;
	}

	/**
	 * @return the gc_date
	 */
	public String getGc_date() {
		return gc_date;
	}

	/**
	 * @param gc_date
	 *            the gc_date to set
	 */
	public void setGc_date(String gc_date) {
		this.gc_date = gc_date;
	}
	private int mg_no;
	private String m_name;
	private String m_email;
	private String m_password;
	private int m_residentNum;

	private int m_no;

	public int getM_no() {
		return m_no;
	}

	public void setM_no(int m_no) {
		this.m_no = m_no;
	}

	public int getMg_no() {
		return mg_no;
	}

	public void setMg_no(int mg_no) {
		this.mg_no = mg_no;
	}

	public String getM_name() {
		return m_name;
	}

	public void setM_name(String m_name) {
		this.m_name = m_name;
	}

	public String getM_email() {
		return m_email;
	}

	public void setM_email(String m_email) {
		this.m_email = m_email;
	}

	public String getM_password() {
		return m_password;
	}

	public void setM_password(String m_password) {
		this.m_password = m_password;
	}

	public int getM_residentNum() {
		return m_residentNum;
	}

	public void setM_residentNum(int m_residentNum) {
		this.m_residentNum = m_residentNum;
	}
}
