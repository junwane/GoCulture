package go.culture.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import go.culture.dao.MemberDAO;
import go.culture.domain.MemberVO;

@Service
public class MemberServiceImpl implements MemberService {

	@Inject
	private MemberDAO dao;
	
	@Override
	public void changePw(String pw) {
		// TODO Auto-generated method stub
		dao.changePw(pw);
	}

	@Override
	public List<MemberVO> listMyInfo() throws Exception {
		// TODO Auto-generated method stub
		return dao.listMyInfo();
	}

	@Override
	public String checkPw(String m_password) {
		// TODO Auto-generated method stub
		return dao.checkPw(m_password);
	}

	@Override
	public void delete() {
		// TODO Auto-generated method stub
		dao.delete();
	}

	@Override
	public List<MemberVO> listEmail(String search) throws Exception {
		// TODO Auto-generated method stub
		return dao.listEmail(search);
	}

}
